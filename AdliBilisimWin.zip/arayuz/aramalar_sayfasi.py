# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Aramalar Sayfası

Arama motorlarında aranan anahtar kelimeler.
"""

import flet as ft
from datetime import datetime
from typing import List, Dict
from urllib.parse import urlparse, parse_qs, unquote
from collections import Counter

from modeller.veri_modelleri import TarayiciGecmisi
from config.ayarlar import Ayarlar


class AramalarSayfasi:
    """Arama motorlarında aranan kelimeler sayfası"""
    
    def __init__(self):
        self.aramalar: List[Dict] = []
        self.kelime_frekansi: Dict[str, int] = {}
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 arama", color="#666666", size=12)
    
    def verileri_yukle(self, gecmis: List[TarayiciGecmisi]):
        """Geçmişten arama sorgularını çıkarır"""
        self.aramalar = []
        self.kelime_frekansi.clear()
        
        for kayit in gecmis:
            arama = self._arama_cikart(kayit)
            if arama:
                self.aramalar.append(arama)
                # Kelime frekansı
                for kelime in arama["sorgu"].lower().split():
                    if len(kelime) > 2:
                        self.kelime_frekansi[kelime] = self.kelime_frekansi.get(kelime, 0) + 1
        
        self.aramalar.sort(key=lambda x: x["tarih"])
        self._guncelle()
    
    def _arama_cikart(self, kayit: TarayiciGecmisi) -> Dict:
        """URL'den arama sorgusunu çıkarır"""
        try:
            parsed = urlparse(kayit.url)
            domain = parsed.netloc.replace("www.", "")
            
            for motor, param in Ayarlar.ARAMA_MOTORLARI.items():
                if motor in domain:
                    params = parse_qs(parsed.query)
                    if param in params:
                        sorgu = unquote(params[param][0])
                        return {
                            "sorgu": sorgu,
                            "motor": motor.split(".")[0].title(),
                            "tarih": kayit.ziyaret_tarihi,
                            "tarayici": kayit.tarayici.value,
                            "url": kayit.url
                        }
            return None
        except:
            return None
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.aramalar)} arama sorgusu"
        
        for arama in self.aramalar[:500]:
            try:
                tarih = arama["tarih"].strftime("%d.%m.%Y %H:%M") if arama["tarih"] != datetime.min else "-"
            except:
                tarih = "-"
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(arama["motor"][:2].upper(), size=10, 
                                           color="#888888", weight=ft.FontWeight.BOLD),
                            width=28, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Text(arama["sorgu"][:70], size=13, color="#ffffff", max_lines=1),
                            ft.Text(f"{arama['motor']} - {arama['tarayici']}", size=11, color="#555555")
                        ], expand=True, spacing=1),
                        ft.Text(tarih, size=10, color="#555555")
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a"))
                )
            )
    
    def _en_cok_aranan(self) -> List[tuple]:
        """En çok aranan kelimeler"""
        return sorted(self.kelime_frekansi.items(), key=lambda x: x[1], reverse=True)[:15]
    
    def build(self) -> ft.Container:
        top_kelimeler = self._en_cok_aranan()
        
        return ft.Container(
            content=ft.Column([
                ft.Text("Arama Geçmişi", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Arama motorlarında aranan kelimeler", size=12, color="#666666"),
                ft.Container(height=15),
                
                # En çok aranan kelimeler
                ft.Container(
                    content=ft.Column([
                        ft.Text("En Çok Aranan Kelimeler", size=12, weight=ft.FontWeight.BOLD, color="#888888"),
                        ft.Container(height=8),
                        ft.Row([
                            ft.Container(
                                content=ft.Text(f"{k} ({s})", size=10, color="#ffffff"),
                                padding=ft.padding.symmetric(horizontal=8, vertical=4),
                                bgcolor="#222222", border_radius=4
                            ) for k, s in top_kelimeler[:10]
                        ], wrap=True, spacing=6, run_spacing=6) if top_kelimeler else ft.Text("Henüz veri yok", size=11, color="#666666")
                    ]),
                    padding=12, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Container(content=self.liste, expand=True)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
