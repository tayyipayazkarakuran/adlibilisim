# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - İndirmeler Sayfası
"""

import flet as ft
from datetime import datetime
from typing import List
import json

from modeller.veri_modelleri import IndirilenDosya
from config.ayarlar import Ayarlar


class IndirmelerSayfasi:
    """İndirme geçmişi sayfası"""
    
    def __init__(self):
        self.indirmeler: List[IndirilenDosya] = []
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 indirme", color="#666666", size=12)
    
    def verileri_yukle(self, indirmeler: List[IndirilenDosya]):
        self.indirmeler = sorted(indirmeler, key=lambda x: x.baslangic_tarihi)
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.indirmeler)} indirme"
        
        for d in self.indirmeler[:300]:
            try:
                tarih = d.baslangic_tarihi.strftime("%d.%m.%Y %H:%M") if d.baslangic_tarihi != datetime.min else "-"
            except:
                tarih = "-"
            
            durum_ikon = ft.Icons.CHECK_CIRCLE if d.durum == "tamamlandi" else ft.Icons.CANCEL if d.durum == "iptal_edildi" else ft.Icons.HOURGLASS_EMPTY
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(durum_ikon, size=16, color="#666666"),
                        ft.Column([
                            ft.Text(d.dosya_adi[:55], size=13, color="#ffffff", max_lines=1),
                            ft.Text(d.kaynak_url[:70], size=11, color="#555555", max_lines=1)
                        ], expand=True, spacing=1),
                        ft.Column([
                            ft.Text(d.boyut_formatli, size=10, color="#888888"),
                            ft.Text(tarih, size=10, color="#555555")
                        ], horizontal_alignment=ft.CrossAxisAlignment.END, spacing=1)
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a"))
                )
            )
    
    def _export_csv(self, e):
        """CSV olarak dışa aktar"""
        try:
            dosya = Ayarlar.export_dizini() / f"indirmeler_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            with open(dosya, 'w', encoding='utf-8') as f:
                f.write("Dosya Adı,URL,Boyut,Tarih,Durum,Tarayıcı\n")
                for d in self.indirmeler:
                    tarih = d.baslangic_tarihi.strftime("%Y-%m-%d %H:%M:%S") if d.baslangic_tarihi != datetime.min else ""
                    f.write(f'"{d.dosya_adi}","{d.kaynak_url}","{d.boyut}","{tarih}","{d.durum}","{d.tarayici.value}"\n')
            e.page.snack_bar = ft.SnackBar(ft.Text(f"CSV kaydedildi: {dosya}"))
            e.page.snack_bar.open = True
            e.page.update()
        except Exception as ex:
            e.page.snack_bar = ft.SnackBar(ft.Text(f"Hata: {ex}"))
            e.page.snack_bar.open = True
            e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("İndirme Geçmişi", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("İndirilen dosyalar", size=12, color="#666666"),
                ft.Container(height=15),
                ft.Row([
                    self.sonuc,
                    ft.Container(
                        content=ft.Text("CSV Olarak Dışa Aktar", color="#000000", size=11),
                        padding=ft.padding.symmetric(horizontal=12, vertical=6),
                        border_radius=4, bgcolor="#ffffff", on_click=self._export_csv, ink=True
                    )
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#222222", height=1),
                ft.Container(content=self.liste, expand=True)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
