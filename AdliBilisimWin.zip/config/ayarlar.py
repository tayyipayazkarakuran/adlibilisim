"""
Adli Bilişim Forensik Aracı - Uygulama Ayarları

Bu modül uygulama genelinde kullanılan sabit değerleri ve 
konfigürasyon ayarlarını içerir.
"""

import os
import platform
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class TarayiciYolu:
    """Tarayıcı profil yolları için veri sınıfı"""
    windows: str
    macos: str
    linux: str


class Ayarlar:
    """Uygulama ayarları ve sabit değerler"""
    
    # Uygulama bilgileri
    UYGULAMA_ADI = "Adli Bilisim Forensik Araci"
    UYGULAMA_VERSIYONU = "1.0.0"
    UYGULAMA_ACIKLAMASI = "Profesyonel tarayici forensik analiz araci"
    
    # Pencere boyutları
    PENCERE_GENISLIK = 1400
    PENCERE_YUKSEKLIK = 900
    MIN_PENCERE_GENISLIK = 1200
    MIN_PENCERE_YUKSEKLIK = 700
    
    # Tema renkleri - Sadece siyah, beyaz, gri
    KOYU_TEMA = {
        "birincil": "#ffffff",
        "ikincil": "#888888",
        "arka_plan": "#0a0a0a",
        "kart_arka_plan": "#141414",
        "metin": "#ffffff",
        "metin_ikincil": "#888888",
        "tehlike": "#ff4444",
        "uyari": "#ffaa00",
        "basari": "#44ff44",
        "bilgi": "#4488ff",
        "kenar_cizgi": "#333333",
        "vurgu": "#ffffff"
    }
    
    # Tarayıcı profil yolları
    @staticmethod
    def kullanici_dizini() -> Path:
        return Path.home()
    
    @staticmethod
    def isletim_sistemi() -> str:
        sistem = platform.system().lower()
        if sistem == "darwin":
            return "macos"
        return sistem
    
    CHROME_YOLLARI = TarayiciYolu(
        windows=r"AppData\Local\Google\Chrome\User Data",
        macos="Library/Application Support/Google/Chrome",
        linux=".config/google-chrome"
    )
    
    FIREFOX_YOLLARI = TarayiciYolu(
        windows=r"AppData\Roaming\Mozilla\Firefox\Profiles",
        macos="Library/Application Support/Firefox/Profiles",
        linux=".mozilla/firefox"
    )
    
    EDGE_YOLLARI = TarayiciYolu(
        windows=r"AppData\Local\Microsoft\Edge\User Data",
        macos="Library/Application Support/Microsoft Edge",
        linux=".config/microsoft-edge"
    )
    
    OPERA_YOLLARI = TarayiciYolu(
        windows=r"AppData\Roaming\Opera Software\Opera Stable",
        macos="Library/Application Support/com.operasoftware.Opera",
        linux=".config/opera"
    )
    
    BRAVE_YOLLARI = TarayiciYolu(
        windows=r"AppData\Local\BraveSoftware\Brave-Browser\User Data",
        macos="Library/Application Support/BraveSoftware/Brave-Browser",
        linux=".config/BraveSoftware/Brave-Browser"
    )
    
    SAFARI_YOLLARI = TarayiciYolu(
        windows="",
        macos="Library/Safari",
        linux=""
    )
    
    @classmethod
    def tarayici_yolu_al(cls, tarayici: str) -> Path:
        sistem = cls.isletim_sistemi()
        kullanici = cls.kullanici_dizini()
        
        yol_mapping = {
            'chrome': cls.CHROME_YOLLARI,
            'firefox': cls.FIREFOX_YOLLARI,
            'edge': cls.EDGE_YOLLARI,
            'opera': cls.OPERA_YOLLARI,
            'brave': cls.BRAVE_YOLLARI,
            'safari': cls.SAFARI_YOLLARI
        }
        
        if tarayici.lower() not in yol_mapping:
            raise ValueError(f"Bilinmeyen tarayici: {tarayici}")
        
        yollar = yol_mapping[tarayici.lower()]
        
        if sistem == "windows":
            return kullanici / yollar.windows
        elif sistem == "macos":
            return kullanici / yollar.macos
        else:
            return kullanici / yollar.linux
    
    DESTEKLENEN_TARAYICILAR = [
        {"ad": "Google Chrome", "kod": "chrome"},
        {"ad": "Mozilla Firefox", "kod": "firefox"},
        {"ad": "Microsoft Edge", "kod": "edge"},
        {"ad": "Opera", "kod": "opera"},
        {"ad": "Brave", "kod": "brave"},
        {"ad": "Safari", "kod": "safari"}
    ]
    
    @classmethod
    def export_dizini(cls) -> Path:
        dizin = Path(__file__).parent.parent / "exports"
        dizin.mkdir(exist_ok=True)
        return dizin
    
    @classmethod
    def rapor_dizini(cls) -> Path:
        dizin = cls.export_dizini() / "raporlar"
        dizin.mkdir(exist_ok=True)
        return dizin
    
    @classmethod
    def gorsel_dizini(cls) -> Path:
        dizin = cls.export_dizini() / "gorseller"
        dizin.mkdir(exist_ok=True)
        return dizin
    
    CHROME_GECMIS_DB = "History"
    CHROME_CEREZ_DB = "Cookies"
    CHROME_LOGIN_DB = "Login Data"
    CHROME_WEB_DATA_DB = "Web Data"
    
    FIREFOX_GECMIS_DB = "places.sqlite"
    FIREFOX_CEREZ_DB = "cookies.sqlite"
    FIREFOX_LOGIN_JSON = "logins.json"
    FIREFOX_KEY_DB = "key4.db"
    
    CHROME_EPOCH_FARKI = 11644473600000000
    WEBKIT_EPOCH_FARKI = 978307200
    
    # Arama motorları ve parametreleri
    ARAMA_MOTORLARI = {
        "google.com": "q",
        "google.com.tr": "q",
        "bing.com": "q",
        "yahoo.com": "p",
        "duckduckgo.com": "q",
        "yandex.com": "text",
        "yandex.com.tr": "text",
        "baidu.com": "wd",
        "ask.com": "q",
        "ecosia.org": "q"
    }
