"""
Adli Bilişim Forensik Aracı - Safari Veri Çıkarıcı

Safari tarayıcısından veri çıkarma modülü (sadece macOS).
"""

from typing import List, Optional
from pathlib import Path
from datetime import datetime
import plistlib
import os

from .temel_cikarici import TemelCikarici
from modeller.veri_modelleri import (
    TarayiciGecmisi,
    Cerez,
    IndirilenDosya,
    KayitliSifre,
    FormVerisi,
    CacheGorsel,
    TarayiciTipi
)
from config.ayarlar import Ayarlar


class SafariCikarici(TemelCikarici):
    """Safari tarayıcısı için veri çıkarıcı (sadece macOS)"""
    
    def __init__(self):
        super().__init__(TarayiciTipi.SAFARI)
    
    def profil_yolu_bul(self) -> Optional[Path]:
        """Safari profil dizinini bulur"""
        # Safari sadece macOS'ta çalışır
        if Ayarlar.isletim_sistemi() != "macos":
            return None
        
        try:
            yol = Ayarlar.tarayici_yolu_al('safari')
            if yol.exists():
                self.profil_yolu = yol
                return yol
            return None
        except Exception as e:
            self.hatalar.append(f"Profil yolu bulunamadı: {str(e)}")
            return None
    
    def profilleri_listele(self) -> List[str]:
        """Safari profillerini listeler"""
        # Safari tek profil kullanır
        if self.profil_yolu_bul():
            return ["Default"]
        return []
    
    def _profil_dizini(self, profil: str = "Default") -> Optional[Path]:
        """Safari profil dizinini döndürür"""
        return self.profil_yolu_bul()
    
    def gecmis_cikart(self, profil: str = "Default") -> List[TarayiciGecmisi]:
        """Safari tarayıcı geçmişini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        db_yolu = profil_dizini / "History.db"
        
        if not db_yolu.exists():
            self.hatalar.append("Safari geçmiş veritabanı bulunamadı")
            return sonuclar
        
        sorgu = """
            SELECT 
                history_items.id,
                history_items.url,
                history_visits.title,
                history_visits.visit_time,
                history_items.visit_count
            FROM history_items
            JOIN history_visits ON history_items.id = history_visits.history_item
            ORDER BY history_visits.visit_time ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                kayit = TarayiciGecmisi(
                    id=satir[0],
                    url=satir[1] or "",
                    baslik=satir[2] or "(Başlıksız)",
                    ziyaret_tarihi=self.webkit_zamani_cevir(satir[3] or 0),
                    ziyaret_sayisi=satir[4] or 1,
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Geçmiş kaydı işleme hatası: {str(e)}")
        
        return sonuclar
    
    def cerezleri_cikart(self, profil: str = "Default") -> List[Cerez]:
        """Safari çerezlerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        # Safari çerezleri binarycookies formatında
        cookies_yolu = profil_dizini / "Cookies" / "Cookies.binarycookies"
        
        if not cookies_yolu.exists():
            # Alternatif konum
            cookies_yolu = Path.home() / "Library" / "Cookies" / "Cookies.binarycookies"
        
        if not cookies_yolu.exists():
            self.hatalar.append("Safari çerez dosyası bulunamadı")
            return sonuclar
        
        try:
            # Basit binarycookies okuyucu
            with open(cookies_yolu, 'rb') as f:
                # Magic number kontrolü
                magic = f.read(4)
                if magic != b'cook':
                    self.hatalar.append("Geçersiz çerez dosyası formatı")
                    return sonuclar
                
                # Sayfa sayısı
                num_pages = int.from_bytes(f.read(4), 'big')
                
                # Safari binarycookies formatı karmaşık olduğu için
                # basit bir uygulama yapıyoruz
                self.hatalar.append("Safari çerez okuma kısmen destekleniyor")
        except Exception as e:
            self.hatalar.append(f"Çerez okuma hatası: {str(e)}")
        
        return sonuclar
    
    def indirmeleri_cikart(self, profil: str = "Default") -> List[IndirilenDosya]:
        """Safari indirme geçmişini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        downloads_plist = profil_dizini / "Downloads.plist"
        
        if not downloads_plist.exists():
            return sonuclar
        
        try:
            with open(downloads_plist, 'rb') as f:
                plist = plistlib.load(f)
            
            downloads = plist.get('DownloadHistory', [])
            
            for idx, download in enumerate(downloads):
                try:
                    dosya_yolu = download.get('DownloadEntryPath', '')
                    dosya_adi = os.path.basename(dosya_yolu) if dosya_yolu else "bilinmiyor"
                    
                    kayit = IndirilenDosya(
                        id=idx + 1,
                        dosya_adi=dosya_adi,
                        dosya_yolu=dosya_yolu,
                        kaynak_url=download.get('DownloadEntryURL', ''),
                        baslangic_tarihi=download.get('DownloadEntryDateAddedKey', datetime.min),
                        bitis_tarihi=download.get('DownloadEntryDateFinishedKey'),
                        dosya_boyutu=download.get('DownloadEntryProgressTotalToLoad', 0),
                        durum="tamamlandi",
                        tarayici=self.tarayici_tipi,
                        profil=profil
                    )
                    sonuclar.append(kayit)
                except Exception as e:
                    self.hatalar.append(f"İndirme kaydı işleme hatası: {str(e)}")
        except Exception as e:
            self.hatalar.append(f"Downloads.plist okuma hatası: {str(e)}")
        
        return sonuclar
    
    def sifreleri_cikart(self, profil: str = "Default") -> List[KayitliSifre]:
        """Safari kayıtlı şifrelerini çıkarır"""
        # Safari şifreleri macOS Keychain'de saklanır
        # Güvenlik nedeniyle erişim kısıtlıdır
        self.hatalar.append("Safari şifreleri macOS Keychain'de saklanır ve erişim izni gerektirir")
        return []
    
    def form_verilerini_cikart(self, profil: str = "Default") -> List[FormVerisi]:
        """Safari form verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        # Safari form verileri
        form_values_path = profil_dizini / "Form Values"
        
        # Eğer bir dosya ise (bazı sürümlerde şifreli tek dosya)
        if form_values_path.is_file():
             self.hatalar.append("Form Values şifreli bir dosya, okunamadı.")
             return sonuclar

        if not form_values_path.exists() or not form_values_path.is_dir():
            return sonuclar
        
        try:
            # Form değerleri dizinini tara
            for dosya in form_values_path.iterdir():
                if dosya.suffix == '.plist':
                    try:
                        with open(dosya, 'rb') as f:
                            plist = plistlib.load(f)
                        
                        for key, value in plist.items():
                            kayit = FormVerisi(
                                id=len(sonuclar) + 1,
                                alan_adi=str(key),
                                deger=str(value) if value else "",
                                kullanim_sayisi=1,
                                son_kullanim_tarihi=None,
                                tarayici=self.tarayici_tipi,
                                profil=profil
                            )
                            sonuclar.append(kayit)
                    except Exception:
                        continue
        except Exception as e:
            self.hatalar.append(f"Form verileri okuma hatası: {str(e)}")
        
        return sonuclar
    
    def cache_gorselleri_cikart(self, profil: str = "Default") -> List[CacheGorsel]:
        """Safari cache görsellerini çıkarır"""
        sonuclar = []
        
        # Safari cache yolları (macOS)
        cache_yollari = [
            Path.home() / "Library" / "Caches" / "com.apple.Safari" / "fsCachedData",
            Path.home() / "Library" / "Caches" / "com.apple.Safari" / "Webpage Previews",
            Path.home() / "Library" / "Containers" / "com.apple.Safari" / "Data" / "Library" / "Caches" / "com.apple.Safari",
            # Big Sur ve sonrası için container yolu
            Path.home() / "Library" / "Containers" / "com.apple.Safari" / "Data" / "Library" / "Caches"
        ]
        
        gorsel_id = 0
        
        for cache_dizini in cache_yollari:
            if not cache_dizini.exists():
                continue
                
            try:
                # Recursive search for images
                # Limit limit to avoid freezing on huge caches
                for i, dosya in enumerate(cache_dizini.rglob("*")):
                    if i > 5000: # Limit per directory
                        break
                        
                    if dosya.is_file():
                        try:
                            # Hızlı kontrol için uzantı (varsa)
                            if dosya.suffix.lower() in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.ico']:
                                # Uzantı varsa direkt işle
                                pass
                            else:
                                # Uzantı yoksa veya bilinmiyorsa header oku
                                if dosya.stat().st_size < 16:
                                    continue
                                    
                            with open(dosya, 'rb') as f:
                                header = f.read(16)
                            
                            format_turu = None
                            
                            if header.startswith(b'\xff\xd8\xff'):
                                format_turu = 'jpeg'
                            elif header.startswith(b'\x89PNG'):
                                format_turu = 'png'
                            elif header.startswith(b'GIF'):
                                format_turu = 'gif'
                            elif header.startswith(b'RIFF') and b'WEBP' in header:
                                format_turu = 'webp'
                            
                            if format_turu:
                                gorsel_id += 1
                                stat = dosya.stat()
                                
                                kayit = CacheGorsel(
                                    id=gorsel_id,
                                    dosya_yolu=str(dosya),
                                    kaynak_url=None,
                                    dosya_boyutu=stat.st_size,
                                    genislik=None,
                                    yukseklik=None,
                                    format=format_turu,
                                    olusturma_tarihi=datetime.fromtimestamp(stat.st_mtime),
                                    tarayici=self.tarayici_tipi,
                                    profil=profil
                                )
                                sonuclar.append(kayit)
                        except Exception:
                            continue
            except Exception as e:
                self.hatalar.append(f"Cache tarama hatası ({cache_dizini}): {str(e)}")
        
        return sonuclar
