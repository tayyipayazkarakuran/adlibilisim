#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - v3.0

Profesyonel tarayıcı forensik analiz uygulaması.
"""

import flet as ft
import sys
import os
import threading
import traceback
from datetime import datetime
from typing import List, Dict, Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.ayarlar import Ayarlar
from cikarticilar import (
    ChromeCikarici, FirefoxCikarici, EdgeCikarici,
    OperaCikarici, BraveCikarici, SafariCikarici
)
# Helper classes
from yardimcilar.eklenti_analizci import EklentiAnalizci
from yardimcilar.sistem_analizci import SistemAnalizci

# UI Pages
from arayuz.ana_sayfa import AnaSayfa
from arayuz.gecmis_sayfasi import GecmisSayfasi
from arayuz.aramalar_sayfasi import AramalarSayfasi
from arayuz.cerez_sayfasi import CerezSayfasi
from arayuz.indirmeler_sayfasi import IndirmelerSayfasi
from arayuz.sifreler_sayfasi import SifrelerSayfasi
from arayuz.cache_sayfasi import CacheSayfasi
from arayuz.rapor_sayfasi import RaporSayfasi
from arayuz.oturum_sayfasi import OturumSayfasi
from arayuz.local_storage_sayfasi import LocalStorageSayfasi
from arayuz.kurtarma_sayfasi import KurtarmaSayfasi
from arayuz.otomatik_doldurma_sayfasi import OtomatikDoldurmaSayfasi
from arayuz.medya_sayfasi import MedyaSayfasi
from arayuz.forensik_sayfasi import ForensikSayfasi
# New UI Pages
from arayuz.zaman_cizelgesi_sayfasi import ZamanCizelgesiSayfasi
from arayuz.eklentiler_sayfasi import EklentilerSayfasi
from arayuz.genel_arama_sayfasi import GenelAramaSayfasi


class AdliBilisimUygulamasi:
    """Ana uygulama sınıfı"""
    
    def __init__(self, page: ft.Page):
        self.page = page
        self.tum_gecmis = []
        
        # Sayfalar
        self.ana_sayfa = AnaSayfa(self._tarama_baslat)
        self.gecmis_sayfasi = GecmisSayfasi()
        self.aramalar_sayfasi = AramalarSayfasi()
        self.zaman_cizelgesi_sayfasi = ZamanCizelgesiSayfasi() # Yeni
        self.eklentiler_sayfasi = EklentilerSayfasi() # Yeni
        self.genel_arama_sayfasi = GenelAramaSayfasi() # Yeni
        self.cerez_sayfasi = CerezSayfasi()
        self.indirmeler_sayfasi = IndirmelerSayfasi()
        self.sifreler_sayfasi = SifrelerSayfasi()
        self.cache_sayfasi = CacheSayfasi()
        self.oturum_sayfasi = OturumSayfasi()
        self.local_storage_sayfasi = LocalStorageSayfasi()
        self.kurtarma_sayfasi = KurtarmaSayfasi()
        self.otomatik_doldurma_sayfasi = OtomatikDoldurmaSayfasi()
        self.medya_sayfasi = MedyaSayfasi()
        self.forensik_sayfasi = ForensikSayfasi()
        self.rapor_sayfasi = RaporSayfasi()
        
        # Sayfa listesi (Navigasyon sırasına göre)
        self.sayfalar = [
            self.ana_sayfa,          # 0
            self.gecmis_sayfasi,      # 1
            self.aramalar_sayfasi,    # 2
            self.zaman_cizelgesi_sayfasi, # 3
            self.eklentiler_sayfasi,  # 4
            self.genel_arama_sayfasi, # 5
            self.cerez_sayfasi,       # 6
            self.indirmeler_sayfasi,  # 7
            self.sifreler_sayfasi,    # 8
            self.cache_sayfasi,       # 9
            self.oturum_sayfasi,      # 10
            self.local_storage_sayfasi, # 11
            self.kurtarma_sayfasi,    # 12
            self.otomatik_doldurma_sayfasi, # 13
            self.medya_sayfasi,       # 14
            self.forensik_sayfasi,    # 15
            self.rapor_sayfasi        # 16
        ]
        
        self.icerik = ft.Container(expand=True, bgcolor="#0a0a0a")
        self.secili = 0
        
        # Yardımcılar
        self.eklenti_analizci = EklentiAnalizci()
        self.sistem_analizci = SistemAnalizci()
        
        self._sayfa_ayarla()
    
    def _sayfa_ayarla(self):
        self.page.title = Ayarlar.UYGULAMA_ADI
        self.page.theme_mode = ft.ThemeMode.DARK
        self.page.bgcolor = "#0a0a0a"
        self.page.window.width = Ayarlar.PENCERE_GENISLIK
        self.page.window.height = Ayarlar.PENCERE_YUKSEKLIK
        self.page.padding = 0
        
        self._uyari_goster()
    
    def _uyari_goster(self):
        def kapat(e):
            dialog.open = False
            self.page.update()
            self._arayuz_olustur()
        
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Yasal Uyarı", text_align=ft.TextAlign.CENTER, color="#ffffff"),
            content=ft.Column([
                ft.Text("Bu uygulama sadece aşağıdaki amaçlar için kullanılmalıdır:", size=13, color="#cccccc"),
                ft.Container(height=10),
                ft.Text("• Eğitim ve öğretim amaçlı çalışmalar", size=12, color="#888888"),
                ft.Text("• Yetkili adli bilişim incelemeleri", size=12, color="#888888"),
                ft.Text("• Kendi bilgisayarınızdaki verileri analiz etme", size=12, color="#888888"),
                ft.Container(height=10),
                ft.Text("Yetkisiz erişim veya veri çalma amaçlı kullanım YASAKTIR.", size=12, color="#ff6666"),
            ], tight=True),
            actions=[ft.TextButton("Kabul Ediyorum", on_click=kapat)],
            actions_alignment=ft.MainAxisAlignment.CENTER,
            bgcolor="#141414"
        )
        
        self.page.overlay.append(dialog)
        dialog.open = True
        self.page.update()
    
    def _arayuz_olustur(self):
        # Menü öğeleri tanımı
        self.menu_items = [
            {"icon": ft.Icons.HOME_OUTLINED, "sel_icon": ft.Icons.HOME, "label": "Ana Sayfa"},
            {"icon": ft.Icons.HISTORY_OUTLINED, "sel_icon": ft.Icons.HISTORY, "label": "Geçmiş"},
            {"icon": ft.Icons.SEARCH_OUTLINED, "sel_icon": ft.Icons.SEARCH, "label": "Aramalar"},
            {"icon": ft.Icons.MAP_OUTLINED, "sel_icon": ft.Icons.MAP, "label": "Zaman Çizelgesi"},
            {"icon": ft.Icons.EXTENSION_OUTLINED, "sel_icon": ft.Icons.EXTENSION, "label": "Eklentiler"},
            {"icon": ft.Icons.FIND_IN_PAGE_OUTLINED, "sel_icon": ft.Icons.FIND_IN_PAGE, "label": "Genel Arama"},
            {"icon": ft.Icons.COOKIE_OUTLINED, "sel_icon": ft.Icons.COOKIE, "label": "Çerezler"},
            {"icon": ft.Icons.DOWNLOAD_OUTLINED, "sel_icon": ft.Icons.DOWNLOAD, "label": "İndirmeler"},
            {"icon": ft.Icons.LOCK_OUTLINE, "sel_icon": ft.Icons.LOCK, "label": "Şifreler"},
            {"icon": ft.Icons.IMAGE_OUTLINED, "sel_icon": ft.Icons.IMAGE, "label": "Cache"},
            {"icon": ft.Icons.TAB_OUTLINED, "sel_icon": ft.Icons.TAB, "label": "Oturumlar"},
            {"icon": ft.Icons.STORAGE_OUTLINED, "sel_icon": ft.Icons.STORAGE, "label": "Storage"},
            {"icon": ft.Icons.RESTORE_OUTLINED, "sel_icon": ft.Icons.RESTORE, "label": "Kurtarma"},
            {"icon": ft.Icons.TEXT_FIELDS_OUTLINED, "sel_icon": ft.Icons.TEXT_FIELDS, "label": "Doldurma"},
            {"icon": ft.Icons.PLAY_CIRCLE_OUTLINE, "sel_icon": ft.Icons.PLAY_CIRCLE, "label": "Medya"},
            {"icon": ft.Icons.SECURITY_OUTLINED, "sel_icon": ft.Icons.SECURITY, "label": "Forensik"},
            {"icon": ft.Icons.DESCRIPTION_OUTLINED, "sel_icon": ft.Icons.DESCRIPTION, "label": "Rapor"},
        ]
        
        # Sidebar listesi
        self.nav_column = ft.Column(spacing=2, scroll=ft.ScrollMode.AUTO)
        self._sidebar_yenile()
        
        # Sidebar container
        sidebar_container = ft.Container(
            content=self.nav_column,
            width=200, 
            bgcolor="#0a0a0a",
            padding=ft.Padding.only(right=10, top=10, bottom=10, left=5),
            border=ft.Border.only(right=ft.BorderSide(1, "#222222"))
        )
        
        self.icerik.content = self.ana_sayfa.build()
        
        self.page.add(
            ft.Row([sidebar_container, self.icerik], 
                   expand=True, spacing=0)
        )
    
    def _sidebar_yenile(self):
        """Sidebar menüsünü yeniden çizer"""
        self.nav_column.controls.clear()
        
        # Başlık veya Logo eklenebilir
        self.nav_column.controls.append(
            ft.Container(
                content=ft.Text("MENÜ", size=10, weight=ft.FontWeight.BOLD, color="#444444"),
                padding=ft.Padding.only(left=12, bottom=5)
            )
        )
        
        for i, item in enumerate(self.menu_items):
            is_selected = (i == self.secili)
            
            # Renkler
            text_color = "#ffffff" if is_selected else "#888888"
            icon_color = "#ffffff" if is_selected else "#888888"
            bg_color = "#222222" if is_selected else None
            
            self.nav_column.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(item["sel_icon"] if is_selected else item["icon"], size=18, color=icon_color),
                        ft.Text(item["label"], size=13, color=text_color, weight=ft.FontWeight.W_500 if is_selected else ft.FontWeight.NORMAL)
                    ], spacing=12),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=10),
                    border_radius=6,
                    bgcolor=bg_color,
                    on_click=lambda e, idx=i: self._menu_tiklandi(e, idx),
                    ink=True
                )
            )
        
        try:
            if self.nav_column.page:
                self.nav_column.update()
        except Exception:
            pass

    def _menu_tiklandi(self, e, index):
        self.secili = index
        self._sayfa_degistir()
        self._sidebar_yenile()

    def _sayfa_degistir(self):
        if 0 <= self.secili < len(self.sayfalar):
            self.icerik.content = self.sayfalar[self.secili].build()
            self.icerik.update()
    
    def _tarama_baslat(self):
        """Tarama işlemini başlatır (thread içinde çalışır)"""
        self.ana_sayfa.tarama_durumu.value = "Tarama başlatılıyor..."
        self.ana_sayfa.ilerleme.visible = True
        self.page.update()
        
        tarama_thread = threading.Thread(target=self._tarama_yap, daemon=True)
        tarama_thread.start()
    
    def _tarama_yap(self):
        """Gerçek tarama işlemini yapar (ayrı thread'de çalışır)"""
        baslangic = datetime.now()
        hata_mesajlari = []
        
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            
            cikarticilar = [
                ChromeCikarici(), FirefoxCikarici(), EdgeCikarici(),
                OperaCikarici(), BraveCikarici(), SafariCikarici()
            ]
            
            # Veri kapları
            tum_gecmis = []
            tum_cerezler = []
            tum_indirmeler = []
            tum_sifreler = []
            tum_form = []
            tum_cache = []
            tum_oturumlar = []
            tum_local_storage = []
            tum_silinen = []
            tum_otomatik_doldurma = []
            tum_medya = []
            tum_silme_girisimi = []
            tum_sw_cache = []
            tum_eklentiler = [] # Yeni
            
            def cikarici_isle(c, p):
                sonuc = {
                    'gecmis': [], 'cerezler': [], 'indirmeler': [],
                    'sifreler': [], 'form': [], 'cache': [],
                    'oturumlar': [], 'local_storage': [], 'silinen': [],
                    'otomatik_doldurma': [], 'medya': [], 'silme_girisimi': [],
                    'sw_cache': [], 'eklentiler': [],
                    'hatalar': []
                }
                try:
                    # Mevcut çıkarmalar
                    sonuc['gecmis'] = c.gecmis_cikart(p)
                    sonuc['cerezler'] = c.cerezleri_cikart(p)
                    sonuc['indirmeler'] = c.indirmeleri_cikart(p)
                    sonuc['sifreler'] = c.sifreleri_cikart(p)
                    sonuc['form'] = c.form_verilerini_cikart(p)
                    sonuc['cache'] = c.cache_gorselleri_cikart(p)
                    sonuc['oturumlar'] = c.oturum_cikart(p)
                    sonuc['local_storage'] = c.local_storage_cikart(p)
                    sonuc['silinen'] = c.silinen_verileri_kurtar(p)
                    sonuc['otomatik_doldurma'] = c.otomatik_doldurma_cikart(p)
                    sonuc['medya'] = c.medya_gecmisi_cikart(p)
                    sonuc['silme_girisimi'] = c.silme_girisimi_tespit(p)
                    sonuc['sw_cache'] = c.service_worker_cache_cikart(p)
                    
                    # Eklenti analizi (yeni)
                    profil_yolu = Ayarlar.tarayici_yolu_al(c.tarayici_adi) 
                    # Not: Profil yolu tam yolu vermeyebilir, cikarici instance'inda yol olmalı.
                    # Aslında profilleri_listele tam yolu değil sadece profil klasör adını döndürüyor.
                    # Base path + profil adı.
                    base_path = Ayarlar.tarayici_yolu_al(c.tarayici_adi)
                    full_profil_path = base_path / p
                    
                    sonuc['eklentiler'] = self.eklenti_analizci.eklentileri_bul(
                        c.tarayici_adi, p, full_profil_path
                    )
                    
                    if c.hatalar:
                        sonuc['hatalar'] = [f"{c.tarayici_adi}: {h}" for h in c.hatalar]
                except Exception as e:
                    sonuc['hatalar'].append(f"{c.tarayici_adi} ({p}): {str(e)}")
                return sonuc
            
            # Görevleri oluştur
            gorevler = []
            for c in cikarticilar:
                try:
                    if c.tarayici_kurulu_mu():
                        profiller = c.profilleri_listele()
                        if profiller:
                            for p in profiller[:2]:
                                gorevler.append((c, p))
                except Exception as e:
                    hata_mesajlari.append(f"{c.tarayici_adi}: {str(e)}")
            
            # Paralel çalıştır
            max_workers = min(len(gorevler) or 1, 6)
            
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(cikarici_isle, c, p): (c, p) for c, p in gorevler}
                
                for future in as_completed(futures):
                    c, p = futures[future]
                    try:
                        sonuc = future.result(timeout=90) # Timeout artırıldı (eklenti analizi için)
                        if sonuc:
                            tum_gecmis.extend(sonuc.get('gecmis', []))
                            tum_cerezler.extend(sonuc.get('cerezler', []))
                            tum_indirmeler.extend(sonuc.get('indirmeler', []))
                            tum_sifreler.extend(sonuc.get('sifreler', []))
                            tum_form.extend(sonuc.get('form', []))
                            tum_cache.extend(sonuc.get('cache', []))
                            tum_oturumlar.extend(sonuc.get('oturumlar', []))
                            tum_local_storage.extend(sonuc.get('local_storage', []))
                            tum_silinen.extend(sonuc.get('silinen', []))
                            tum_otomatik_doldurma.extend(sonuc.get('otomatik_doldurma', []))
                            tum_medya.extend(sonuc.get('medya', []))
                            tum_silme_girisimi.extend(sonuc.get('silme_girisimi', []))
                            tum_sw_cache.extend(sonuc.get('sw_cache', []))
                            tum_eklentiler.extend(sonuc.get('eklentiler', []))
                            
                            if sonuc.get('hatalar'):
                                hata_mesajlari.extend(sonuc['hatalar'])
                    except TimeoutError:
                         hata_mesajlari.append(f"Zaman aşımı: {c.tarayici_adi} - {p}")
                    except Exception as e:
                        hata_mesajlari.append(f"İşlem hatası ({c.tarayici_adi}): {str(e)}")
            
            # Sistem analizi (Single thread, hızlıdır)
            usb_verileri = self.sistem_analizci.usb_gecmisi_getir()
            
            self.tum_gecmis = tum_gecmis
            
            # UI Güncelleme (Tüm verilerle)
            self._tarama_sonucu_guncelle(
                tum_gecmis, tum_cerezler, tum_indirmeler, 
                tum_sifreler, tum_form, tum_cache, 
                tum_oturumlar, tum_local_storage, tum_silinen,
                tum_otomatik_doldurma, tum_medya, tum_silme_girisimi, tum_sw_cache,
                tum_eklentiler, usb_verileri,
                baslangic, hata_mesajlari
            )
            
        except Exception as e:
            hata_msg = f"Kritik tarama hatası: {str(e)}"
            print(f"KRİTİK HATA: {hata_msg}")
            traceback.print_exc()
            self._tarama_hata_goster(hata_msg)
    
    def _tarama_sonucu_guncelle(self, tum_gecmis, tum_cerezler, tum_indirmeler, 
                                tum_sifreler, tum_form, tum_cache, 
                                tum_oturumlar, tum_local_storage, tum_silinen,
                                tum_otomatik_doldurma, tum_medya, tum_silme_girisimi, tum_sw_cache,
                                tum_eklentiler, usb_verileri,
                                baslangic, hata_mesajlari):
        """Tarama sonuçlarını UI'da günceller (UI thread'de çalışır)"""
        try:
            # Mevcut sayfalar
            self.gecmis_sayfasi.verileri_yukle(tum_gecmis)
            self.aramalar_sayfasi.verileri_yukle(tum_gecmis)
            self.cerez_sayfasi.verileri_yukle(tum_cerezler)
            self.indirmeler_sayfasi.verileri_yukle(tum_indirmeler)
            self.sifreler_sayfasi.verileri_yukle(tum_sifreler)
            self.cache_sayfasi.verileri_yukle(tum_cache)
            self.oturum_sayfasi.verileri_yukle(tum_oturumlar)
            self.local_storage_sayfasi.verileri_yukle(tum_local_storage)
            self.kurtarma_sayfasi.verileri_yukle(tum_silinen)
            self.otomatik_doldurma_sayfasi.verileri_yukle(tum_otomatik_doldurma)
            self.medya_sayfasi.verileri_yukle(tum_medya)
            
            # Yeni Sayfalar
            self.forensik_sayfasi.verileri_yukle(
                silme=tum_silme_girisimi, 
                usb=usb_verileri
                # Gizli mod izleri entegre edilecekse buraya eklenebilir
            )
            self.eklentiler_sayfasi.verileri_yukle(tum_eklentiler)
            
            # Toplu Veri Paketleri (Rapor, Zaman çizelgesi, Global Arama)
            tum_veriler_dict = {
                "gecmis": tum_gecmis,
                "cerez": tum_cerezler,
                "indirme": tum_indirmeler,
                "sifre": tum_sifreler,
                "form": tum_form,
                "cache": tum_cache,
                "oturum": tum_oturumlar,
                "storage": tum_local_storage,
                "silinen": tum_silinen,
                "otomatik_doldurma": tum_otomatik_doldurma,
                "medya": tum_medya,
                "eklenti": tum_eklentiler,
                "usb": usb_verileri
            }
            
            self.zaman_cizelgesi_sayfasi.verileri_yukle(tum_veriler_dict)
            self.genel_arama_sayfasi.verileri_yukle(tum_veriler_dict)
            self.rapor_sayfasi.verileri_yukle(tum_veriler_dict)
            
            # Ana Sayfa İstatistikler
            istatistikler = {
                "gecmis": len(tum_gecmis),
                "arama": len(self.aramalar_sayfasi.aramalar),
                "cerez": len(tum_cerezler),
                "indirme": len(tum_indirmeler),
                "sifre": len(tum_sifreler),
                "cache": len(tum_cache),
                "oturum": len(tum_oturumlar),
                "storage": len(tum_local_storage),
                "kurtarma": len(tum_silinen)
            }
            self.ana_sayfa.istatistikleri_guncelle(istatistikler)
            
            # Durum mesajı
            sure = (datetime.now() - baslangic).total_seconds()
            durum_mesaji = f"✓ Tarama tamamlandı ({sure:.1f}s)"
            if hata_mesajlari:
                durum_mesaji += f" - {len(hata_mesajlari)} hata"
                print(f"Tarama Hataları: {len(hata_mesajlari)}")
            
            self.ana_sayfa.tarama_durumu.value = durum_mesaji
            self.ana_sayfa.ilerleme.visible = False
            self.page.update()
            
        except Exception as e:
            hata_msg = f"UI güncelleme hatası: {str(e)}"
            print(hata_msg)
            traceback.print_exc()
            self._tarama_hata_goster(hata_msg)
    
    def _tarama_hata_goster(self, hata_mesaji: str):
        self.ana_sayfa.tarama_durumu.value = f"✗ Hata: {hata_mesaji[:50]}..."
        self.ana_sayfa.ilerleme.visible = False
        self.page.update()


def main(page: ft.Page):
    AdliBilisimUygulamasi(page)


if __name__ == "__main__":
    ft.app(target=main)
