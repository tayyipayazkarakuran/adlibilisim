"""
Adli Bilişim Forensik Aracı - Cache İşleyici Modülü

Cache görsellerini bulma, işleme ve export etme.
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Tuple

from modeller.veri_modelleri import CacheGorsel, TarayiciTipi
from config.ayarlar import Ayarlar


class CacheIsleyici:
    """Cache görsellerini işleme sınıfı"""
    
    def __init__(self):
        self.hatalar = []
        self.export_dizini = Ayarlar.gorsel_dizini()
    
    def gorsel_turu_belirle(self, dosya_yolu: Path) -> Optional[Tuple[str, str]]:
        """Dosyanın görsel türünü magic bytes ile belirler"""
        try:
            with open(dosya_yolu, 'rb') as f:
                header = f.read(16)
            
            if header.startswith(b'\xff\xd8\xff'):
                return ('jpeg', '.jpg')
            if header.startswith(b'\x89PNG'):
                return ('png', '.png')
            if header.startswith(b'GIF'):
                return ('gif', '.gif')
            if header.startswith(b'RIFF') and b'WEBP' in header:
                return ('webp', '.webp')
            if header.startswith(b'BM'):
                return ('bmp', '.bmp')
            return None
        except Exception:
            return None
    
    def gorsel_boyutlari_al(self, dosya_yolu: Path) -> Tuple[Optional[int], Optional[int]]:
        """Görselin genişlik ve yüksekliğini alır"""
        try:
            from PIL import Image
            with Image.open(dosya_yolu) as img:
                return img.size
        except Exception:
            return (None, None)
    
    def cache_tara(self, cache_dizini: Path, tarayici: TarayiciTipi, 
                   profil: str = "Default") -> List[CacheGorsel]:
        """Cache dizinini tarayarak görselleri bulur"""
        sonuclar = []
        if not cache_dizini.exists():
            return sonuclar
        
        gorsel_id = 0
        try:
            for dosya in cache_dizini.rglob('*'):
                if not dosya.is_file():
                    continue
                gorsel_bilgi = self.gorsel_turu_belirle(dosya)
                if gorsel_bilgi is None:
                    continue
                
                format_turu, _ = gorsel_bilgi
                gorsel_id += 1
                try:
                    stat = dosya.stat()
                    genislik, yukseklik = self.gorsel_boyutlari_al(dosya)
                    kayit = CacheGorsel(
                        id=gorsel_id, dosya_yolu=str(dosya), kaynak_url=None,
                        dosya_boyutu=stat.st_size, genislik=genislik, yukseklik=yukseklik,
                        format=format_turu, olusturma_tarihi=datetime.fromtimestamp(stat.st_mtime),
                        tarayici=tarayici, profil=profil
                    )
                    sonuclar.append(kayit)
                except Exception:
                    continue
        except Exception as e:
            self.hatalar.append(f"Cache tarama hatası: {str(e)}")
        return sonuclar
    
    def gorsel_export(self, gorsel: CacheGorsel, hedef_dizin: Optional[Path] = None) -> Optional[Path]:
        """Tek bir görseli export eder"""
        if hedef_dizin is None:
            hedef_dizin = self.export_dizini
        hedef_dizin.mkdir(parents=True, exist_ok=True)
        
        kaynak = Path(gorsel.dosya_yolu)
        if not kaynak.exists():
            return None
        
        uzanti_map = {'jpeg': '.jpg', 'png': '.png', 'gif': '.gif', 'webp': '.webp', 'bmp': '.bmp'}
        uzanti = uzanti_map.get(gorsel.format, '.bin')
        zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
        hedef = hedef_dizin / f"{gorsel.tarayici.value}_{gorsel.id}_{zaman}{uzanti}"
        
        try:
            shutil.copy2(kaynak, hedef)
            return hedef
        except Exception:
            return None
    
    def toplu_export(self, gorseller: List[CacheGorsel], hedef_dizin: Optional[Path] = None) -> List[Path]:
        """Birden fazla görseli export eder"""
        if hedef_dizin is None:
            hedef_dizin = self.export_dizini
        zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
        export_dir = hedef_dizin / f"export_{zaman}"
        export_dir.mkdir(parents=True, exist_ok=True)
        
        sonuclar = []
        for gorsel in gorseller:
            yol = self.gorsel_export(gorsel, export_dir)
            if yol:
                sonuclar.append(yol)
        return sonuclar
