# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - RaporOluşturucu

Analiz sonuçlarını HTML, CSV ve JSON formatlarında dışa aktarır.
"""

import os
import csv
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

from config.ayarlar import Ayarlar

class RaporOlusturucu:
    """Rapor ve dışa aktarım işlemlerini yönetir"""
    
    def __init__(self):
        self.rapor_dizini = Ayarlar.rapor_dizini()
        
    def html_rapor_olustur(self, veriler: Dict[str, List[Any]], meta_veri: Dict[str, Any]) -> str:
        """Kapsamlı HTML rapor oluşturur"""
        tarih_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        dosya_adi = f"AdliBilisim_Rapor_{tarih_str}.html"
        tam_yol = self.rapor_dizini / dosya_adi
        
        # CSS Stilleri
        css = """
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; color: #333; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
        h2 { color: #34495e; margin-top: 30px; border-left: 4px solid #3498db; padding-left: 10px; }
        .meta-info { background: #ecf0f1; padding: 15px; border-radius: 4px; margin-bottom: 30px; }
        .stat-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px; }
        .stat-card { background: #3498db; color: white; padding: 15px; border-radius: 4px; text-align: center; }
        .stat-value { font-size: 24px; font-weight: bold; }
        .stat-label { font-size: 12px; opacity: 0.9; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; color: #333; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .risk-high { color: red; font-weight: bold; }
        footer { margin-top: 50px; text-align: center; font-size: 11px; color: #7f8c8d; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .tabs { margin-bottom: 20px; }
        .tab-btn { padding: 10px 20px; cursor: pointer; border: none; background: #e0e0e0; margin-right: 5px; border-radius: 4px 4px 0 0; }
        .tab-btn.active { background: #3498db; color: white; }
        """
        
        # JS Scriptleri (Tablar için)
        js = """
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tab-btn");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(tabName).style.display = "block";
            evt.currentTarget.className += " active";
        }
        """
        
        # HTML İçerik Oluşturma
        html_content = [
            f"<!DOCTYPE html><html><head><meta charset='utf-8'><title>Adli Bilişim Raporu - {tarih_str}</title>",
            f"<style>{css}</style><script>{js}</script></head><body>",
            "<div class='container'>",
            f"<h1>Adli Bilişim Analiz Raporu</h1>",
            
            # Meta Veri Bölümü
            "<div class='meta-info'>",
            f"<p><strong>Oluşturma Tarihi:</strong> {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}</p>",
            f"<p><strong>Vaka/Kullanıcı:</strong> {meta_veri.get('vaka_adi', 'Varsayılan')}</p>",
            f"<p><strong>Sistem:</strong> {meta_veri.get('sistem_bilgisi', '')}</p>",
            "</div>",
            
            # Özet İstatistikler
            "<div class='stat-grid'>",
        ]
        
        for key, liste in veriler.items():
            count = len(liste)
            label = key.replace('_', ' ').title()
            html_content.append(
                f"<div class='stat-card'><div class='stat-value'>{count}</div><div class='stat-label'>{label}</div></div>"
            )
        html_content.append("</div>")
        
        # Tablar
        html_content.append("<div class='tabs'>")
        first = True
        for key in veriler.keys():
            active_cls = " active" if first else ""
            label = key.replace('_', ' ').title()
            html_content.append(f"<button class='tab-btn{active_cls}' onclick=\"openTab(event, '{key}')\">{label}</button>")
            first = False
        html_content.append("</div>")
        
        # Tab İçerikleri
        first = True
        for key, liste in veriler.items():
            active_style = "display: block;" if first else "display: none;"
            html_content.append(f"<div id='{key}' class='tab-content' style='{active_style}'>")
            html_content.append(f"<h2>{key.replace('_', ' ').title()} ({len(liste)})</h2>")
            
            if not liste:
                html_content.append("<p>Veri bulunamadı.</p>")
            else:
                html_content.append("<table><thead><tr>")
                # Başlıkları ilk elemandan al (to_dict metodunu kullanarak)
                if hasattr(liste[0], 'to_dict'):
                    sample = liste[0].to_dict()
                elif isinstance(liste[0], dict):
                    sample = liste[0]
                else:
                    sample = {}
                
                headers = list(sample.keys())[:6] # İlk 6 kolon yeterli
                for h in headers:
                    html_content.append(f"<th>{h.replace('_', ' ').title()}</th>")
                html_content.append("</tr></thead><tbody>")
                
                # Satırlar (Max 1000 satır)
                for item in liste[:1000]:
                    if hasattr(item, 'to_dict'):
                        d = item.to_dict()
                    elif isinstance(item, dict):
                        d = item
                    else:
                        d = {}
                    
                    html_content.append("<tr>")
                    for h in headers:
                        val = str(d.get(h, ''))
                        if len(val) > 100: val = val[:100] + "..."
                        html_content.append(f"<td>{val}</td>")
                    html_content.append("</tr>")
                html_content.append("</tbody></table>")
                if len(liste) > 1000:
                    html_content.append(f"<p>... ve {len(liste)-1000} kayıt daha.</p>")
            
            html_content.append("</div>")
            first = False

        html_content.append("<footer>Oluşturuldu: Adli Bilişim Forensik Aracı v1.0</footer>")
        html_content.append("</div></body></html>")
        
        try:
            with open(tam_yol, 'w', encoding='utf-8') as f:
                f.write("".join(html_content))
            return str(tam_yol)
        except Exception as e:
            return f"Hata: {str(e)}"

    def csv_export(self, veri_listesi: List[Any], dosya_adi_koku: str) -> str:
        """Veri listesini CSV olarak dışa aktarır"""
        if not veri_listesi:
            return ""
            
        tarih_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        dosya_adi = f"{dosya_adi_koku}_{tarih_str}.csv"
        tam_yol = self.rapor_dizini / dosya_adi
        
        try:
            # Sütun başlıklarını belirle
            sample = veri_listesi[0]
            if hasattr(sample, 'to_dict'):
                headers = list(sample.to_dict().keys())
            elif isinstance(sample, dict):
                headers = list(sample.keys())
            else:
                return "Veri formatı desteklenmiyor"
                
            with open(tam_yol, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(headers)
                
                for item in veri_listesi:
                    if hasattr(item, 'to_dict'):
                        d = item.to_dict()
                    elif isinstance(item, dict):
                        d = item
                    else:
                        continue
                    writer.writerow([d.get(h, '') for h in headers])
                    
            return str(tam_yol)
        except Exception as e:
            return f"CSV Hatası: {str(e)}"
