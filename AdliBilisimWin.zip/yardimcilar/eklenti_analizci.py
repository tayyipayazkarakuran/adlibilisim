# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Eklenti Analiz Modülü

Tarayıcı eklentilerini (extensions) listeler ve analiz eder.
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional
from modeller.veri_modelleri import EklentiVerisi, TarayiciTipi
from config.ayarlar import Ayarlar

class EklentiAnalizci:
    """Tarayıcı eklentilerini analiz eden sınıf"""
    
    def __init__(self):
        self.hatalar: List[str] = []
        
        # Riskli izinler
        self.riskli_izinler = [
            "all_urls", "<all_urls>", "tabs", "cookies", 
            "history", "webRequest", "webRequestBlocking",
            "proxy", "management", "debugger", "downloads"
        ]

    def eklentileri_bul(self, tarayici: str, profil_adi: str, profil_yolu: Path) -> List[EklentiVerisi]:
        """Verilen profildeki eklentileri bulur"""
        eklentiler = []
        
        try:
            # Chrome/Edge/Brave eklenti yolu
            if tarayici in ['chrome', 'edge', 'brave', 'opera']:
                extensions_path = profil_yolu / "Extensions"
                if not extensions_path.exists():
                    return []
                
                # Her bir extension ID klasörü
                for ext_id_path in extensions_path.iterdir():
                    if not ext_id_path.is_dir():
                        continue
                        
                    ext_id = ext_id_path.name
                    
                    # Versiyon klasörleri (genellikle tek bir versiyon olur)
                    if not any(ext_id_path.iterdir()):
                        continue
                        
                    # En son versiyonu al
                    versions = [p for p in ext_id_path.iterdir() if p.is_dir()]
                    if not versions:
                        continue
                        
                    latest_version_path = sorted(versions, key=lambda p: p.name, reverse=True)[0]
                    manifest_path = latest_version_path / "manifest.json"
                    
                    if manifest_path.exists():
                        veri = self._manifest_okuma(manifest_path, ext_id, tarayici, profil_adi)
                        if veri:
                            eklentiler.append(veri)
            
            # Firefox eklentileri (extensions.json içinde tutulur)
            elif tarayici == 'firefox':
                extensions_json = profil_yolu / "extensions.json"
                if extensions_json.exists():
                    eklentiler.extend(self._firefox_extensions_oku(extensions_json, profil_adi))
                    
        except Exception as e:
            self.hatalar.append(f"Eklenti tarama hatası ({tarayici} - {profil_adi}): {str(e)}")
            
        return eklentiler

    def _manifest_okuma(self, manifest_path: Path, ext_id: str, tarayici_adi: str, profil_adi: str) -> Optional[EklentiVerisi]:
        """Chrome manifest.json dosyasını okur"""
        try:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            ad = data.get('name', 'Bilinmeyen Eklenti')
            versiyon = data.get('version', '0.0')
            aciklama = data.get('description', '')
            default_locale = data.get('default_locale')

            # Yerelleştirilmiş isimleri çözme (__MSG_appName__)
            if ad.startswith('__MSG_') and default_locale:
                locales_path = manifest_path.parent / "_locales" / default_locale / "messages.json"
                if locales_path.exists():
                    try:
                        with open(locales_path, 'r', encoding='utf-8') as lf:
                            msgs = json.load(lf)
                            key = ad.replace('__MSG_', '').replace('__', '')
                            if key in msgs:
                                ad = msgs[key].get('message', ad)
                            
                            if aciklama.startswith('__MSG_'):
                                key_desc = aciklama.replace('__MSG_', '').replace('__', '')
                                if key_desc in msgs:
                                    aciklama = msgs[key_desc].get('message', aciklama)
                    except:
                        pass

            permissions = data.get('permissions', [])
            
            # Risk analizi
            risk_skoru = 0
            risk_detaylari = []
            
            for perm in permissions:
                if perm in self.riskli_izinler:
                    risk_skoru += 10
                    risk_detaylari.append(f"Riskli İzin: {perm}")
            
            if len(permissions) > 10:
                risk_skoru += 10
                risk_detaylari.append("Çok fazla izin talebi")
            
            risk_skoru = min(100, risk_skoru)
            
            # Tarih (dosya oluşturulma tarihi)
            try:
                ts = manifest_path.stat().st_birthtime
                kurulum_tarihi = datetime.fromtimestamp(ts)
            except:
                kurulum_tarihi = datetime.now()

            return EklentiVerisi(
                id=0, # Sonradan atanacak
                ad=ad,
                kimlik=ext_id,
                versiyon=versiyon,
                aciklama=aciklama,
                izinler=permissions,
                kurulum_tarihi=kurulum_tarihi,
                aktif=True, # Genellikle klasör varsa aktiftir
                tarayici=TarayiciTipi(tarayici_adi),
                profil=profil_adi,
                risk_skoru=risk_skoru,
                risk_detaylari=risk_detaylari
            )
        except Exception as e:
            # self.hatalar.append(f"Manifest okuma hatası: {str(e)}")
            return None

    def _firefox_extensions_oku(self, json_path: Path, profil_adi: str) -> List[EklentiVerisi]:
        """Firefox extensions.json dosyasını okur"""
        eklentiler = []
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            addons = data.get('addons', [])
            for addon in addons:
                if addon.get('location') == 'app-profile': # Sadece kullanıcı tarafından yüklenenler
                    ad = addon.get('defaultLocale', {}).get('name') or addon.get('name', 'Adsız')
                    ext_id = addon.get('id', '')
                    versiyon = addon.get('version', '')
                    aciklama = addon.get('defaultLocale', {}).get('description') or addon.get('description', '')
                    permissions = addon.get('permissions', [])
                    active = addon.get('active', False)
                    
                    # Tarih
                    update_date = addon.get('updateDate') # Milliseconds
                    kurulum_tarihi = None
                    if update_date:
                        try:
                            kurulum_tarihi = datetime.fromtimestamp(update_date / 1000)
                        except:
                            pass
                    
                    # Risk
                    risk_skoru = 0
                    risk_detaylari = []
                    for perm in permissions:
                        if perm in self.riskli_izinler:
                            risk_skoru += 10
                            risk_detaylari.append(f"Riskli İzin: {perm}")
                    
                    eklentiler.append(EklentiVerisi(
                        id=0,
                        ad=ad,
                        kimlik=ext_id,
                        versiyon=versiyon,
                        aciklama=aciklama or "",
                        izinler=permissions,
                        kurulum_tarihi=kurulum_tarihi,
                        aktif=active,
                        tarayici=TarayiciTipi.FIREFOX,
                        profil=profil_adi,
                        risk_skoru=risk_skoru,
                        risk_detaylari=risk_detaylari
                    ))
        except Exception as e:
            self.hatalar.append(f"Firefox eklenti okuma hatası: {str(e)}")
            
        return eklentiler
