# AdliBilisim Task Status

## 1. UI Fixes (Completed)
- [x] Fix `TypeError` in all Dropdowns.

## 2. Feature Enhancements (Completed)
- [x] macOS Password Decryption (Keychain access).
- [x] Cache Image Previews.

## 3. New Features (Completed)
- [x] **Reporting System:**
    - HTML Report generation.
    - CSV/JSON Export options.
- [x] **Timeline Analysis:**
    - Created `ZamanCizelgesiSayfasi`.
    - Integrated history, cookies, downloads, media, cache into a unified timeline.
- [x] **Global Search:**
    - Created `GenelAramaSayfasi` searching across all data types.
- [x] **Browser Extensions:**
    - Created `EklentiAnalizci` to parse `manifest.json`.
    - Created `EklentilerSayfasi` with risk analysis (permutations analysis).
- [x] **System Integration:**
    - USB History (macOS `ioreg` implementation) added to `ForensikSayfasi`.
    - Downloaded file existence check logic added.

## 4. Optimization (Completed)
- [x] Parallel processing in `main.py` updated to include new tasks.
