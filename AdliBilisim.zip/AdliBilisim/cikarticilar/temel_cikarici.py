"""
Adli Bilişim Forensik Aracı - Temel Çıkarıcı Sınıfı

Tüm tarayıcı çıkarıcıları için temel soyut sınıf.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from pathlib import Path
from datetime import datetime
import sqlite3
import shutil
import tempfile
import os

from modeller.veri_modelleri import (
    TarayiciGecmisi,
    Cerez,
    IndirilenDosya,
    KayitliSifre,
    FormVerisi,
    CacheGorsel,
    TarayiciTipi,
    OturumVerisi,
    LocalStorageVerisi,
    SilinenKayit,
    OtomatikDoldurma,
    MedyaGecmisi,
    DosyaErisimi,
    SilmeGirisimi,
    ServiceWorkerCache
)
from config.ayarlar import Ayarlar


class TemelCikarici(ABC):
    """
    Tüm tarayıcı çıkarıcıları için temel soyut sınıf.
    
    Her tarayıcı çıkarıcısı bu sınıftan türemeli ve
    soyut metodları implemente etmelidir.
    """
    
    def __init__(self, tarayici_tipi: TarayiciTipi):
        """
        Temel çıkarıcı başlatıcı
        
        Args:
            tarayici_tipi: Tarayıcı tipi enum değeri
        """
        self.tarayici_tipi = tarayici_tipi
        self.profil_yolu: Optional[Path] = None
        self.hatalar: List[str] = []
        
    @property
    def tarayici_adi(self) -> str:
        """Tarayıcının görünen adını döndürür"""
        return self.tarayici_tipi.gorunen_ad
    
    @abstractmethod
    def profil_yolu_bul(self) -> Optional[Path]:
        """
        Tarayıcı profil dizinini bulur
        
        Returns:
            Profil dizin yolu veya None (bulunamazsa)
        """
        pass
    
    @abstractmethod
    def profilleri_listele(self) -> List[str]:
        """
        Mevcut profilleri listeler
        
        Returns:
            Profil adları listesi
        """
        pass
    
    @abstractmethod
    def gecmis_cikart(self, profil: str = "Default") -> List[TarayiciGecmisi]:
        """
        Tarayıcı geçmişini çıkarır
        
        Args:
            profil: Profil adı
            
        Returns:
            Tarayıcı geçmişi kayıtları listesi
        """
        pass
    
    @abstractmethod
    def cerezleri_cikart(self, profil: str = "Default") -> List[Cerez]:
        """
        Çerezleri çıkarır
        
        Args:
            profil: Profil adı
            
        Returns:
            Çerez kayıtları listesi
        """
        pass
    
    @abstractmethod
    def indirmeleri_cikart(self, profil: str = "Default") -> List[IndirilenDosya]:
        """
        İndirme geçmişini çıkarır
        
        Args:
            profil: Profil adı
            
        Returns:
            İndirilen dosya kayıtları listesi
        """
        pass
    
    @abstractmethod
    def sifreleri_cikart(self, profil: str = "Default") -> List[KayitliSifre]:
        """
        Kayıtlı şifreleri çıkarır
        
        Args:
            profil: Profil adı
            
        Returns:
            Kayıtlı şifre kayıtları listesi
        """
        pass
    
    @abstractmethod
    def form_verilerini_cikart(self, profil: str = "Default") -> List[FormVerisi]:
        """
        Form verilerini çıkarır
        
        Args:
            profil: Profil adı
            
        Returns:
            Form verisi kayıtları listesi
        """
        pass
    
    def cache_gorselleri_cikart(self, profil: str = "Default") -> List[CacheGorsel]:
        """
        Cache görsellerini çıkarır (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            Cache görsel kayıtları listesi
        """
        return []
    
    def oturum_cikart(self, profil: str = "Default") -> List[OturumVerisi]:
        """
        Oturum/sekme verilerini çıkarır (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            Oturum verisi kayıtları listesi
        """
        return []
    
    def local_storage_cikart(self, profil: str = "Default") -> List[LocalStorageVerisi]:
        """
        LocalStorage/IndexedDB verilerini çıkarır (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            LocalStorage verisi kayıtları listesi
        """
        return []
    
    def silinen_verileri_kurtar(self, profil: str = "Default") -> List[SilinenKayit]:
        """
        SQLite veritabanlarından silinmiş verileri kurtarır (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            Silinmiş kayıt listesi
        """
        return []
    
    def otomatik_doldurma_cikart(self, profil: str = "Default") -> List[OtomatikDoldurma]:
        """
        Otomatik doldurma verilerini çıkarır (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            Otomatik doldurma verisi listesi
        """
        return []
    
    def medya_gecmisi_cikart(self, profil: str = "Default") -> List[MedyaGecmisi]:
        """
        Medya geçmişini çıkarır (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            Medya geçmişi listesi
        """
        return []
    
    def silme_girisimi_tespit(self, profil: str = "Default") -> List[SilmeGirisimi]:
        """
        Silme girişimlerini tespit eder (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            Silme girişimi listesi
        """
        return []
    
    def service_worker_cache_cikart(self, profil: str = "Default") -> List[ServiceWorkerCache]:
        """
        Service Worker cache verilerini çıkarır (opsiyonel override)
        
        Args:
            profil: Profil adı
            
        Returns:
            Service Worker cache listesi
        """
        return []
    
    def tarayici_kurulu_mu(self) -> bool:
        """
        Tarayıcının kurulu olup olmadığını kontrol eder
        
        Returns:
            Kurulu ise True, değilse False
        """
        yol = self.profil_yolu_bul()
        return yol is not None and yol.exists()
    
    def veritabani_kopyala(self, db_yolu: Path) -> Optional[Path]:
        """
        SQLite veritabanını geçici dizine kopyalar.
        Tarayıcı çalışırken veritabanı kilitli olabileceği için
        kopyalama yapılır.
        
        Args:
            db_yolu: Orijinal veritabanı yolu
            
        Returns:
            Geçici kopya yolu veya None (hata durumunda)
        """
        if not db_yolu.exists():
            self.hatalar.append(f"Veritabanı bulunamadı: {db_yolu}")
            return None
        
        try:
            # Geçici dosya oluştur
            gecici_dosya = tempfile.NamedTemporaryFile(
                delete=False,
                suffix='.db'
            )
            gecici_yol = Path(gecici_dosya.name)
            gecici_dosya.close()
            
            # Windows için dosya kilitleme sorunlarını ele al
            # Birkaç deneme yap
            import time
            for deneme in range(3):
                try:
                    # Kopyala
                    shutil.copy2(db_yolu, gecici_yol)
                    return gecici_yol
                except (PermissionError, OSError) as e:
                    if deneme < 2:  # Son deneme değilse bekle
                        time.sleep(0.1)  # 100ms bekle
                        continue
                    else:  # Son denemede de başarısız oldu
                        raise
            
        except PermissionError as e:
            # Windows'ta dosya kilitli hatası
            self.hatalar.append(f"Veritabanı kilitli (tarayıcı çalışıyor olabilir): {db_yolu}")
            return None
        except Exception as e:
            self.hatalar.append(f"Veritabanı kopyalama hatası: {str(e)}")
            return None
    
    def gecici_dosya_temizle(self, dosya_yolu: Path):
        """
        Geçici dosyayı temizler
        
        Args:
            dosya_yolu: Silinecek dosya yolu
        """
        try:
            if dosya_yolu.exists():
                os.unlink(dosya_yolu)
        except Exception:
            pass  # Temizleme hatasını yoksay
    
    def sqlite_oku(self, db_yolu: Path, sorgu: str) -> List[tuple]:
        """
        SQLite veritabanından sorgu çalıştırır
        
        Args:
            db_yolu: Veritabanı yolu
            sorgu: SQL sorgusu
            
        Returns:
            Sorgu sonuç satırları
        """
        gecici_yol = self.veritabani_kopyala(db_yolu)
        if gecici_yol is None:
            return []
        
        try:
            conn = sqlite3.connect(str(gecici_yol))
            cursor = conn.cursor()
            cursor.execute(sorgu)
            sonuclar = cursor.fetchall()
            conn.close()
            return sonuclar
            
        except sqlite3.Error as e:
            self.hatalar.append(f"SQLite hatası: {str(e)}")
            return []
            
        finally:
            self.gecici_dosya_temizle(gecici_yol)
    
    def chrome_zamani_cevir(self, chrome_zaman: int) -> datetime:
        """
        Chrome/Chromium zaman damgasını datetime'a çevirir.
        Chrome 1601-01-01'den itibaren mikrosaniye kullanır.
        
        Args:
            chrome_zaman: Chrome zaman damgası
            
        Returns:
            datetime nesnesi
        """
        if chrome_zaman == 0:
            return datetime.min
        
        try:
            # Chrome zamanı: 1601-01-01'den itibaren mikrosaniye
            # Unix zamanına çevir (1970-01-01)
            timestamp = (chrome_zaman - Ayarlar.CHROME_EPOCH_FARKI) / 1_000_000
            return datetime.fromtimestamp(timestamp)
        except (ValueError, OSError):
            return datetime.min
    
    def webkit_zamani_cevir(self, webkit_zaman: float) -> datetime:
        """
        WebKit zaman damgasını datetime'a çevirir.
        Safari 2001-01-01'den itibaren saniye kullanır.
        
        Args:
            webkit_zaman: WebKit zaman damgası
            
        Returns:
            datetime nesnesi
        """
        if webkit_zaman == 0:
            return datetime.min
        
        try:
            timestamp = webkit_zaman + Ayarlar.WEBKIT_EPOCH_FARKI
            return datetime.fromtimestamp(timestamp)
        except (ValueError, OSError):
            return datetime.min
    
    def firefox_zamani_cevir(self, firefox_zaman: int) -> datetime:
        """
        Firefox zaman damgasını datetime'a çevirir.
        Firefox mikrosaniye cinsinden Unix zamanı kullanır.
        
        Args:
            firefox_zaman: Firefox zaman damgası
            
        Returns:
            datetime nesnesi
        """
        if firefox_zaman == 0:
            return datetime.min
        
        try:
            timestamp = firefox_zaman / 1_000_000
            return datetime.fromtimestamp(timestamp)
        except (ValueError, OSError):
            return datetime.min
    
    def tum_verileri_cikart(self, profil: str = "Default") -> Dict[str, Any]:
        """
        Tüm verileri tek seferde çıkarır
        
        Args:
            profil: Profil adı
            
        Returns:
            Tüm veriler dictionary olarak
        """
        return {
            "gecmis": self.gecmis_cikart(profil),
            "cerezler": self.cerezleri_cikart(profil),
            "indirmeler": self.indirmeleri_cikart(profil),
            "sifreler": self.sifreleri_cikart(profil),
            "form_verileri": self.form_verilerini_cikart(profil),
            "cache_gorseller": self.cache_gorselleri_cikart(profil),
            "hatalar": self.hatalar.copy()
        }
