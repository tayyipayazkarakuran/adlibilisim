"""
Adli Bilişim Forensik Aracı - Brave Veri Çıkarıcı

Brave tarayıcısından veri çıkarma modülü.
Brave Chromium tabanlı olduğu için Chrome çıkarıcısını temel alır.
"""

from typing import List, Optional
from pathlib import Path

from .chrome_cikarici import ChromeCikarici
from modeller.veri_modelleri import TarayiciTipi
from config.ayarlar import Ayarlar


class BraveCikarici(ChromeCikarici):
    """Brave tarayıcısı için veri çıkarıcı"""
    
    def __init__(self):
        super(ChromeCikarici, self).__init__(TarayiciTipi.BRAVE)
        # Şifre çözücüyü başlat (ChromeCikarici.__init__ çağrılmadığı için)
        from yardimcilar.sifre_cozucu import SifreCozucu
        self.sifre_cozucu = SifreCozucu()
    
    def profil_yolu_bul(self) -> Optional[Path]:
        """Brave profil dizinini bulur"""
        try:
            yol = Ayarlar.tarayici_yolu_al('brave')
            if yol.exists():
                self.profil_yolu = yol
                return yol
            return None
        except Exception as e:
            self.hatalar.append(f"Profil yolu bulunamadı: {str(e)}")
            return None
