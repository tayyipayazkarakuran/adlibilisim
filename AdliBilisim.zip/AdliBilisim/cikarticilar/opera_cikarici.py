"""
Adli Bilişim Forensik Aracı - Opera Veri Çıkarıcı

Opera tarayıcısından veri çıkarma modülü.
Opera Chromium tabanlı olduğu için Chrome çıkarıcısını temel alır.
"""

from typing import List, Optional
from pathlib import Path

from .chrome_cikarici import ChromeCikarici
from modeller.veri_modelleri import TarayiciTipi
from config.ayarlar import Ayarlar


class OperaCikarici(ChromeCikarici):
    """Opera tarayıcısı için veri çıkarıcı"""
    
    def __init__(self):
        super(ChromeCikarici, self).__init__(TarayiciTipi.OPERA)
        # Şifre çözücüyü başlat (ChromeCikarici.__init__ çağrılmadığı için)
        from yardimcilar.sifre_cozucu import SifreCozucu
        self.sifre_cozucu = SifreCozucu()
    
    def profil_yolu_bul(self) -> Optional[Path]:
        """Opera profil dizinini bulur"""
        try:
            yol = Ayarlar.tarayici_yolu_al('opera')
            if yol.exists():
                self.profil_yolu = yol
                return yol
            return None
        except Exception as e:
            self.hatalar.append(f"Profil yolu bulunamadı: {str(e)}")
            return None
    
    def profilleri_listele(self) -> List[str]:
        """Opera profillerini listeler"""
        profiller = []
        yol = self.profil_yolu_bul()
        
        if yol is None:
            return profiller
        
        # Opera genellikle tek profil kullanır
        if yol.exists():
            profiller.append("Default")
        
        return profiller
    
    def _profil_dizini(self, profil: str = "Default") -> Optional[Path]:
        """Opera profil dizinini döndürür"""
        yol = self.profil_yolu_bul()
        if yol is None:
            return None
        
        # Opera profilleri doğrudan ana dizinde
        if yol.exists():
            return yol
        
        return None
