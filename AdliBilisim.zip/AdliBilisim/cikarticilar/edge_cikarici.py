"""
Adli Bilişim Forensik Aracı - Edge Veri Çıkarıcı

Microsoft Edge tarayıcısından veri çıkarma modülü.
Edge Chromium tabanlı olduğu için Chrome çıkarıcısını temel alır.
"""

from typing import List, Optional
from pathlib import Path

from .chrome_cikarici import ChromeCikarici
from modeller.veri_modelleri import TarayiciTipi
from config.ayarlar import Ayarlar


class EdgeCikarici(ChromeCikarici):
    """Microsoft Edge tarayıcısı için veri çıkarıcı"""
    
    def __init__(self):
        # ChromeCikarici'yı atla, doğrudan TemelCikarici'yı başlat
        super(ChromeCikarici, self).__init__(TarayiciTipi.EDGE)
        # Şifre çözücüyü başlat (ChromeCikarici.__init__ çağrılmadığı için)
        from yardimcilar.sifre_cozucu import SifreCozucu
        self.sifre_cozucu = SifreCozucu()
    
    def profil_yolu_bul(self) -> Optional[Path]:
        """Edge profil dizinini bulur"""
        try:
            yol = Ayarlar.tarayici_yolu_al('edge')
            if yol.exists():
                self.profil_yolu = yol
                return yol
            return None
        except Exception as e:
            self.hatalar.append(f"Profil yolu bulunamadı: {str(e)}")
            return None
