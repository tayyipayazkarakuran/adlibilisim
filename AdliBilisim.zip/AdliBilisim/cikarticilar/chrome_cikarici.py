"""
Adli Bilişim Forensik Aracı - Chrome Veri Çıkarıcı

Google Chrome tarayıcısından veri çıkarma modülü.
Chromium tabanlı diğer tarayıcılar için de temel oluşturur.
"""

from typing import List, Optional
from pathlib import Path
from datetime import datetime
import json
import os
import sys

from .temel_cikarici import TemelCikarici
from modeller.veri_modelleri import (
    TarayiciGecmisi,
    Cerez,
    IndirilenDosya,
    KayitliSifre,
    FormVerisi,
    CacheGorsel,
    TarayiciTipi,
    OturumVerisi,
    LocalStorageVerisi,
    SilinenKayit,
    OtomatikDoldurma,
    MedyaGecmisi,
    SilmeGirisimi,
    ServiceWorkerCache
)
from config.ayarlar import Ayarlar
from yardimcilar.sifre_cozucu import SifreCozucu
from yardimcilar.local_storage_okuyucu import LocalStorageOkuyucu
from yardimcilar.sqlite_kurtarici import SQLiteKurtarici
from yardimcilar.forensik_analizci import OtomatikDoldurmaOkuyucu, MedyaGecmisiOkuyucu, ForensikAnalizci


class ChromeCikarici(TemelCikarici):
    """Google Chrome tarayıcısı için veri çıkarıcı"""
    
    def __init__(self):
        super().__init__(TarayiciTipi.CHROME)
        self.sifre_cozucu = SifreCozucu()
    
    def profil_yolu_bul(self) -> Optional[Path]:
        """Chrome profil dizinini bulur"""
        try:
            yol = Ayarlar.tarayici_yolu_al('chrome')
            if yol.exists():
                self.profil_yolu = yol
                return yol
            return None
        except Exception as e:
            self.hatalar.append(f"Profil yolu bulunamadı: {str(e)}")
            return None
    
    def profilleri_listele(self) -> List[str]:
        """Mevcut Chrome profillerini listeler"""
        profiller = []
        yol = self.profil_yolu_bul()
        
        if yol is None:
            return profiller
        
        # Default profil
        default_yol = yol / "Default"
        if default_yol.exists():
            profiller.append("Default")
        
        # Diğer profiller (Profile 1, Profile 2, vb.)
        for item in yol.iterdir():
            if item.is_dir() and item.name.startswith("Profile "):
                profiller.append(item.name)
        
        return profiller
    
    def _profil_dizini(self, profil: str) -> Optional[Path]:
        """Belirtilen profilin dizin yolunu döndürür"""
        yol = self.profil_yolu_bul()
        if yol is None:
            return None
        
        profil_yolu = yol / profil
        if profil_yolu.exists():
            return profil_yolu
        return None
    
    def gecmis_cikart(self, profil: str = "Default") -> List[TarayiciGecmisi]:
        """Chrome tarayıcı geçmişini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            self.hatalar.append(f"Profil bulunamadı: {profil}")
            return sonuclar
        
        db_yolu = profil_dizini / Ayarlar.CHROME_GECMIS_DB
        
        if not db_yolu.exists():
            self.hatalar.append(f"Geçmiş veritabanı bulunamadı: {db_yolu}")
            return sonuclar
        
        sorgu = """
            SELECT 
                urls.id,
                urls.url,
                urls.title,
                visits.visit_time,
                urls.visit_count
            FROM urls
            JOIN visits ON urls.id = visits.url
            ORDER BY visits.visit_time ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                kayit = TarayiciGecmisi(
                    id=satir[0],
                    url=satir[1] or "",
                    baslik=satir[2] or "(Başlıksız)",
                    ziyaret_tarihi=self.chrome_zamani_cevir(satir[3] or 0),
                    ziyaret_sayisi=satir[4] or 1,
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Geçmiş kaydı işleme hatası: {str(e)}")
        
        return sonuclar
    
    def cerezleri_cikart(self, profil: str = "Default") -> List[Cerez]:
        """Chrome çerezlerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        # Chrome 96+ sürümlerinde Cookies dosyası "Network" klasöründe
        db_yolu = profil_dizini / "Network" / Ayarlar.CHROME_CEREZ_DB
        
        if not db_yolu.exists():
            # Eski Chrome sürümleri için
            db_yolu = profil_dizini / Ayarlar.CHROME_CEREZ_DB
        
        if not db_yolu.exists():
            self.hatalar.append(f"Çerez veritabanı bulunamadı")
            return sonuclar
        
        sorgu = """
            SELECT 
                rowid,
                name,
                value,
                host_key,
                path,
                creation_utc,
                last_access_utc,
                expires_utc,
                is_secure,
                is_httponly
            FROM cookies
            ORDER BY creation_utc ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                son_kullanma = None
                if satir[7] and satir[7] > 0:
                    son_kullanma = self.chrome_zamani_cevir(satir[7])
                
                kayit = Cerez(
                    id=satir[0],
                    ad=satir[1] or "",
                    deger=satir[2] or "",
                    domain=satir[3] or "",
                    yol=satir[4] or "/",
                    olusturma_tarihi=self.chrome_zamani_cevir(satir[5] or 0),
                    son_erisim_tarihi=self.chrome_zamani_cevir(satir[6] or 0),
                    son_kullanma_tarihi=son_kullanma,
                    guvenli=bool(satir[8]),
                    http_only=bool(satir[9]),
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Çerez kaydı işleme hatası: {str(e)}")
        
        return sonuclar
    
    def indirmeleri_cikart(self, profil: str = "Default") -> List[IndirilenDosya]:
        """Chrome indirme geçmişini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        db_yolu = profil_dizini / Ayarlar.CHROME_GECMIS_DB
        
        if not db_yolu.exists():
            return sonuclar
        
        sorgu = """
            SELECT 
                downloads.id,
                downloads.target_path,
                downloads.tab_url,
                downloads.start_time,
                downloads.end_time,
                downloads.total_bytes,
                downloads.state
            FROM downloads
            ORDER BY downloads.start_time ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                # Durum değerini çevir
                durum_map = {
                    0: "devam_ediyor",
                    1: "tamamlandi",
                    2: "iptal_edildi",
                    3: "iptal_edildi",
                    4: "devam_ediyor"
                }
                durum = durum_map.get(satir[6], "bilinmiyor")
                
                dosya_yolu = satir[1] or ""
                dosya_adi = os.path.basename(dosya_yolu) if dosya_yolu else "bilinmiyor"
                
                bitis_tarihi = None
                if satir[4] and satir[4] > 0:
                    bitis_tarihi = self.chrome_zamani_cevir(satir[4])
                
                kayit = IndirilenDosya(
                    id=satir[0],
                    dosya_adi=dosya_adi,
                    dosya_yolu=dosya_yolu,
                    kaynak_url=satir[2] or "",
                    baslangic_tarihi=self.chrome_zamani_cevir(satir[3] or 0),
                    bitis_tarihi=bitis_tarihi,
                    dosya_boyutu=satir[5] or 0,
                    durum=durum,
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"İndirme kaydı işleme hatası: {str(e)}")
        
        return sonuclar
    
    def sifreleri_cikart(self, profil: str = "Default") -> List[KayitliSifre]:
        """Chrome kayıtlı şifrelerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        db_yolu = profil_dizini / Ayarlar.CHROME_LOGIN_DB
        
        if not db_yolu.exists():
            self.hatalar.append(f"Şifre veritabanı bulunamadı")
            return sonuclar
        
        sorgu = """
            SELECT 
                rowid,
                origin_url,
                username_value,
                password_value,
                date_created,
                date_last_used
            FROM logins
            ORDER BY date_created ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        # Şifreleme anahtarını al (bir kez al, tüm şifreler için kullan)
        sifreleme_anahtari = None
        try:
            # Chrome v80+ için anahtar gerekli
            yol = self.profil_yolu_bul()
            if yol:
                local_state_yolu = yol / "Local State"
                if local_state_yolu.exists():
                    sifreleme_anahtari = self.sifre_cozucu.chrome_anahtar_al(local_state_yolu)
        except Exception as e:
            self.hatalar.append(f"Şifreleme anahtarı alınamadı: {str(e)}")
        
        for satir in satirlar:
            try:
                olusturma = None
                if satir[4] and satir[4] > 0:
                    olusturma = self.chrome_zamani_cevir(satir[4])
                
                son_kullanim = None
                if satir[5] and satir[5] > 0:
                    son_kullanim = self.chrome_zamani_cevir(satir[5])
                
                # Şifreyi çöz
                sifre_sifreli = satir[3] or b""
                sifre_cozulmus = None
                
                if sifre_sifreli:
                    try:
                        sifre_cozulmus = self.sifre_cozucu.chrome_sifre_coz(sifre_sifreli, sifreleme_anahtari)
                        if sifre_cozulmus is None and self.sifre_cozucu.hatalar:
                            # Hata varsa logla ama devam et
                            pass
                    except Exception as e:
                        self.hatalar.append(f"Şifre çözme hatası: {str(e)}")
                
                kayit = KayitliSifre(
                    id=satir[0],
                    site_url=satir[1] or "",
                    kullanici_adi=satir[2] or "",
                    sifre_sifreli=sifre_sifreli,
                    sifre_cozulmus=sifre_cozulmus,
                    olusturma_tarihi=olusturma,
                    son_kullanim_tarihi=son_kullanim,
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Şifre kaydı işleme hatası: {str(e)}")
        
        # Şifre çözücü hatalarını ekle
        if self.sifre_cozucu.hatalar:
            self.hatalar.extend([f"Şifre çözücü: {h}" for h in self.sifre_cozucu.hatalar])
        
        return sonuclar
    
    def form_verilerini_cikart(self, profil: str = "Default") -> List[FormVerisi]:
        """Chrome form verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        db_yolu = profil_dizini / Ayarlar.CHROME_WEB_DATA_DB
        
        if not db_yolu.exists():
            self.hatalar.append(f"Web Data veritabanı bulunamadı")
            return sonuclar
        
        sorgu = """
            SELECT 
                rowid,
                name,
                value,
                count,
                date_last_used
            FROM autofill
            ORDER BY date_last_used ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                son_kullanim = None
                if satir[4] and satir[4] > 0:
                    son_kullanim = self.chrome_zamani_cevir(satir[4])
                
                kayit = FormVerisi(
                    id=satir[0],
                    alan_adi=satir[1] or "",
                    deger=satir[2] or "",
                    kullanim_sayisi=satir[3] or 1,
                    son_kullanim_tarihi=son_kullanim,
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Form verisi işleme hatası: {str(e)}")
        
        return sonuclar
    
    def cache_gorselleri_cikart(self, profil: str = "Default") -> List[CacheGorsel]:
        """Chrome cache görsellerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        # Olası cache dizinleri
        cache_dizinleri = []
        
        # 1. Profil içindeki Cache
        cache_dizinleri.append(profil_dizini / "Cache" / "Cache_Data")
        cache_dizinleri.append(profil_dizini / "Cache")
        
        # 2. macOS için özel cache yolu (~/Library/Caches/Google/Chrome/...)
        if Ayarlar.isletim_sistemi() == "macos":
             # Profil adından Cache klasörü adını çıkar (Default -> Default, Profile 1 -> Profile 1)
             profil_adi = profil_dizini.name
             macos_cache_base = Ayarlar.kullanici_dizini() / "Library" / "Caches" / "Google" / "Chrome"
             
             cache_dizinleri.append(macos_cache_base / profil_adi / "Cache" / "Cache_Data")
             cache_dizinleri.append(macos_cache_base / profil_adi / "Cache")
        
        gorsel_id = 0
        gorsel_uzantilar = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.ico'}
        
        taranan_dosyalar = set() # Duplicate önlemek için
        
        for cache_dizini in cache_dizinleri:
            if not cache_dizini.exists():
                continue
                
            try:
                # Cache dizinini tara
                for dosya in cache_dizini.iterdir():
                    if not dosya.is_file():
                        continue
                        
                    # Aynı dosyayı tekrar işleme (farklı yollarda aynı dosya olabilir)
                    dosya_ab = str(dosya.absolute())
                    if dosya_ab in taranan_dosyalar:
                        continue
                    taranan_dosyalar.add(dosya_ab)
                    
                    try:
                        # Dosya boyutu kontrol
                        if dosya.stat().st_size < 16:
                            continue

                        with open(dosya, 'rb') as f:
                            header = f.read(16)
                        
                        format_turu = None
                        
                        # Magic bytes kontrolü
                        if header.startswith(b'\xff\xd8\xff'):
                            format_turu = 'jpeg'
                        elif header.startswith(b'\x89PNG'):
                            format_turu = 'png'
                        elif header.startswith(b'GIF'):
                            format_turu = 'gif'
                        elif header.startswith(b'RIFF') and b'WEBP' in header:
                            format_turu = 'webp'
                        elif header.startswith(b'BM'):
                            format_turu = 'bmp'
                        
                        if format_turu:
                            gorsel_id += 1
                            stat = dosya.stat()
                            
                            kayit = CacheGorsel(
                                id=gorsel_id,
                                dosya_yolu=str(dosya),
                                kaynak_url=None,
                                dosya_boyutu=stat.st_size,
                                genislik=None,
                                yukseklik=None,
                                format=format_turu,
                                olusturma_tarihi=datetime.fromtimestamp(stat.st_mtime),
                                tarayici=self.tarayici_tipi,
                                profil=profil
                            )
                            sonuclar.append(kayit)
                    except Exception:
                        continue
            except Exception as e:
                self.hatalar.append(f"Cache tarama hatası ({cache_dizini}): {str(e)}")
        
        return sonuclar
    
    def sifreleme_anahtari_al(self, profil: str = "Default") -> Optional[bytes]:
        """
        Chrome şifreleme anahtarını alır (Windows DPAPI için).
        Bu metod sifre_cozucu modülünde kullanılır.
        """
        yol = self.profil_yolu_bul()
        if yol is None:
            return None
        
        local_state_yolu = yol / "Local State"
        
        if not local_state_yolu.exists():
            return None
        
        try:
            with open(local_state_yolu, 'r', encoding='utf-8') as f:
                local_state = json.load(f)
            
            # Şifrelenmiş anahtar
            encrypted_key = local_state.get('os_crypt', {}).get('encrypted_key')
            
            if encrypted_key:
                import base64
                encrypted_key = base64.b64decode(encrypted_key)
                # 'DPAPI' prefix'ini kaldır
                if encrypted_key.startswith(b'DPAPI'):
                    encrypted_key = encrypted_key[5:]
                return encrypted_key
            
            return None
        except Exception as e:
            self.hatalar.append(f"Şifreleme anahtarı alınamadı: {str(e)}")
            return None
    
    def oturum_cikart(self, profil: str = "Default") -> List[OturumVerisi]:
        """Chrome oturum/sekme verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        # Current Session ve Current Tabs dosyalarını kontrol et
        session_dosyalari = [
            profil_dizini / "Current Session",
            profil_dizini / "Current Tabs",
            profil_dizini / "Last Session",
            profil_dizini / "Last Tabs"
        ]
        
        sekme_id = 0
        
        for session_dosya in session_dosyalari:
            if not session_dosya.exists():
                continue
            
            try:
                with open(session_dosya, 'rb') as f:
                    icerik = f.read()
                
                # URL'leri ve başlıkları ara
                # SNSS formatında URL'ler metin olarak saklanır
                url_kaliplari = [b'http://', b'https://']
                
                for kalip in url_kaliplari:
                    pos = 0
                    while True:
                        idx = icerik.find(kalip, pos)
                        if idx == -1:
                            break
                        
                        # URL sonunu bul
                        end = idx
                        for i in range(idx, min(idx + 2048, len(icerik))):
                            byte = icerik[i]
                            if byte < 32 or byte > 126:
                                end = i
                                break
                            end = i + 1
                        
                        if end > idx + 10:
                            try:
                                url = icerik[idx:end].decode('utf-8', errors='ignore')
                                if self._gecerli_url_mi(url):
                                    sekme_id += 1
                                    kayit = OturumVerisi(
                                        id=sekme_id,
                                        url=url,
                                        baslik=self._baslik_cikart(url),
                                        son_erisim=datetime.fromtimestamp(session_dosya.stat().st_mtime),
                                        tarayici=self.tarayici_tipi,
                                        profil=profil
                                    )
                                    # Tekrar eden URL'leri kontrol et
                                    if not any(s.url == url for s in sonuclar):
                                        sonuclar.append(kayit)
                            except:
                                pass
                        
                        pos = end
                        
            except Exception as e:
                self.hatalar.append(f"Oturum dosyası okuma hatası: {str(e)}")
        
        return sonuclar
    
    def _gecerli_url_mi(self, url: str) -> bool:
        """URL'nin geçerli olup olmadığını kontrol eder"""
        if len(url) < 10 or len(url) > 2048:
            return False
        if not url.startswith(('http://', 'https://')):
            return False
        # Chrome dahili sayfalarını atla
        if 'chrome://' in url or 'chrome-extension://' in url:
            return False
        return True
    
    def _baslik_cikart(self, url: str) -> str:
        """URL'den basit bir başlık çıkarır"""
        from urllib.parse import urlparse
        try:
            parsed = urlparse(url)
            return parsed.netloc or url[:50]
        except:
            return url[:50]
    
    def local_storage_cikart(self, profil: str = "Default") -> List[LocalStorageVerisi]:
        """Chrome LocalStorage verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        try:
            okuyucu = LocalStorageOkuyucu()
            
            # LocalStorage
            ls_veriler = okuyucu.chrome_local_storage_oku(profil_dizini)
            
            for idx, veri in enumerate(ls_veriler):
                kayit = LocalStorageVerisi(
                    id=idx + 1,
                    origin=veri.get('origin', ''),
                    anahtar=veri.get('anahtar', ''),
                    deger=veri.get('deger', ''),
                    boyut=veri.get('boyut', 0),
                    veri_tipi=veri.get('kaynak', 'localStorage'),
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            
            # IndexedDB
            idb_veriler = okuyucu.indexeddb_oku(profil_dizini, 'chrome')
            
            for idx, veri in enumerate(idb_veriler):
                kayit = LocalStorageVerisi(
                    id=len(sonuclar) + idx + 1,
                    origin=veri.get('origin', ''),
                    anahtar=veri.get('anahtar', ''),
                    deger=veri.get('deger', ''),
                    boyut=veri.get('boyut', 0),
                    veri_tipi='indexedDB',
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            
            # Hataları aktar
            self.hatalar.extend(okuyucu.hatalar)
            
        except Exception as e:
            self.hatalar.append(f"LocalStorage çıkarma hatası: {str(e)}")
        
        return sonuclar
    
    def silinen_verileri_kurtar(self, profil: str = "Default") -> List[SilinenKayit]:
        """Chrome veritabanlarından silinmiş verileri kurtarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        try:
            kurtarici = SQLiteKurtarici()
            
            # Taranacak veritabanları
            db_yollari = [
                profil_dizini / Ayarlar.CHROME_GECMIS_DB,
                profil_dizini / "Network" / Ayarlar.CHROME_CEREZ_DB,
                profil_dizini / Ayarlar.CHROME_CEREZ_DB,
                profil_dizini / Ayarlar.CHROME_LOGIN_DB,
                profil_dizini / Ayarlar.CHROME_WEB_DATA_DB
            ]
            
            # Geçerli yolları filtrele
            gecerli_yollar = [y for y in db_yollari if y.exists()]
            
            # Kurtarma işlemini başlat
            kurtarilan = kurtarici.tum_veritabanlarini_tara(gecerli_yollar)
            
            for idx, veri in enumerate(kurtarilan):
                # Tablo adını tahmin et
                tablo = "bilinmeyen"
                if veri.get('tip') == 'url':
                    tablo = "urls"
                elif veri.get('tip') == 'metin':
                    tablo = "metin_verisi"
                
                kayit = SilinenKayit(
                    id=idx + 1,
                    tablo=tablo,
                    veri=veri,
                    kaynak_db=veri.get('veritabani', 'bilinmeyen'),
                    kurtarma_tarihi=datetime.now(),
                    guvenilirlik=kurtarici.guvenilirlik_hesapla(veri),
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            
            # Hataları aktar
            self.hatalar.extend(kurtarici.hatalar)
            
        except Exception as e:
            self.hatalar.append(f"Silinen veri kurtarma hatası: {str(e)}")
        
        return sonuclar
    
    def otomatik_doldurma_cikart(self, profil: str = "Default") -> List[OtomatikDoldurma]:
        """Chrome otomatik doldurma verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        try:
            okuyucu = OtomatikDoldurmaOkuyucu()
            veriler = okuyucu.chrome_autofill_oku(profil_dizini)
            
            for idx, veri in enumerate(veriler):
                kayit = OtomatikDoldurma(
                    id=idx + 1,
                    tip=veri.get('tip', 'diger'),
                    alan=veri.get('alan', ''),
                    deger=veri.get('deger', ''),
                    kullanim_sayisi=veri.get('kullanim_sayisi', 0),
                    son_kullanim=veri.get('son_kullanim'),
                    olusturma_tarihi=veri.get('olusturma_tarihi'),
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            
            self.hatalar.extend(okuyucu.hatalar)
            
        except Exception as e:
            self.hatalar.append(f"Otomatik doldurma hatası: {str(e)}")
        
        return sonuclar
    
    def medya_gecmisi_cikart(self, profil: str = "Default") -> List[MedyaGecmisi]:
        """Chrome medya geçmişini çıkarır (geçmişten filtreleme)"""
        sonuclar = []
        
        try:
            # Önce geçmişi al
            gecmis = self.gecmis_cikart(profil)
            
            # Medya okuyucu ile filtrele
            okuyucu = MedyaGecmisiOkuyucu()
            medya_verileri = okuyucu.gecmisten_medya_cikart(gecmis)
            
            for idx, veri in enumerate(medya_verileri):
                kayit = MedyaGecmisi(
                    id=idx + 1,
                    url=veri.get('url', ''),
                    baslik=veri.get('baslik', ''),
                    medya_tipi=veri.get('medya_tipi', 'video'),
                    kaynak=veri.get('kaynak', ''),
                    son_izleme=veri.get('son_izleme'),
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
                
        except Exception as e:
            self.hatalar.append(f"Medya geçmişi hatası: {str(e)}")
        
        return sonuclar
    
    def silme_girisimi_tespit(self, profil: str = "Default") -> List[SilmeGirisimi]:
        """Geçmiş silme girişimlerini tespit eder"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        try:
            analizci = ForensikAnalizci()
            
            # History veritabanını analiz et
            history_db = profil_dizini / Ayarlar.CHROME_GECMIS_DB
            if history_db.exists():
                tespitler = analizci.silme_girisimi_tespit(history_db)
                
                for idx, tespit in enumerate(tespitler):
                    kayit = SilmeGirisimi(
                        id=idx + 1,
                        silme_tipi=tespit.get('silme_tipi', 'bilinmeyen'),
                        tespit_yontemi=tespit.get('tespit_yontemi', ''),
                        detaylar=tespit.get('detaylar', ''),
                        guvenilirlik=tespit.get('guvenilirlik', 0),
                        tarayici=self.tarayici_tipi,
                        profil=profil
                    )
                    sonuclar.append(kayit)
            
            self.hatalar.extend(analizci.hatalar)
            
        except Exception as e:
            self.hatalar.append(f"Silme tespiti hatası: {str(e)}")
        
        return sonuclar
    
    def service_worker_cache_cikart(self, profil: str = "Default") -> List[ServiceWorkerCache]:
        """Chrome Service Worker cache verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        try:
            sw_dizini = profil_dizini / "Service Worker" / "CacheStorage"
            
            if not sw_dizini.exists():
                return sonuclar
            
            cache_id = 0
            
            # Her origin için dizinleri tara
            for origin_dizini in sw_dizini.iterdir():
                if not origin_dizini.is_dir():
                    continue
                
                origin = origin_dizini.name
                
                # Cache dizinlerini tara
                for cache_dizini in origin_dizini.iterdir():
                    if not cache_dizini.is_dir():
                        continue
                    
                    cache_adi = cache_dizini.name
                    
                    # İndex dosyasını oku
                    index_dosya = cache_dizini / "index"
                    if index_dosya.exists():
                        try:
                            # Basit dosya tarama
                            for dosya in cache_dizini.iterdir():
                                if dosya.is_file() and dosya.suffix in ['', '.cache']:
                                    cache_id += 1
                                    
                                    # İçerik tipini tahmin et
                                    icerik_tipi = "unknown"
                                    dosya_boyut = dosya.stat().st_size
                                    
                                    kayit = ServiceWorkerCache(
                                        id=cache_id,
                                        origin=origin,
                                        cache_adi=cache_adi,
                                        url=dosya.name,
                                        icerik_tipi=icerik_tipi,
                                        boyut=dosya_boyut,
                                        tarayici=self.tarayici_tipi,
                                        profil=profil
                                    )
                                    sonuclar.append(kayit)
                        except Exception:
                            continue
                            
        except Exception as e:
            self.hatalar.append(f"Service Worker cache hatası: {str(e)}")
        
        return sonuclar
