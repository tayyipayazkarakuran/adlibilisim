"""
Adli Bilişim Forensik Aracı - Firefox Veri Çıkarıcı

Mozilla Firefox tarayıcısından veri çıkarma modülü.
"""

from typing import List, Optional
from pathlib import Path
from datetime import datetime
import json
import os
import configparser

from .temel_cikarici import TemelCikarici
from modeller.veri_modelleri import (
    TarayiciGecmisi,
    Cerez,
    IndirilenDosya,
    KayitliSifre,
    FormVerisi,
    CacheGorsel,
    TarayiciTipi,
    OturumVerisi,
    LocalStorageVerisi,
    SilinenKayit
)
from config.ayarlar import Ayarlar
from yardimcilar.local_storage_okuyucu import LocalStorageOkuyucu
from yardimcilar.sqlite_kurtarici import SQLiteKurtarici


class FirefoxCikarici(TemelCikarici):
    """Mozilla Firefox tarayıcısı için veri çıkarıcı"""
    
    def __init__(self):
        super().__init__(TarayiciTipi.FIREFOX)
    
    def profil_yolu_bul(self) -> Optional[Path]:
        """Firefox profil dizinini bulur"""
        try:
            yol = Ayarlar.tarayici_yolu_al('firefox')
            if yol.exists():
                self.profil_yolu = yol
                return yol
            return None
        except Exception as e:
            self.hatalar.append(f"Profil yolu bulunamadı: {str(e)}")
            return None
    
    def profilleri_listele(self) -> List[str]:
        """Mevcut Firefox profillerini listeler"""
        profiller = []
        yol = self.profil_yolu_bul()
        
        if yol is None:
            return profiller
        
        # profiles.ini dosyasını oku
        profiles_ini = yol.parent / "profiles.ini"
        
        if profiles_ini.exists():
            try:
                config = configparser.ConfigParser()
                config.read(profiles_ini)
                
                for section in config.sections():
                    if section.startswith('Profile'):
                        path = config.get(section, 'Path', fallback=None)
                        if path:
                            profil_yolu = yol.parent / path
                            if profil_yolu.exists():
                                profiller.append(path)
            except Exception:
                pass
        
        # Klasörleri de kontrol et
        if yol.exists():
            for item in yol.iterdir():
                if item.is_dir() and '.default' in item.name:
                    if item.name not in profiller:
                        profiller.append(item.name)
        
        return profiller
    
    def _profil_dizini(self, profil: str) -> Optional[Path]:
        """Belirtilen profilin dizin yolunu döndürür"""
        yol = self.profil_yolu_bul()
        if yol is None:
            return None
        
        # Profil adı tam yol olabilir
        profil_yolu = yol / profil
        if profil_yolu.exists():
            return profil_yolu
        
        # Profiles klasöründe arama yap
        profil_yolu = yol.parent / profil
        if profil_yolu.exists():
            return profil_yolu
        
        # .default içeren profili bul
        if yol.exists():
            for item in yol.iterdir():
                if item.is_dir() and '.default' in item.name:
                    return item
        
        return None
    
    def gecmis_cikart(self, profil: str = "Default") -> List[TarayiciGecmisi]:
        """Firefox tarayıcı geçmişini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            self.hatalar.append(f"Profil bulunamadı: {profil}")
            return sonuclar
        
        db_yolu = profil_dizini / Ayarlar.FIREFOX_GECMIS_DB
        
        if not db_yolu.exists():
            self.hatalar.append(f"Geçmiş veritabanı bulunamadı: {db_yolu}")
            return sonuclar
        
        sorgu = """
            SELECT 
                moz_places.id,
                moz_places.url,
                moz_places.title,
                moz_historyvisits.visit_date,
                moz_places.visit_count
            FROM moz_places
            JOIN moz_historyvisits ON moz_places.id = moz_historyvisits.place_id
            ORDER BY moz_historyvisits.visit_date ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                kayit = TarayiciGecmisi(
                    id=satir[0],
                    url=satir[1] or "",
                    baslik=satir[2] or "(Başlıksız)",
                    ziyaret_tarihi=self.firefox_zamani_cevir(satir[3] or 0),
                    ziyaret_sayisi=satir[4] or 1,
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Geçmiş kaydı işleme hatası: {str(e)}")
        
        return sonuclar
    
    def cerezleri_cikart(self, profil: str = "Default") -> List[Cerez]:
        """Firefox çerezlerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        db_yolu = profil_dizini / Ayarlar.FIREFOX_CEREZ_DB
        
        if not db_yolu.exists():
            self.hatalar.append(f"Çerez veritabanı bulunamadı")
            return sonuclar
        
        sorgu = """
            SELECT 
                id,
                name,
                value,
                host,
                path,
                creationTime,
                lastAccessed,
                expiry,
                isSecure,
                isHttpOnly
            FROM moz_cookies
            ORDER BY creationTime ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                son_kullanma = None
                if satir[7] and satir[7] > 0:
                    try:
                        son_kullanma = datetime.fromtimestamp(satir[7])
                    except:
                        pass
                
                kayit = Cerez(
                    id=satir[0],
                    ad=satir[1] or "",
                    deger=satir[2] or "",
                    domain=satir[3] or "",
                    yol=satir[4] or "/",
                    olusturma_tarihi=self.firefox_zamani_cevir(satir[5] or 0),
                    son_erisim_tarihi=self.firefox_zamani_cevir(satir[6] or 0),
                    son_kullanma_tarihi=son_kullanma,
                    guvenli=bool(satir[8]),
                    http_only=bool(satir[9]),
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Çerez kaydı işleme hatası: {str(e)}")
        
        return sonuclar
    
    def indirmeleri_cikart(self, profil: str = "Default") -> List[IndirilenDosya]:
        """Firefox indirme geçmişini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        db_yolu = profil_dizini / Ayarlar.FIREFOX_GECMIS_DB
        
        if not db_yolu.exists():
            return sonuclar
        
        # Firefox indirmeleri moz_annos tablosunda saklar
        sorgu = """
            SELECT 
                moz_annos.id,
                moz_places.url,
                moz_annos.content,
                moz_annos.dateAdded
            FROM moz_annos
            JOIN moz_places ON moz_annos.place_id = moz_places.id
            WHERE moz_annos.anno_attribute_id IN (
                SELECT id FROM moz_anno_attributes 
                WHERE name = 'downloads/destinationFileURI'
            )
            ORDER BY moz_annos.dateAdded ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                dosya_uri = satir[2] or ""
                dosya_yolu = dosya_uri.replace("file:///", "").replace("file://", "")
                dosya_adi = os.path.basename(dosya_yolu) if dosya_yolu else "bilinmiyor"
                
                kayit = IndirilenDosya(
                    id=satir[0],
                    dosya_adi=dosya_adi,
                    dosya_yolu=dosya_yolu,
                    kaynak_url=satir[1] or "",
                    baslangic_tarihi=self.firefox_zamani_cevir(satir[3] or 0),
                    bitis_tarihi=None,
                    dosya_boyutu=0,
                    durum="tamamlandi",
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"İndirme kaydı işleme hatası: {str(e)}")
        
        return sonuclar
    
    def sifreleri_cikart(self, profil: str = "Default") -> List[KayitliSifre]:
        """Firefox kayıtlı şifrelerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        logins_json = profil_dizini / Ayarlar.FIREFOX_LOGIN_JSON
        
        if not logins_json.exists():
            self.hatalar.append(f"Şifre dosyası bulunamadı")
            return sonuclar
        
        try:
            with open(logins_json, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            logins = data.get('logins', [])
            
            for idx, login in enumerate(logins):
                try:
                    olusturma = None
                    if login.get('timeCreated'):
                        olusturma = datetime.fromtimestamp(login['timeCreated'] / 1000)
                    
                    son_kullanim = None
                    if login.get('timeLastUsed'):
                        son_kullanim = datetime.fromtimestamp(login['timeLastUsed'] / 1000)
                    
                    kayit = KayitliSifre(
                        id=idx + 1,
                        site_url=login.get('hostname', ''),
                        kullanici_adi=login.get('encryptedUsername', ''),
                        sifre_sifreli=login.get('encryptedPassword', '').encode(),
                        olusturma_tarihi=olusturma,
                        son_kullanim_tarihi=son_kullanim,
                        tarayici=self.tarayici_tipi,
                        profil=profil
                    )
                    sonuclar.append(kayit)
                except Exception as e:
                    self.hatalar.append(f"Şifre kaydı işleme hatası: {str(e)}")
        except Exception as e:
            self.hatalar.append(f"Şifre dosyası okuma hatası: {str(e)}")
        
        return sonuclar
    
    def form_verilerini_cikart(self, profil: str = "Default") -> List[FormVerisi]:
        """Firefox form verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        db_yolu = profil_dizini / "formhistory.sqlite"
        
        if not db_yolu.exists():
            return sonuclar
        
        sorgu = """
            SELECT 
                id,
                fieldname,
                value,
                timesUsed,
                lastUsed
            FROM moz_formhistory
            ORDER BY lastUsed ASC
        """
        
        satirlar = self.sqlite_oku(db_yolu, sorgu)
        
        for satir in satirlar:
            try:
                son_kullanim = None
                if satir[4] and satir[4] > 0:
                    son_kullanim = self.firefox_zamani_cevir(satir[4] * 1000000)
                
                kayit = FormVerisi(
                    id=satir[0],
                    alan_adi=satir[1] or "",
                    deger=satir[2] or "",
                    kullanim_sayisi=satir[3] or 1,
                    son_kullanim_tarihi=son_kullanim,
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            except Exception as e:
                self.hatalar.append(f"Form verisi işleme hatası: {str(e)}")
        
        return sonuclar
    
    def cache_gorselleri_cikart(self, profil: str = "Default") -> List[CacheGorsel]:
        """Firefox cache görsellerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        cache_dizini = profil_dizini / "cache2" / "entries"
        
        if not cache_dizini.exists():
            return sonuclar
        
        gorsel_id = 0
        
        try:
            for dosya in cache_dizini.iterdir():
                if dosya.is_file():
                    try:
                        with open(dosya, 'rb') as f:
                            header = f.read(16)
                        
                        format_turu = None
                        
                        if header.startswith(b'\xff\xd8\xff'):
                            format_turu = 'jpeg'
                        elif header.startswith(b'\x89PNG'):
                            format_turu = 'png'
                        elif header.startswith(b'GIF'):
                            format_turu = 'gif'
                        elif header.startswith(b'RIFF') and b'WEBP' in header:
                            format_turu = 'webp'
                        
                        if format_turu:
                            gorsel_id += 1
                            stat = dosya.stat()
                            
                            kayit = CacheGorsel(
                                id=gorsel_id,
                                dosya_yolu=str(dosya),
                                kaynak_url=None,
                                dosya_boyutu=stat.st_size,
                                genislik=None,
                                yukseklik=None,
                                format=format_turu,
                                olusturma_tarihi=datetime.fromtimestamp(stat.st_mtime),
                                tarayici=self.tarayici_tipi,
                                profil=profil
                            )
                            sonuclar.append(kayit)
                    except Exception:
                        continue
        except Exception as e:
            self.hatalar.append(f"Cache tarama hatası: {str(e)}")
        
        return sonuclar
    
    def oturum_cikart(self, profil: str = "Default") -> List[OturumVerisi]:
        """Firefox oturum/sekme verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        # Firefox oturum dosyaları
        session_dosyalari = [
            profil_dizini / "sessionstore.jsonlz4",
            profil_dizini / "sessionstore-backups" / "recovery.jsonlz4",
            profil_dizini / "sessionstore-backups" / "previous.jsonlz4"
        ]
        
        sekme_id = 0
        
        for session_dosya in session_dosyalari:
            if not session_dosya.exists():
                continue
            
            try:
                # jsonlz4 formatını çöz
                session_data = self._jsonlz4_oku(session_dosya)
                if session_data is None:
                    continue
                
                # Pencereleri ve sekmeleri çıkar
                pencereler = session_data.get('windows', [])
                
                for pencere_idx, pencere in enumerate(pencereler):
                    sekmeler = pencere.get('tabs', [])
                    
                    for sekme_idx, sekme in enumerate(sekmeler):
                        # Son girişi al
                        entries = sekme.get('entries', [])
                        if not entries:
                            continue
                        
                        son_entry = entries[-1]
                        url = son_entry.get('url', '')
                        baslik = son_entry.get('title', '')
                        
                        if not url or url.startswith('about:'):
                            continue
                        
                        sekme_id += 1
                        son_erisim = datetime.fromtimestamp(session_dosya.stat().st_mtime)
                        
                        kayit = OturumVerisi(
                            id=sekme_id,
                            url=url,
                            baslik=baslik or url[:50],
                            son_erisim=son_erisim,
                            sekme_indeksi=sekme_idx,
                            pencere_id=pencere_idx,
                            tarayici=self.tarayici_tipi,
                            profil=profil,
                            pinned=sekme.get('pinned', False)
                        )
                        sonuclar.append(kayit)
                        
            except Exception as e:
                self.hatalar.append(f"Firefox oturum okuma hatası: {str(e)}")
        
        return sonuclar
    
    def _jsonlz4_oku(self, dosya_yolu: Path) -> Optional[dict]:
        """Firefox jsonlz4 formatını okur"""
        try:
            import lz4.block
            
            with open(dosya_yolu, 'rb') as f:
                # Magic bytes'ları atla (mozLz40\x00)
                magic = f.read(8)
                if not magic.startswith(b'mozLz40'):
                    return None
                
                # Sıkıştırılmış veriyi oku
                compressed = f.read()
                
                # Decompress
                decompressed = lz4.block.decompress(compressed)
                
                # JSON parse
                return json.loads(decompressed)
                
        except ImportError:
            # lz4 yoksa basit metin araması yap
            return self._jsonlz4_basit_oku(dosya_yolu)
        except Exception as e:
            self.hatalar.append(f"jsonlz4 okuma hatası: {str(e)}")
            return None
    
    def _jsonlz4_basit_oku(self, dosya_yolu: Path) -> Optional[dict]:
        """lz4 kütüphanesi olmadan basit URL çıkarma"""
        try:
            with open(dosya_yolu, 'rb') as f:
                icerik = f.read()
            
            # URL'leri ara ve basit bir yapı oluştur
            url_list = []
            patterns = [b'http://', b'https://']
            
            for pattern in patterns:
                pos = 0
                while True:
                    idx = icerik.find(pattern, pos)
                    if idx == -1:
                        break
                    
                    # URL sonunu bul
                    end = idx
                    for i in range(idx, min(idx + 2048, len(icerik))):
                        if icerik[i] < 32 or icerik[i] > 126 or chr(icerik[i]) in '"\'':
                            end = i
                            break
                        end = i + 1
                    
                    if end > idx + 10:
                        try:
                            url = icerik[idx:end].decode('utf-8', errors='ignore')
                            if not url.startswith('about:') and url not in url_list:
                                url_list.append(url)
                        except:
                            pass
                    
                    pos = end
            
            # Basit yapı döndür
            if url_list:
                tabs = [{'entries': [{'url': url, 'title': ''}]} for url in url_list[:50]]
                return {'windows': [{'tabs': tabs}]}
            
            return None
            
        except Exception:
            return None
    
    def local_storage_cikart(self, profil: str = "Default") -> List[LocalStorageVerisi]:
        """Firefox LocalStorage verilerini çıkarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        try:
            okuyucu = LocalStorageOkuyucu()
            
            # Firefox webappsstore.sqlite
            ls_veriler = okuyucu.firefox_local_storage_oku(profil_dizini)
            
            for idx, veri in enumerate(ls_veriler):
                kayit = LocalStorageVerisi(
                    id=idx + 1,
                    origin=veri.get('origin', ''),
                    anahtar=veri.get('anahtar', ''),
                    deger=veri.get('deger', ''),
                    boyut=veri.get('boyut', 0),
                    veri_tipi='localStorage',
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            
            # IndexedDB
            idb_veriler = okuyucu.indexeddb_oku(profil_dizini, 'firefox')
            
            for idx, veri in enumerate(idb_veriler):
                kayit = LocalStorageVerisi(
                    id=len(sonuclar) + idx + 1,
                    origin=veri.get('origin', ''),
                    anahtar=veri.get('anahtar', ''),
                    deger=veri.get('deger', ''),
                    boyut=veri.get('boyut', 0),
                    veri_tipi='indexedDB',
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            
            # Hataları aktar
            self.hatalar.extend(okuyucu.hatalar)
            
        except Exception as e:
            self.hatalar.append(f"LocalStorage çıkarma hatası: {str(e)}")
        
        return sonuclar
    
    def silinen_verileri_kurtar(self, profil: str = "Default") -> List[SilinenKayit]:
        """Firefox veritabanlarından silinmiş verileri kurtarır"""
        sonuclar = []
        profil_dizini = self._profil_dizini(profil)
        
        if profil_dizini is None:
            return sonuclar
        
        try:
            kurtarici = SQLiteKurtarici()
            
            # Taranacak veritabanları
            db_yollari = [
                profil_dizini / Ayarlar.FIREFOX_GECMIS_DB,
                profil_dizini / Ayarlar.FIREFOX_CEREZ_DB,
                profil_dizini / "formhistory.sqlite",
                profil_dizini / "webappsstore.sqlite"
            ]
            
            # Geçerli yolları filtrele
            gecerli_yollar = [y for y in db_yollari if y.exists()]
            
            # Kurtarma işlemini başlat
            kurtarilan = kurtarici.tum_veritabanlarini_tara(gecerli_yollar)
            
            for idx, veri in enumerate(kurtarilan):
                # Tablo adını tahmin et
                tablo = "bilinmeyen"
                if veri.get('tip') == 'url':
                    tablo = "moz_places"
                elif veri.get('tip') == 'metin':
                    tablo = "metin_verisi"
                
                kayit = SilinenKayit(
                    id=idx + 1,
                    tablo=tablo,
                    veri=veri,
                    kaynak_db=veri.get('veritabani', 'bilinmeyen'),
                    kurtarma_tarihi=datetime.now(),
                    guvenilirlik=kurtarici.guvenilirlik_hesapla(veri),
                    tarayici=self.tarayici_tipi,
                    profil=profil
                )
                sonuclar.append(kayit)
            
            # Hataları aktar
            self.hatalar.extend(kurtarici.hatalar)
            
        except Exception as e:
            self.hatalar.append(f"Silinen veri kurtarma hatası: {str(e)}")
        
        return sonuclar
