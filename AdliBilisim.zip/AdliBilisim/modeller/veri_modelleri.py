"""
Adli Bilişim Forensik Aracı - Veri Modelleri

Bu modül uygulama genelinde kullanılan veri modellerini
(dataclass) içerir.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List
from enum import Enum


class TarayiciTipi(Enum):
    """Desteklenen tarayıcı türleri"""
    CHROME = "chrome"
    FIREFOX = "firefox"
    EDGE = "edge"
    OPERA = "opera"
    BRAVE = "brave"
    SAFARI = "safari"
    
    @property
    def gorunen_ad(self) -> str:
        """Tarayıcının görünen adını döndürür"""
        isimler = {
            "chrome": "Google Chrome",
            "firefox": "Mozilla Firefox",
            "edge": "Microsoft Edge",
            "opera": "Opera",
            "brave": "Brave",
            "safari": "Safari"
        }
        return isimler.get(self.value, self.value)


@dataclass
class TarayiciGecmisi:
    """Tarayıcı geçmiş kaydı veri modeli"""
    id: int
    url: str
    baslik: str
    ziyaret_tarihi: datetime
    ziyaret_sayisi: int
    tarayici: TarayiciTipi
    profil: str = "Default"
    
    # Hash değeri (veri bütünlüğü için)
    hash_degeri: Optional[str] = None
    
    def __post_init__(self):
        """Tarih formatını düzelt"""
        if isinstance(self.ziyaret_tarihi, str):
            self.ziyaret_tarihi = datetime.fromisoformat(self.ziyaret_tarihi)
    
    @property
    def domain(self) -> str:
        """URL'den domain adını çıkarır"""
        from urllib.parse import urlparse
        try:
            parsed = urlparse(self.url)
            return parsed.netloc
        except:
            return self.url
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "url": self.url,
            "baslik": self.baslik,
            "ziyaret_tarihi": self.ziyaret_tarihi.isoformat(),
            "ziyaret_sayisi": self.ziyaret_sayisi,
            "tarayici": self.tarayici.value,
            "profil": self.profil,
            "hash_degeri": self.hash_degeri
        }


@dataclass
class Cerez:
    """Cookie (çerez) veri modeli"""
    id: int
    ad: str
    deger: str
    domain: str
    yol: str
    olusturma_tarihi: datetime
    son_erisim_tarihi: Optional[datetime]
    son_kullanma_tarihi: Optional[datetime]
    guvenli: bool  # Secure flag
    http_only: bool  # HttpOnly flag
    tarayici: TarayiciTipi
    profil: str = "Default"
    
    # Hash değeri
    hash_degeri: Optional[str] = None
    
    @property
    def suresi_dolmus(self) -> bool:
        """Çerezin süresinin dolup dolmadığını kontrol eder"""
        if self.son_kullanma_tarihi is None:
            return False  # Session cookie
        return datetime.now() > self.son_kullanma_tarihi
    
    @property
    def oturum_cerezi(self) -> bool:
        """Session cookie olup olmadığını kontrol eder"""
        return self.son_kullanma_tarihi is None
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "ad": self.ad,
            "deger": self.deger,
            "domain": self.domain,
            "yol": self.yol,
            "olusturma_tarihi": self.olusturma_tarihi.isoformat() if self.olusturma_tarihi else None,
            "son_erisim_tarihi": self.son_erisim_tarihi.isoformat() if self.son_erisim_tarihi else None,
            "son_kullanma_tarihi": self.son_kullanma_tarihi.isoformat() if self.son_kullanma_tarihi else None,
            "guvenli": self.guvenli,
            "http_only": self.http_only,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class IndirilenDosya:
    """İndirilen dosya veri modeli"""
    id: int
    dosya_adi: str
    dosya_yolu: str
    kaynak_url: str
    baslangic_tarihi: datetime
    bitis_tarihi: Optional[datetime]
    dosya_boyutu: int  # Byte cinsinden
    durum: str  # 'tamamlandi', 'iptal_edildi', 'devam_ediyor'
    tarayici: TarayiciTipi
    profil: str = "Default"
    
    # Hash değeri
    hash_degeri: Optional[str] = None
    
    @property
    def boyut_formatli(self) -> str:
        """Dosya boyutunu okunabilir formatta döndürür"""
        boyut = self.dosya_boyutu
        for birim in ['B', 'KB', 'MB', 'GB', 'TB']:
            if boyut < 1024:
                return f"{boyut:.2f} {birim}"
            boyut /= 1024
        return f"{boyut:.2f} PB"
    
    @property
    def dosya_uzantisi(self) -> str:
        """Dosya uzantısını döndürür"""
        import os
        _, uzanti = os.path.splitext(self.dosya_adi)
        return uzanti.lower()
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "dosya_adi": self.dosya_adi,
            "dosya_yolu": self.dosya_yolu,
            "kaynak_url": self.kaynak_url,
            "baslangic_tarihi": self.baslangic_tarihi.isoformat(),
            "bitis_tarihi": self.bitis_tarihi.isoformat() if self.bitis_tarihi else None,
            "dosya_boyutu": self.dosya_boyutu,
            "durum": self.durum,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class KayitliSifre:
    """Kayıtlı şifre veri modeli"""
    id: int
    site_url: str
    kullanici_adi: str
    sifre_sifreli: bytes  # Şifrelenmiş hali
    sifre_cozulmus: Optional[str] = None  # Çözülmüş hali (opsiyonel)
    olusturma_tarihi: Optional[datetime] = None
    son_kullanim_tarihi: Optional[datetime] = None
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    # Hash değeri
    hash_degeri: Optional[str] = None
    
    @property
    def domain(self) -> str:
        """URL'den domain adını çıkarır"""
        from urllib.parse import urlparse
        try:
            parsed = urlparse(self.site_url)
            return parsed.netloc
        except:
            return self.site_url
    
    @property
    def sifre_uzunlugu(self) -> int:
        """Çözülmüş şifrenin uzunluğunu döndürür"""
        if self.sifre_cozulmus:
            return len(self.sifre_cozulmus)
        return 0
    
    def to_dict(self, sifre_goster: bool = False) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "site_url": self.site_url,
            "kullanici_adi": self.kullanici_adi,
            "sifre": self.sifre_cozulmus if sifre_goster else "********",
            "olusturma_tarihi": self.olusturma_tarihi.isoformat() if self.olusturma_tarihi else None,
            "son_kullanim_tarihi": self.son_kullanim_tarihi.isoformat() if self.son_kullanim_tarihi else None,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class FormVerisi:
    """Otomatik doldurulan form verisi modeli"""
    id: int
    alan_adi: str  # Form alanı adı (name, email, address, vb.)
    deger: str  # Form alanı değeri
    kullanim_sayisi: int
    son_kullanim_tarihi: Optional[datetime]
    tarayici: TarayiciTipi
    profil: str = "Default"
    
    # Hash değeri
    hash_degeri: Optional[str] = None
    
    @property
    def alan_tipi(self) -> str:
        """Alan adından tip çıkarımı yapar"""
        alan = self.alan_adi.lower()
        if any(x in alan for x in ['email', 'e-mail', 'mail']):
            return "E-posta"
        elif any(x in alan for x in ['phone', 'tel', 'telefon']):
            return "Telefon"
        elif any(x in alan for x in ['name', 'isim', 'ad']):
            return "İsim"
        elif any(x in alan for x in ['address', 'adres']):
            return "Adres"
        elif any(x in alan for x in ['city', 'sehir', 'şehir']):
            return "Şehir"
        elif any(x in alan for x in ['country', 'ulke', 'ülke']):
            return "Ülke"
        elif any(x in alan for x in ['zip', 'postal', 'posta']):
            return "Posta Kodu"
        else:
            return "Diğer"
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "alan_adi": self.alan_adi,
            "deger": self.deger,
            "kullanim_sayisi": self.kullanim_sayisi,
            "son_kullanim_tarihi": self.son_kullanim_tarihi.isoformat() if self.son_kullanim_tarihi else None,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class CacheGorsel:
    """Cache'deki görsel dosya modeli"""
    id: int
    dosya_yolu: str
    kaynak_url: Optional[str]
    dosya_boyutu: int
    genislik: Optional[int]
    yukseklik: Optional[int]
    format: str  # 'jpeg', 'png', 'gif', 'webp', vb.
    olusturma_tarihi: Optional[datetime]
    tarayici: TarayiciTipi
    profil: str = "Default"
    
    # Hash değeri
    hash_degeri: Optional[str] = None
    
    @property
    def boyut_formatli(self) -> str:
        """Dosya boyutunu okunabilir formatta döndürür"""
        boyut = self.dosya_boyutu
        for birim in ['B', 'KB', 'MB', 'GB']:
            if boyut < 1024:
                return f"{boyut:.2f} {birim}"
            boyut /= 1024
        return f"{boyut:.2f} TB"
    
    @property
    def boyutlar(self) -> str:
        """Görsel boyutlarını döndürür"""
        if self.genislik and self.yukseklik:
            return f"{self.genislik}x{self.yukseklik}"
        return "Bilinmiyor"
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "dosya_yolu": self.dosya_yolu,
            "kaynak_url": self.kaynak_url,
            "dosya_boyutu": self.dosya_boyutu,
            "genislik": self.genislik,
            "yukseklik": self.yukseklik,
            "format": self.format,
            "olusturma_tarihi": self.olusturma_tarihi.isoformat() if self.olusturma_tarihi else None,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class TaramaRaporu:
    """Tarama sonuç raporu modeli"""
    tarama_tarihi: datetime
    tarama_suresi: float  # Saniye cinsinden
    toplam_gecmis: int = 0
    toplam_cerez: int = 0
    toplam_indirme: int = 0
    toplam_sifre: int = 0
    toplam_form_verisi: int = 0
    toplam_cache_gorsel: int = 0
    taranan_tarayicilar: List[str] = field(default_factory=list)
    hatalar: List[str] = field(default_factory=list)
    
    @property
    def toplam_kayit(self) -> int:
        """Toplam kayıt sayısını döndürür"""
        return (
            self.toplam_gecmis +
            self.toplam_cerez +
            self.toplam_indirme +
            self.toplam_sifre +
            self.toplam_form_verisi +
            self.toplam_cache_gorsel
        )
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "tarama_tarihi": self.tarama_tarihi.isoformat(),
            "tarama_suresi": self.tarama_suresi,
            "toplam_gecmis": self.toplam_gecmis,
            "toplam_cerez": self.toplam_cerez,
            "toplam_indirme": self.toplam_indirme,
            "toplam_sifre": self.toplam_sifre,
            "toplam_form_verisi": self.toplam_form_verisi,
            "toplam_cache_gorsel": self.toplam_cache_gorsel,
            "taranan_tarayicilar": self.taranan_tarayicilar,
            "hatalar": self.hatalar
        }


@dataclass
class OturumVerisi:
    """Açık sekme/oturum verisi modeli"""
    id: int
    url: str
    baslik: str
    son_erisim: datetime
    sekme_indeksi: int = 0
    pencere_id: int = 0
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    # Ek bilgiler
    pinned: bool = False  # Sabitlenmiş sekme
    aktif: bool = False   # Aktif sekme
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "url": self.url,
            "baslik": self.baslik,
            "son_erisim": self.son_erisim.isoformat() if self.son_erisim else None,
            "sekme_indeksi": self.sekme_indeksi,
            "pencere_id": self.pencere_id,
            "tarayici": self.tarayici.value,
            "profil": self.profil,
            "pinned": self.pinned,
            "aktif": self.aktif
        }


@dataclass
class LocalStorageVerisi:
    """LocalStorage/IndexedDB verisi modeli"""
    id: int
    origin: str  # https://example.com
    anahtar: str
    deger: str
    boyut: int  # Byte cinsinden
    veri_tipi: str = "localStorage"  # localStorage, sessionStorage, indexedDB
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    @property
    def domain(self) -> str:
        """Origin'den domain adını çıkarır"""
        from urllib.parse import urlparse
        try:
            parsed = urlparse(self.origin)
            return parsed.netloc
        except:
            return self.origin
    
    @property
    def deger_kisaltilmis(self) -> str:
        """Değerin kısaltılmış halini döndürür"""
        if len(self.deger) > 100:
            return self.deger[:100] + "..."
        return self.deger
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "origin": self.origin,
            "anahtar": self.anahtar,
            "deger": self.deger,
            "boyut": self.boyut,
            "veri_tipi": self.veri_tipi,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class SilinenKayit:
    """SQLite'dan kurtarılan silinmiş kayıt modeli"""
    id: int
    tablo: str  # urls, cookies, downloads, vb.
    veri: dict  # Kurtarılan veri
    kaynak_db: str  # Veritabanı dosya adı
    kurtarma_tarihi: datetime
    guvenilirlik: int = 0  # 0-100 arası güvenilirlik skoru
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    @property
    def veri_ozeti(self) -> str:
        """Verinin özet gösterimini döndürür"""
        if not self.veri:
            return "(Boş)"
        
        # URL varsa göster
        if "url" in self.veri:
            return self.veri["url"][:80]
        
        # İlk anahtar-değer çiftini göster
        ilk_anahtar = list(self.veri.keys())[0]
        ilk_deger = str(self.veri[ilk_anahtar])[:50]
        return f"{ilk_anahtar}: {ilk_deger}"
    
    def to_dict(self) -> dict:
        """Dictionary'e dönüştürür"""
        return {
            "id": self.id,
            "tablo": self.tablo,
            "veri": self.veri,
            "kaynak_db": self.kaynak_db,
            "kurtarma_tarihi": self.kurtarma_tarihi.isoformat(),
            "guvenilirlik": self.guvenilirlik,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class OtomatikDoldurma:
    """Otomatik doldurma verisi modeli (adres, telefon, kredi kartı)"""
    id: int
    tip: str  # "adres", "telefon", "kredi_karti", "isim", "email"
    alan: str  # Form alanı adı
    deger: str  # Şifrelenmiş veya açık değer
    kullanim_sayisi: int = 0
    son_kullanim: Optional[datetime] = None
    olusturma_tarihi: Optional[datetime] = None
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    @property
    def maskelenmis_deger(self) -> str:
        """Hassas verileri maskeler"""
        if self.tip == "kredi_karti" and len(self.deger) > 4:
            return "*" * (len(self.deger) - 4) + self.deger[-4:]
        elif self.tip == "telefon" and len(self.deger) > 4:
            return "*" * (len(self.deger) - 4) + self.deger[-4:]
        return self.deger
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "tip": self.tip,
            "alan": self.alan,
            "deger": self.maskelenmis_deger,
            "kullanim_sayisi": self.kullanim_sayisi,
            "son_kullanim": self.son_kullanim.isoformat() if self.son_kullanim else None,
            "tarayici": self.tarayici.value,
            "profil": self.profil
        }


@dataclass
class MedyaGecmisi:
    """Medya geçmişi modeli (video, ses)"""
    id: int
    url: str
    baslik: str
    medya_tipi: str  # "video", "audio"
    sure: Optional[int] = None  # Saniye cinsinden süre
    izlenme_suresi: Optional[int] = None  # Ne kadar izlendi
    son_izleme: Optional[datetime] = None
    kaynak: str = ""  # YouTube, Spotify, vb.
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    @property
    def tamamlanma_yuzdesi(self) -> int:
        """İzlenme yüzdesini hesaplar"""
        if self.sure and self.izlenme_suresi:
            return min(100, int((self.izlenme_suresi / self.sure) * 100))
        return 0
    
    @property
    def domain(self) -> str:
        from urllib.parse import urlparse
        try:
            return urlparse(self.url).netloc
        except:
            return ""
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "url": self.url,
            "baslik": self.baslik,
            "medya_tipi": self.medya_tipi,
            "sure": self.sure,
            "izlenme_suresi": self.izlenme_suresi,
            "son_izleme": self.son_izleme.isoformat() if self.son_izleme else None,
            "kaynak": self.kaynak,
            "tarayici": self.tarayici.value
        }


@dataclass
class DosyaErisimi:
    """Dosya sistemi erişim geçmişi modeli"""
    id: int
    dosya_yolu: str
    dosya_adi: str
    erisim_tipi: str  # "okuma", "yazma", "indirme", "upload"
    erisim_tarihi: datetime
    kaynak_url: Optional[str] = None
    dosya_boyutu: Optional[int] = None
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    @property
    def uzanti(self) -> str:
        """Dosya uzantısını döndürür"""
        import os
        return os.path.splitext(self.dosya_adi)[1].lower()
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "dosya_yolu": self.dosya_yolu,
            "dosya_adi": self.dosya_adi,
            "erisim_tipi": self.erisim_tipi,
            "erisim_tarihi": self.erisim_tarihi.isoformat(),
            "kaynak_url": self.kaynak_url,
            "dosya_boyutu": self.dosya_boyutu,
            "tarayici": self.tarayici.value
        }


@dataclass
class GizliModIzi:
    """Incognito/Özel mod iz modeli"""
    id: int
    iz_tipi: str  # "dns_cache", "memory_dump", "temp_file", "registry"
    aciklama: str
    kanit: str  # Bulunan kanıt
    tespit_tarihi: datetime
    guvenilirlik: int = 0  # 0-100
    tarayici: Optional[TarayiciTipi] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "iz_tipi": self.iz_tipi,
            "aciklama": self.aciklama,
            "kanit": self.kanit,
            "tespit_tarihi": self.tespit_tarihi.isoformat(),
            "guvenilirlik": self.guvenilirlik,
            "tarayici": self.tarayici.value if self.tarayici else None
        }


@dataclass
class SilmeGirisimi:
    """Geçmiş silme girişimi tespiti modeli"""
    id: int
    silme_tipi: str  # "gecmis", "cerez", "cache", "tam_temizlik"
    tespit_yontemi: str  # "bos_db", "timestamp_uyumsuzlugu", "wal_analizi"
    tahmin_tarihi: Optional[datetime] = None  # Silme işleminin tahmini zamanı
    tespit_tarihi: datetime = field(default_factory=datetime.now)
    detaylar: str = ""
    guvenilirlik: int = 0
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "silme_tipi": self.silme_tipi,
            "tespit_yontemi": self.tespit_yontemi,
            "tahmin_tarihi": self.tahmin_tarihi.isoformat() if self.tahmin_tarihi else None,
            "tespit_tarihi": self.tespit_tarihi.isoformat(),
            "detaylar": self.detaylar,
            "guvenilirlik": self.guvenilirlik,
            "tarayici": self.tarayici.value
        }


@dataclass
class DNSKaydi:
    """DNS önbellek kaydı modeli"""
    id: int
    domain: str
    ip_adresi: str
    ttl: int  # Time to live (saniye)
    kayit_tipi: str = "A"  # A, AAAA, CNAME, vb.
    sorgu_tarihi: Optional[datetime] = None
    kaynak: str = "system"  # "system", "chrome", "firefox"
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "domain": self.domain,
            "ip_adresi": self.ip_adresi,
            "ttl": self.ttl,
            "kayit_tipi": self.kayit_tipi,
            "sorgu_tarihi": self.sorgu_tarihi.isoformat() if self.sorgu_tarihi else None,
            "kaynak": self.kaynak
        }


@dataclass
class ServiceWorkerCache:
    """Service Worker / PWA önbellek modeli"""
    id: int
    origin: str
    cache_adi: str
    url: str
    icerik_tipi: str  # "script", "style", "image", "document", "font"
    boyut: int = 0
    olusturma_tarihi: Optional[datetime] = None
    tarayici: TarayiciTipi = TarayiciTipi.CHROME
    profil: str = "Default"
    
    @property
    def domain(self) -> str:
        from urllib.parse import urlparse
        try:
            return urlparse(self.origin).netloc
        except:
            return self.origin
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "origin": self.origin,
            "cache_adi": self.cache_adi,
            "url": self.url,
            "icerik_tipi": self.icerik_tipi,
            "boyut": self.boyut,
            "olusturma_tarihi": self.olusturma_tarihi.isoformat() if self.olusturma_tarihi else None,
            "tarayici": self.tarayici.value
        }


@dataclass
class TaramaSonucu:
    """Önbellek için tarama sonucu modeli"""
    tarama_id: str
    tarama_tarihi: datetime
    tarayici: str
    profil: str
    veri_sayilari: dict  # {"gecmis": 100, "cerez": 50, ...}
    hash_degeri: str  # Veri bütünlüğü için
    
    def to_dict(self) -> dict:
        return {
            "tarama_id": self.tarama_id,
            "tarama_tarihi": self.tarama_tarihi.isoformat(),
            "tarayici": self.tarayici,
            "profil": self.profil,
            "veri_sayilari": self.veri_sayilari,
            "hash_degeri": self.hash_degeri
        }
