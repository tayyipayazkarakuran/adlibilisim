# Konfigürasyon modülü
