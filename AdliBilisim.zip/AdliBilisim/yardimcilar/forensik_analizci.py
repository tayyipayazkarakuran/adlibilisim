# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Forensik Analiz Modülü

Silme girişimi tespiti, gizli mod izleri ve DNS cache analizi.
"""

import os
import subprocess
import sqlite3
import tempfile
import shutil
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional


class ForensikAnalizci:
    """Gelişmiş forensik analiz sınıfı"""
    
    def __init__(self):
        self.hatalar: List[str] = []
    
    def dns_cache_oku(self) -> List[Dict[str, Any]]:
        """Sistem DNS önbelleğini okur (macOS/Windows)"""
        kayitlar = []
        
        try:
            import platform
            sistem = platform.system()
            
            if sistem == "Darwin":  # macOS
                kayitlar = self._macos_dns_cache()
            elif sistem == "Windows":
                kayitlar = self._windows_dns_cache()
            elif sistem == "Linux":
                kayitlar = self._linux_dns_cache()
                
        except Exception as e:
            self.hatalar.append(f"DNS cache okuma hatası: {str(e)}")
        
        return kayitlar
    
    def _macos_dns_cache(self) -> List[Dict[str, Any]]:
        """macOS DNS cache oku"""
        kayitlar = []
        try:
            # scutil ile DNS bilgisi
            result = subprocess.run(
                ["scutil", "--dns"],
                capture_output=True, text=True, timeout=10
            )
            
            if result.returncode == 0:
                current_domain = None
                for line in result.stdout.split('\n'):
                    line = line.strip()
                    if 'domain' in line.lower():
                        parts = line.split(':')
                        if len(parts) > 1:
                            current_domain = parts[1].strip()
                    elif 'nameserver' in line.lower() and current_domain:
                        parts = line.split(':')
                        if len(parts) > 1:
                            ip = parts[1].strip().split('[')[0].strip()
                            kayitlar.append({
                                'domain': current_domain,
                                'ip_adresi': ip,
                                'ttl': 0,
                                'kayit_tipi': 'NS',
                                'kaynak': 'system'
                            })
            
            # dscacheutil ile cache
            result2 = subprocess.run(
                ["dscacheutil", "-cachedump", "-entries", "Host"],
                capture_output=True, text=True, timeout=10
            )
            if result2.returncode == 0:
                lines = result2.stdout.split('\n')
                for i, line in enumerate(lines):
                    if 'name:' in line:
                        domain = line.split(':', 1)[1].strip()
                        ip = ""
                        for j in range(i+1, min(i+5, len(lines))):
                            if 'ip_address:' in lines[j]:
                                ip = lines[j].split(':', 1)[1].strip()
                                break
                        if domain and ip:
                            kayitlar.append({
                                'domain': domain,
                                'ip_adresi': ip,
                                'ttl': 300,
                                'kayit_tipi': 'A',
                                'kaynak': 'dscacheutil'
                            })
                            
        except subprocess.TimeoutExpired:
            self.hatalar.append("DNS cache okuma zaman aşımı")
        except Exception as e:
            self.hatalar.append(f"macOS DNS hatası: {str(e)}")
        
        return kayitlar
    
    def _windows_dns_cache(self) -> List[Dict[str, Any]]:
        """Windows DNS cache oku"""
        kayitlar = []
        try:
            result = subprocess.run(
                ["ipconfig", "/displaydns"],
                capture_output=True, text=True, timeout=30, shell=True
            )
            
            if result.returncode == 0:
                current_record = {}
                for line in result.stdout.split('\n'):
                    line = line.strip()
                    if 'Record Name' in line or 'Kayıt Adı' in line:
                        if current_record.get('domain'):
                            kayitlar.append(current_record)
                        current_record = {'domain': line.split(':', 1)[1].strip()}
                    elif 'A (Host) Record' in line or 'A Record' in line:
                        ip = line.split(':', 1)[1].strip() if ':' in line else ""
                        current_record['ip_adresi'] = ip
                        current_record['kayit_tipi'] = 'A'
                    elif 'Time To Live' in line or 'TTL' in line:
                        ttl = line.split(':', 1)[1].strip() if ':' in line else "0"
                        current_record['ttl'] = int(ttl) if ttl.isdigit() else 0
                
                if current_record.get('domain'):
                    kayitlar.append(current_record)
                    
        except Exception as e:
            self.hatalar.append(f"Windows DNS hatası: {str(e)}")
        
        return kayitlar
    
    def _linux_dns_cache(self) -> List[Dict[str, Any]]:
        """Linux DNS cache oku (systemd-resolved)"""
        kayitlar = []
        try:
            result = subprocess.run(
                ["resolvectl", "statistics"],
                capture_output=True, text=True, timeout=10
            )
            # Linux'ta doğrudan cache okumak zor, /etc/hosts kontrolü
            hosts_path = Path("/etc/hosts")
            if hosts_path.exists():
                with open(hosts_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            parts = line.split()
                            if len(parts) >= 2:
                                kayitlar.append({
                                    'domain': parts[1],
                                    'ip_adresi': parts[0],
                                    'ttl': 0,
                                    'kayit_tipi': 'A',
                                    'kaynak': 'hosts'
                                })
        except Exception as e:
            self.hatalar.append(f"Linux DNS hatası: {str(e)}")
        
        return kayitlar
    
    def silme_girisimi_tespit(self, db_yolu: Path) -> List[Dict[str, Any]]:
        """Geçmiş silme girişimlerini tespit eder"""
        tespitler = []
        
        if not db_yolu.exists():
            return tespitler
        
        try:
            # Geçici kopyaya al
            gecici = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
            gecici_yol = Path(gecici.name)
            gecici.close()
            shutil.copy2(db_yolu, gecici_yol)
            
            conn = sqlite3.connect(str(gecici_yol))
            cursor = conn.cursor()
            
            # 1. Boş tablo kontrolü
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tablolar = cursor.fetchall()
            
            for (tablo,) in tablolar:
                if tablo.startswith('sqlite_'):
                    continue
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {tablo}")
                    sayim = cursor.fetchone()[0]
                    if sayim == 0:
                        tespitler.append({
                            'silme_tipi': 'tablo_bosaltma',
                            'tespit_yontemi': 'bos_tablo',
                            'detaylar': f"'{tablo}' tablosu boş",
                            'guvenilirlik': 60
                        })
                except:
                    pass
            
            # 2. Veritabanı boyutu vs kayıt sayısı kontrolü
            db_boyut = db_yolu.stat().st_size
            toplam_kayit = 0
            for (tablo,) in tablolar:
                if not tablo.startswith('sqlite_'):
                    try:
                        cursor.execute(f"SELECT COUNT(*) FROM {tablo}")
                        toplam_kayit += cursor.fetchone()[0]
                    except:
                        pass
            
            # Eğer veritabanı büyük ama kayıt az ise
            if db_boyut > 100000 and toplam_kayit < 10:
                tespitler.append({
                    'silme_tipi': 'toplu_silme',
                    'tespit_yontemi': 'boyut_uyumsuzlugu',
                    'detaylar': f"DB boyutu: {db_boyut} byte, kayıt: {toplam_kayit}",
                    'guvenilirlik': 70
                })
            
            # 3. Timestamp boşlukları kontrolü
            for (tablo,) in tablolar:
                if tablo in ['urls', 'visits', 'moz_places', 'moz_historyvisits']:
                    try:
                        zaman_sutunu = 'visit_time' if 'visit' in tablo else 'last_visit_time'
                        cursor.execute(f"""
                            SELECT {zaman_sutunu} FROM {tablo} 
                            WHERE {zaman_sutunu} > 0 
                            ORDER BY {zaman_sutunu}
                        """)
                        zamanlar = [r[0] for r in cursor.fetchall()]
                        
                        # Büyük boşluklar ara (7 günden fazla)
                        for i in range(1, len(zamanlar)):
                            fark = zamanlar[i] - zamanlar[i-1]
                            # Chrome timestamp mikrosaniye
                            if fark > 7 * 24 * 60 * 60 * 1000000:
                                tespitler.append({
                                    'silme_tipi': 'kismi_silme',
                                    'tespit_yontemi': 'timestamp_boslugu',
                                    'detaylar': f"7+ günlük boşluk tespit edildi",
                                    'guvenilirlik': 50
                                })
                                break
                    except:
                        pass
            
            conn.close()
            os.unlink(gecici_yol)
            
        except Exception as e:
            self.hatalar.append(f"Silme tespiti hatası: {str(e)}")
        
        return tespitler
    
    def gizli_mod_izleri_ara(self) -> List[Dict[str, Any]]:
        """Incognito/Özel mod kullanım izlerini arar"""
        izler = []
        
        try:
            import platform
            sistem = platform.system()
            
            # 1. Geçici dosya konumlarını kontrol et
            temp_dizinler = [
                Path(tempfile.gettempdir()),
            ]
            
            if sistem == "Darwin":
                temp_dizinler.extend([
                    Path.home() / "Library" / "Caches",
                    Path("/private/var/folders")
                ])
            elif sistem == "Windows":
                temp_dizinler.extend([
                    Path(os.environ.get('LOCALAPPDATA', '')) / "Temp",
                    Path(os.environ.get('TEMP', ''))
                ])
            
            # Chrome incognito izleri
            incognito_kaliplari = [
                "*incognito*", "*private*", "*InPrivate*",
                "*.tmp", "*chrome*tmp*"
            ]
            
            for dizin in temp_dizinler:
                if not dizin.exists():
                    continue
                for kalip in incognito_kaliplari:
                    try:
                        for dosya in dizin.glob(kalip):
                            if dosya.is_file():
                                izler.append({
                                    'iz_tipi': 'temp_file',
                                    'aciklama': f"Şüpheli geçici dosya: {dosya.name}",
                                    'kanit': str(dosya),
                                    'guvenilirlik': 40
                                })
                    except:
                        pass
            
            # 2. DNS cache'de private browsing izleri
            dns_kayitlari = self.dns_cache_oku()
            gizli_domainler = ['duckduckgo.com', 'startpage.com', 'brave.com']
            for kayit in dns_kayitlari:
                domain = kayit.get('domain', '').lower()
                if any(gd in domain for gd in gizli_domainler):
                    izler.append({
                        'iz_tipi': 'dns_cache',
                        'aciklama': f"Gizlilik odaklı site DNS kaydı: {domain}",
                        'kanit': kayit.get('ip_adresi', ''),
                        'guvenilirlik': 30
                    })
            
        except Exception as e:
            self.hatalar.append(f"Gizli mod izi arama hatası: {str(e)}")
        
        return izler


class OtomatikDoldurmaOkuyucu:
    """Otomatik doldurma verilerini okuma sınıfı"""
    
    def __init__(self):
        self.hatalar: List[str] = []
    
    def chrome_autofill_oku(self, profil_dizini: Path) -> List[Dict[str, Any]]:
        """Chrome Web Data veritabanından autofill verilerini okur"""
        veriler = []
        web_data = profil_dizini / "Web Data"
        
        if not web_data.exists():
            return veriler
        
        try:
            gecici = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
            gecici_yol = Path(gecici.name)
            gecici.close()
            shutil.copy2(web_data, gecici_yol)
            
            conn = sqlite3.connect(str(gecici_yol))
            cursor = conn.cursor()
            
            # autofill tablosu
            try:
                cursor.execute("""
                    SELECT name, value, count, date_last_used, date_created
                    FROM autofill
                    ORDER BY count DESC
                    LIMIT 500
                """)
                for row in cursor.fetchall():
                    tip = self._tip_tahmin(row[0], row[1])
                    veriler.append({
                        'tip': tip,
                        'alan': row[0],
                        'deger': row[1],
                        'kullanim_sayisi': row[2],
                        'son_kullanim': self._chrome_timestamp(row[3]),
                        'olusturma_tarihi': self._chrome_timestamp(row[4])
                    })
            except Exception as e:
                self.hatalar.append(f"autofill tablo hatası: {str(e)}")
            
            # autofill_profiles tablosu (adresler)
            try:
                cursor.execute("""
                    SELECT 
                        full_name, company_name, street_address,
                        city, state, zipcode, country_code,
                        phone_number, email_address
                    FROM autofill_profiles
                """)
                for row in cursor.fetchall():
                    if row[0]:
                        veriler.append({'tip': 'isim', 'alan': 'full_name', 'deger': row[0]})
                    if row[2]:
                        veriler.append({'tip': 'adres', 'alan': 'street_address', 'deger': row[2]})
                    if row[3]:
                        veriler.append({'tip': 'adres', 'alan': 'city', 'deger': row[3]})
                    if row[7]:
                        veriler.append({'tip': 'telefon', 'alan': 'phone', 'deger': row[7]})
                    if row[8]:
                        veriler.append({'tip': 'email', 'alan': 'email', 'deger': row[8]})
            except:
                pass
            
            # credit_cards tablosu
            try:
                cursor.execute("""
                    SELECT name_on_card, card_number_encrypted, 
                           expiration_month, expiration_year
                    FROM credit_cards
                """)
                for row in cursor.fetchall():
                    veriler.append({
                        'tip': 'kredi_karti',
                        'alan': 'card_holder',
                        'deger': row[0] or "(Şifreli)",
                        'kullanim_sayisi': 0
                    })
            except:
                pass
            
            conn.close()
            os.unlink(gecici_yol)
            
        except Exception as e:
            self.hatalar.append(f"Chrome autofill hatası: {str(e)}")
        
        return veriler
    
    def _tip_tahmin(self, alan: str, deger: str) -> str:
        """Alan ve değere göre tip tahmin eder"""
        alan_lower = alan.lower()
        
        if any(x in alan_lower for x in ['email', 'e-mail', 'mail']):
            return 'email'
        elif any(x in alan_lower for x in ['phone', 'tel', 'mobile']):
            return 'telefon'
        elif any(x in alan_lower for x in ['address', 'street', 'city', 'zip', 'adres']):
            return 'adres'
        elif any(x in alan_lower for x in ['name', 'isim', 'ad']):
            return 'isim'
        elif any(x in alan_lower for x in ['card', 'credit', 'kart']):
            return 'kredi_karti'
        
        # Değer analizi
        if '@' in deger and '.' in deger:
            return 'email'
        elif deger.replace('+', '').replace('-', '').replace(' ', '').isdigit() and len(deger) >= 10:
            return 'telefon'
        
        return 'diger'
    
    def _chrome_timestamp(self, timestamp) -> Optional[datetime]:
        """Chrome timestamp'ını datetime'a çevirir"""
        if not timestamp:
            return None
        try:
            # Chrome epoch: 1601-01-01, mikrosaniye
            return datetime(1601, 1, 1) + timedelta(microseconds=timestamp)
        except:
            return None


class MedyaGecmisiOkuyucu:
    """Medya geçmişi okuma sınıfı"""
    
    def __init__(self):
        self.hatalar: List[str] = []
        
        # Bilinen medya siteleri
        self.video_siteleri = [
            'youtube.com', 'youtu.be', 'vimeo.com', 'dailymotion.com',
            'twitch.tv', 'netflix.com', 'primevideo.com', 'disneyplus.com',
            'hulu.com', 'hbomax.com', 'peacocktv.com'
        ]
        self.muzik_siteleri = [
            'spotify.com', 'music.youtube.com', 'soundcloud.com',
            'deezer.com', 'tidal.com', 'pandora.com', 'apple.com/music'
        ]
    
    def gecmisten_medya_cikart(self, gecmis_kayitlari: List) -> List[Dict[str, Any]]:
        """Geçmiş kayıtlarından medya izlemelerini çıkarır"""
        medya_listesi = []
        
        for kayit in gecmis_kayitlari:
            url = kayit.url.lower() if hasattr(kayit, 'url') else str(kayit.get('url', '')).lower()
            baslik = kayit.baslik if hasattr(kayit, 'baslik') else kayit.get('baslik', '')
            
            medya_tipi = None
            kaynak = ""
            
            # Video siteleri kontrolü
            for site in self.video_siteleri:
                if site in url:
                    medya_tipi = "video"
                    kaynak = site.split('.')[0].title()
                    break
            
            # Müzik siteleri kontrolü
            if not medya_tipi:
                for site in self.muzik_siteleri:
                    if site in url:
                        medya_tipi = "audio"
                        kaynak = site.split('.')[0].title()
                        break
            
            # URL'de medya uzantısı kontrolü
            if not medya_tipi:
                if any(ext in url for ext in ['.mp4', '.webm', '.avi', '.mkv', '.mov']):
                    medya_tipi = "video"
                elif any(ext in url for ext in ['.mp3', '.wav', '.flac', '.m4a', '.ogg']):
                    medya_tipi = "audio"
            
            if medya_tipi:
                medya_listesi.append({
                    'url': kayit.url if hasattr(kayit, 'url') else kayit.get('url', ''),
                    'baslik': baslik,
                    'medya_tipi': medya_tipi,
                    'kaynak': kaynak,
                    'son_izleme': kayit.ziyaret_tarihi if hasattr(kayit, 'ziyaret_tarihi') else None
                })
        
        return medya_listesi


from datetime import timedelta
