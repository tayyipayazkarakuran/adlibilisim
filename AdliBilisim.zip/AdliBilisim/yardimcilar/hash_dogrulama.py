"""
Adli Bilişim Forensik Aracı - Hash Doğrulama Modülü

SHA-256 hash hesaplama ve veri bütünlüğü doğrulama.
"""

import hashlib
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime


class HashDogrulayici:
    """Hash hesaplama ve doğrulama sınıfı"""
    
    @staticmethod
    def dosya_hash_hesapla(dosya_yolu: str, algoritma: str = "sha256") -> Optional[str]:
        """
        Dosyanın hash değerini hesaplar
        
        Args:
            dosya_yolu: Dosya yolu
            algoritma: Hash algoritması (sha256, md5, sha1)
            
        Returns:
            Hexadecimal hash değeri veya None
        """
        try:
            yol = Path(dosya_yolu)
            if not yol.exists():
                return None
            
            if algoritma == "sha256":
                hasher = hashlib.sha256()
            elif algoritma == "md5":
                hasher = hashlib.md5()
            elif algoritma == "sha1":
                hasher = hashlib.sha1()
            else:
                hasher = hashlib.sha256()
            
            with open(yol, 'rb') as f:
                # Büyük dosyalar için chunk okuma
                for chunk in iter(lambda: f.read(8192), b''):
                    hasher.update(chunk)
            
            return hasher.hexdigest()
        except Exception:
            return None
    
    @staticmethod
    def metin_hash_hesapla(metin: str, algoritma: str = "sha256") -> str:
        """
        Metin için hash değeri hesaplar
        
        Args:
            metin: Hash'lenecek metin
            algoritma: Hash algoritması
            
        Returns:
            Hexadecimal hash değeri
        """
        if algoritma == "sha256":
            hasher = hashlib.sha256()
        elif algoritma == "md5":
            hasher = hashlib.md5()
        elif algoritma == "sha1":
            hasher = hashlib.sha1()
        else:
            hasher = hashlib.sha256()
        
        hasher.update(metin.encode('utf-8'))
        return hasher.hexdigest()
    
    @staticmethod
    def veri_hash_hesapla(veri: bytes, algoritma: str = "sha256") -> str:
        """
        Binary veri için hash değeri hesaplar
        
        Args:
            veri: Hash'lenecek binary veri
            algoritma: Hash algoritması
            
        Returns:
            Hexadecimal hash değeri
        """
        if algoritma == "sha256":
            hasher = hashlib.sha256()
        elif algoritma == "md5":
            hasher = hashlib.md5()
        elif algoritma == "sha1":
            hasher = hashlib.sha1()
        else:
            hasher = hashlib.sha256()
        
        hasher.update(veri)
        return hasher.hexdigest()
    
    @staticmethod
    def hash_dogrula(dosya_yolu: str, beklenen_hash: str, algoritma: str = "sha256") -> bool:
        """
        Dosyanın hash değerini doğrular
        
        Args:
            dosya_yolu: Dosya yolu
            beklenen_hash: Beklenen hash değeri
            algoritma: Hash algoritması
            
        Returns:
            Doğrulama başarılı ise True
        """
        hesaplanan = HashDogrulayici.dosya_hash_hesapla(dosya_yolu, algoritma)
        if hesaplanan is None:
            return False
        return hesaplanan.lower() == beklenen_hash.lower()
    
    @staticmethod
    def kayit_hash_hesapla(kayit: Dict[str, Any]) -> str:
        """
        Bir veri kaydının hash'ini hesaplar (veri bütünlüğü için)
        
        Args:
            kayit: Dictionary formatında veri kaydı
            
        Returns:
            Hash değeri
        """
        # Dictionary'yi tutarlı bir stringe çevir
        sorted_keys = sorted(kayit.keys())
        veri = "|".join(f"{k}:{kayit[k]}" for k in sorted_keys)
        return HashDogrulayici.metin_hash_hesapla(veri)
    
    @staticmethod
    def forensik_rapor_olustur(dosya_yolu: str) -> Dict[str, Any]:
        """
        Dosya için forensik hash raporu oluşturur
        
        Args:
            dosya_yolu: Dosya yolu
            
        Returns:
            Forensik rapor dictionary
        """
        yol = Path(dosya_yolu)
        
        rapor = {
            "dosya_yolu": str(yol.absolute()),
            "dosya_adi": yol.name,
            "hesaplama_zamani": datetime.now().isoformat(),
            "dosya_mevcut": yol.exists()
        }
        
        if yol.exists():
            stat = yol.stat()
            rapor["dosya_boyutu"] = stat.st_size
            rapor["olusturma_zamani"] = datetime.fromtimestamp(stat.st_ctime).isoformat()
            rapor["degistirme_zamani"] = datetime.fromtimestamp(stat.st_mtime).isoformat()
            rapor["sha256"] = HashDogrulayici.dosya_hash_hesapla(dosya_yolu, "sha256")
            rapor["md5"] = HashDogrulayici.dosya_hash_hesapla(dosya_yolu, "md5")
            rapor["sha1"] = HashDogrulayici.dosya_hash_hesapla(dosya_yolu, "sha1")
        
        return rapor
