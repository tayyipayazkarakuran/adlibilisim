# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Sistem Analiz Modülü

USB geçmişi, dosya sistemi analizi ve indirilen dosyaların kontrolü.
"""

import os
import subprocess
import platform
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional
from modeller.veri_modelleri import DosyaErisimi

class SistemAnalizci:
    """Sistem seviyesi analizleri yapar"""
    
    def __init__(self):
        self.hatalar: List[str] = []
        self.os_type = platform.system()

    def usb_gecmisi_getir(self) -> List[Dict[str, Any]]:
        """Bağlı USB cihazları ve geçmişi (Platforma göre)"""
        usb_listesi = []
        
        try:
            if self.os_type == "Darwin": # macOS
                # ioreg ile bağlı cihazlar
                result = subprocess.run(
                    ['ioreg', '-p', 'IOUSB', '-w0', '-l'],
                    capture_output=True, text=True
                )
                
                if result.returncode == 0:
                    current_dev = {}
                    for line in result.stdout.split('\n'):
                        if "+-o" in line:
                            # Yeni cihaz başlangıcı, öncekini kaydet
                            if current_dev.get("ad"):
                                usb_listesi.append(current_dev)
                            
                            name = line.split("+-o")[1].split("<")[0].strip()
                            current_dev = {
                                "ad": name,
                                "durum": "Bağlı",
                                "detay": line.strip()
                            }
                        elif current_dev:
                            if '"USB Serial Number" =' in line:
                                current_dev["seri_no"] = line.split('=')[1].strip().replace('"', '')
                            elif '"idVendor" =' in line:
                                current_dev["vendor_id"] = line.split('=')[1].strip()
                            elif '"idProduct" =' in line:
                                current_dev["product_id"] = line.split('=')[1].strip()
                    
                    if current_dev.get("ad"):
                        usb_listesi.append(current_dev)
                
                # Geçmiş logları (log show) - Bu genelde root gerektirir veya çok yavaştır
                # Basitlik için sadece bağlıları döndürüyoruz.
                
            elif self.os_type == "Windows":
                # Windows Registry veya WMI kullanılabilir
                # Şimdilik pas geçiyoruz veya basit WMI
                pass
                
        except Exception as e:
            self.hatalar.append(f"USB analiz hatası: {str(e)}")
            
        return usb_listesi

    def indirilen_dosya_kontrol(self, dosya_yolu: str) -> Dict[str, Any]:
        """İndirilen bir dosyanın diskte hala var olup olmadığını kontrol eder"""
        path = Path(dosya_yolu)
        durum = {
            "mevcut": False,
            "yol": dosya_yolu,
            "boyut": 0,
            "son_erisim": None,
            "hash": None,
            "not": ""
        }
        
        if not dosya_yolu:
            durum["not"] = "Yol boş"
            return durum
            
        if path.exists():
            durum["mevcut"] = True
            try:
                stat = path.stat()
                durum["boyut"] = stat.st_size
                durum["son_erisim"] = datetime.fromtimestamp(stat.st_atime)
                durum["olusturma"] = datetime.fromtimestamp(stat.st_ctime)
            except Exception as e:
                durum["not"] = f"Dosya özelliklerine erişilemedi: {e}"
        else:
            durum["not"] = "Dosya bulunamadı (Silinmiş veya taşınmış)"
            
        return durum

    def dosya_hash_al(self, dosya_yolu: str, algoritma="md5") -> Optional[str]:
        """Dosya hash değeri hesaplar"""
        import hashlib
        path = Path(dosya_yolu)
        if not path.exists() or not path.is_file():
            return None
            
        try:
            hash_func = hashlib.md5() if algoritma == "md5" else hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_func.update(chunk)
            return hash_func.hexdigest()
        except:
            return None
