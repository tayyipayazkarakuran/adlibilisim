# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - SQLite Veri Kurtarma Modülü

SQLite veritabanlarından silinmiş kayıtları kurtarma.
WAL dosyaları ve freelist page'leri taranır.
"""

import sqlite3
import os
import struct
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
import tempfile
import shutil


class SQLiteKurtarici:
    """SQLite veritabanlarından silinmiş veri kurtarma sınıfı"""
    
    def __init__(self):
        self.hatalar: List[str] = []
        self.kurtarilan_sayisi = 0
    
    def veritabani_kopyala(self, db_yolu: Path) -> Optional[Path]:
        """Veritabanını geçici dizine kopyalar"""
        if not db_yolu.exists():
            return None
        
        try:
            gecici = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
            gecici_yol = Path(gecici.name)
            gecici.close()
            shutil.copy2(db_yolu, gecici_yol)
            return gecici_yol
        except Exception as e:
            self.hatalar.append(f"Kopyalama hatası: {str(e)}")
            return None
    
    def wal_dosyasi_tara(self, db_yolu: Path) -> List[Dict[str, Any]]:
        """
        WAL (Write-Ahead Log) dosyasını tarar.
        WAL dosyası commit edilmemiş ve silinmiş verileri içerebilir.
        """
        kurtarilan = []
        wal_yolu = Path(str(db_yolu) + "-wal")
        
        if not wal_yolu.exists():
            return kurtarilan
        
        try:
            with open(wal_yolu, 'rb') as f:
                # WAL header kontrolü
                header = f.read(32)
                if len(header) < 32:
                    return kurtarilan
                
                # Magic number kontrolü
                magic = struct.unpack('>I', header[0:4])[0]
                if magic not in (0x377F0683, 0x377F0682):
                    return kurtarilan
                
                # Page size
                page_size = struct.unpack('>I', header[8:12])[0]
                
                # Frame'leri oku
                f.seek(32)  # Header'dan sonra
                frame_id = 0
                
                while True:
                    frame_header = f.read(24)
                    if len(frame_header) < 24:
                        break
                    
                    page_data = f.read(page_size)
                    if len(page_data) < page_size:
                        break
                    
                    # Page'den veri çıkar
                    veriler = self._page_verilerini_cikart(page_data)
                    for veri in veriler:
                        veri['kaynak'] = 'WAL'
                        veri['frame_id'] = frame_id
                        kurtarilan.append(veri)
                    
                    frame_id += 1
                    
        except Exception as e:
            self.hatalar.append(f"WAL okuma hatası: {str(e)}")
        
        return kurtarilan
    
    def freelist_tara(self, db_yolu: Path) -> List[Dict[str, Any]]:
        """
        SQLite freelist (boş sayfa listesi) taraması.
        Silinmiş veriler genellikle freelist'e taşınır.
        """
        kurtarilan = []
        gecici_yol = self.veritabani_kopyala(db_yolu)
        
        if gecici_yol is None:
            return kurtarilan
        
        try:
            with open(gecici_yol, 'rb') as f:
                # SQLite header'ı oku
                header = f.read(100)
                if len(header) < 100:
                    return kurtarilan
                
                # Magic string kontrolü
                if header[0:16] != b'SQLite format 3\x00':
                    return kurtarilan
                
                # Page size (offset 16-17)
                page_size = struct.unpack('>H', header[16:18])[0]
                if page_size == 1:
                    page_size = 65536
                
                # Total pages (offset 28-31)
                total_pages = struct.unpack('>I', header[28:32])[0]
                
                # Freelist trunk page (offset 32-35)
                freelist_trunk = struct.unpack('>I', header[32:36])[0]
                
                # Freelist page count (offset 36-39)
                freelist_count = struct.unpack('>I', header[36:40])[0]
                
                if freelist_count == 0:
                    return kurtarilan
                
                # Freelist page'leri tara
                visited_pages = set()
                current_trunk = freelist_trunk
                
                while current_trunk != 0 and current_trunk not in visited_pages:
                    visited_pages.add(current_trunk)
                    
                    # Trunk page'e git
                    f.seek((current_trunk - 1) * page_size)
                    trunk_data = f.read(page_size)
                    
                    if len(trunk_data) < 8:
                        break
                    
                    # Sonraki trunk page
                    next_trunk = struct.unpack('>I', trunk_data[0:4])[0]
                    
                    # Leaf page sayısı
                    leaf_count = struct.unpack('>I', trunk_data[4:8])[0]
                    
                    # Leaf page'leri oku
                    for i in range(min(leaf_count, (page_size - 8) // 4)):
                        offset = 8 + i * 4
                        if offset + 4 <= len(trunk_data):
                            leaf_page = struct.unpack('>I', trunk_data[offset:offset+4])[0]
                            
                            if leaf_page > 0 and leaf_page <= total_pages:
                                # Leaf page verisini oku
                                f.seek((leaf_page - 1) * page_size)
                                leaf_data = f.read(page_size)
                                
                                # Page'den veri çıkar
                                veriler = self._page_verilerini_cikart(leaf_data)
                                for veri in veriler:
                                    veri['kaynak'] = 'Freelist'
                                    veri['page_no'] = leaf_page
                                    kurtarilan.append(veri)
                    
                    current_trunk = next_trunk
                    
        except Exception as e:
            self.hatalar.append(f"Freelist okuma hatası: {str(e)}")
        finally:
            if gecici_yol and gecici_yol.exists():
                try:
                    os.unlink(gecici_yol)
                except:
                    pass
        
        return kurtarilan
    
    def _page_verilerini_cikart(self, page_data: bytes) -> List[Dict[str, Any]]:
        """
        Bir SQLite page'inden okunabilir verileri çıkarır.
        URL'ler, başlıklar ve diğer metin verilerini arar.
        """
        veriler = []
        
        try:
            # Metin kalıplarını ara
            # URL kalıbı
            url_kaliplari = [b'http://', b'https://', b'file://']
            
            for kalip in url_kaliplari:
                pos = 0
                while True:
                    idx = page_data.find(kalip, pos)
                    if idx == -1:
                        break
                    
                    # URL sonunu bul
                    end = idx
                    for i in range(idx, min(idx + 2048, len(page_data))):
                        byte = page_data[i]
                        # URL'de geçerli olmayan karakterde dur
                        if byte < 32 or byte > 126 or chr(byte) in ' \t\n\r"\'<>':
                            end = i
                            break
                        end = i + 1
                    
                    if end > idx + 10:  # Minimum URL uzunluğu
                        try:
                            url = page_data[idx:end].decode('utf-8', errors='ignore')
                            if self._gecerli_url_mi(url):
                                veriler.append({
                                    'tip': 'url',
                                    'url': url,
                                    'offset': idx
                                })
                        except:
                            pass
                    
                    pos = end
            
            # Başlık/metin verisi ara (uzun string'ler)
            # Ardışık ASCII karakterleri bul
            metin_baslangic = -1
            for i in range(len(page_data)):
                byte = page_data[i]
                if 32 <= byte <= 126:  # Yazdırılabilir ASCII
                    if metin_baslangic == -1:
                        metin_baslangic = i
                else:
                    if metin_baslangic != -1:
                        uzunluk = i - metin_baslangic
                        if uzunluk >= 20:  # Minimum metin uzunluğu
                            try:
                                metin = page_data[metin_baslangic:i].decode('utf-8', errors='ignore')
                                # URL değilse ve anlamlı görünüyorsa
                                if not metin.startswith(('http://', 'https://')):
                                    # Yalnızca alfanumerik ve boşluk içeriyorsa
                                    if any(c.isalpha() for c in metin):
                                        veriler.append({
                                            'tip': 'metin',
                                            'metin': metin[:500],  # Maksimum 500 karakter
                                            'offset': metin_baslangic
                                        })
                            except:
                                pass
                        metin_baslangic = -1
                        
        except Exception as e:
            pass
        
        return veriler
    
    def _gecerli_url_mi(self, url: str) -> bool:
        """URL'nin geçerli olup olmadığını kontrol eder"""
        if len(url) < 10 or len(url) > 2048:
            return False
        
        # Protokol kontrolü
        if not url.startswith(('http://', 'https://', 'file://')):
            return False
        
        # Domain kontrolü
        from urllib.parse import urlparse
        try:
            parsed = urlparse(url)
            if not parsed.netloc and not url.startswith('file://'):
                return False
            return True
        except:
            return False
    
    def tum_veritabanlarini_tara(self, db_yollari: List[Path]) -> List[Dict[str, Any]]:
        """Birden fazla veritabanını tarar"""
        tum_kurtarilan = []
        
        for db_yolu in db_yollari:
            if not db_yolu.exists():
                continue
            
            # WAL taraması
            wal_sonuclari = self.wal_dosyasi_tara(db_yolu)
            for sonuc in wal_sonuclari:
                sonuc['veritabani'] = db_yolu.name
                tum_kurtarilan.append(sonuc)
            
            # Freelist taraması
            freelist_sonuclari = self.freelist_tara(db_yolu)
            for sonuc in freelist_sonuclari:
                sonuc['veritabani'] = db_yolu.name
                tum_kurtarilan.append(sonuc)
        
        self.kurtarilan_sayisi = len(tum_kurtarilan)
        return tum_kurtarilan
    
    def guvenilirlik_hesapla(self, veri: Dict[str, Any]) -> int:
        """Kurtarılan verinin güvenilirlik skorunu hesaplar (0-100)"""
        skor = 50  # Başlangıç skoru
        
        # URL varsa ve geçerliyse skor artar
        if veri.get('tip') == 'url':
            url = veri.get('url', '')
            if self._gecerli_url_mi(url):
                skor += 30
            if url.startswith('https://'):
                skor += 10
        
        # WAL'dan geldiyse daha güvenilir
        if veri.get('kaynak') == 'WAL':
            skor += 10
        
        return min(skor, 100)
