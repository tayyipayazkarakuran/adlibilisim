# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Önbellek ve İlerleme Yönetimi

Tarama sonuçlarını önbellekleme ve ilerleme takibi.
"""

import json
import hashlib
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional, Callable
import threading


class TaramaOnbellegi:
    """Tarama sonuçlarını önbellekleme sınıfı"""
    
    def __init__(self, onbellek_dizini: Optional[Path] = None):
        if onbellek_dizini is None:
            self.onbellek_dizini = Path.home() / ".adlibilisim" / "cache"
        else:
            self.onbellek_dizini = onbellek_dizini
        
        self.onbellek_dizini.mkdir(parents=True, exist_ok=True)
        self.meta_dosya = self.onbellek_dizini / "meta.json"
        self.meta = self._meta_yukle()
    
    def _meta_yukle(self) -> Dict[str, Any]:
        """Meta bilgilerini yükler"""
        if self.meta_dosya.exists():
            try:
                with open(self.meta_dosya, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {"taramalar": {}, "son_guncelleme": None}
    
    def _meta_kaydet(self):
        """Meta bilgilerini kaydeder"""
        self.meta["son_guncelleme"] = datetime.now().isoformat()
        with open(self.meta_dosya, 'w', encoding='utf-8') as f:
            json.dump(self.meta, f, ensure_ascii=False, indent=2)
    
    def _hash_hesapla(self, veri: Any) -> str:
        """Veri için hash hesaplar"""
        veri_str = json.dumps(veri, sort_keys=True, default=str)
        return hashlib.sha256(veri_str.encode()).hexdigest()[:16]
    
    def tarama_id_olustur(self, tarayici: str, profil: str) -> str:
        """Tarama için benzersiz ID oluşturur"""
        return f"{tarayici}_{profil}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    def kaydet(self, tarama_id: str, veri_tipi: str, veriler: List[Any]):
        """Verileri önbelleğe kaydeder"""
        dosya_adi = f"{tarama_id}_{veri_tipi}.json"
        dosya_yolu = self.onbellek_dizini / dosya_adi
        
        # Serializable hale getir
        kayit_verisi = []
        for v in veriler:
            if hasattr(v, 'to_dict'):
                kayit_verisi.append(v.to_dict())
            elif isinstance(v, dict):
                kayit_verisi.append(v)
            else:
                kayit_verisi.append(str(v))
        
        with open(dosya_yolu, 'w', encoding='utf-8') as f:
            json.dump(kayit_verisi, f, ensure_ascii=False, default=str)
        
        # Meta güncelle
        if tarama_id not in self.meta["taramalar"]:
            self.meta["taramalar"][tarama_id] = {
                "tarih": datetime.now().isoformat(),
                "veri_tipleri": {}
            }
        
        self.meta["taramalar"][tarama_id]["veri_tipleri"][veri_tipi] = {
            "dosya": dosya_adi,
            "sayim": len(veriler),
            "hash": self._hash_hesapla(kayit_verisi)
        }
        self._meta_kaydet()
    
    def yukle(self, tarama_id: str, veri_tipi: str) -> Optional[List[Dict]]:
        """Önbellekten veri yükler"""
        if tarama_id not in self.meta["taramalar"]:
            return None
        
        tarama = self.meta["taramalar"][tarama_id]
        if veri_tipi not in tarama["veri_tipleri"]:
            return None
        
        dosya_adi = tarama["veri_tipleri"][veri_tipi]["dosya"]
        dosya_yolu = self.onbellek_dizini / dosya_adi
        
        if not dosya_yolu.exists():
            return None
        
        try:
            with open(dosya_yolu, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return None
    
    def son_tarama_al(self, tarayici: str = None) -> Optional[str]:
        """En son tarama ID'sini döndürür"""
        taramalar = self.meta.get("taramalar", {})
        if not taramalar:
            return None
        
        # Tarihe göre sırala
        sirali = sorted(
            taramalar.items(),
            key=lambda x: x[1].get("tarih", ""),
            reverse=True
        )
        
        if tarayici:
            for tarama_id, _ in sirali:
                if tarayici.lower() in tarama_id.lower():
                    return tarama_id
        
        return sirali[0][0] if sirali else None
    
    def temizle(self, gun_siniri: int = 7):
        """Eski önbellek dosyalarını temizler"""
        simdi = datetime.now()
        silinecekler = []
        
        for tarama_id, bilgi in self.meta["taramalar"].items():
            try:
                tarih = datetime.fromisoformat(bilgi["tarih"])
                if (simdi - tarih).days > gun_siniri:
                    silinecekler.append(tarama_id)
            except:
                pass
        
        for tarama_id in silinecekler:
            tarama = self.meta["taramalar"][tarama_id]
            for veri_tipi, tip_bilgi in tarama.get("veri_tipleri", {}).items():
                dosya = self.onbellek_dizini / tip_bilgi["dosya"]
                if dosya.exists():
                    try:
                        os.unlink(dosya)
                    except:
                        pass
            del self.meta["taramalar"][tarama_id]
        
        self._meta_kaydet()
        return len(silinecekler)


class IlerlemeYoneticisi:
    """Tarama ilerleme takibi sınıfı"""
    
    def __init__(self, guncelleme_callback: Optional[Callable] = None):
        self.guncelleme_callback = guncelleme_callback
        self.lock = threading.Lock()
        
        self.tarayicilar: Dict[str, Dict[str, Any]] = {}
        self.genel_ilerleme = 0
        self.toplam_adim = 0
        self.tamamlanan_adim = 0
        self.baslangic_zamani: Optional[datetime] = None
        self.durum_mesaji = ""
    
    def baslat(self, tarayici_listesi: List[str]):
        """İlerleme takibini başlatır"""
        with self.lock:
            self.baslangic_zamani = datetime.now()
            self.toplam_adim = len(tarayici_listesi)
            self.tamamlanan_adim = 0
            self.genel_ilerleme = 0
            
            for tarayici in tarayici_listesi:
                self.tarayicilar[tarayici] = {
                    "durum": "bekliyor",
                    "ilerleme": 0,
                    "mesaj": "",
                    "veri_sayisi": 0
                }
        
        self._bildir()
    
    def tarayici_baslat(self, tarayici: str):
        """Bir tarayıcı taramasını başlatır"""
        with self.lock:
            if tarayici in self.tarayicilar:
                self.tarayicilar[tarayici]["durum"] = "taraniyor"
                self.tarayicilar[tarayici]["ilerleme"] = 0
                self.durum_mesaji = f"{tarayici} taranıyor..."
        self._bildir()
    
    def tarayici_ilerleme(self, tarayici: str, ilerleme: int, mesaj: str = ""):
        """Bir tarayıcının ilerlemesini günceller"""
        with self.lock:
            if tarayici in self.tarayicilar:
                self.tarayicilar[tarayici]["ilerleme"] = min(100, ilerleme)
                self.tarayicilar[tarayici]["mesaj"] = mesaj
                self._genel_ilerleme_hesapla()
        self._bildir()
    
    def tarayici_tamamla(self, tarayici: str, veri_sayisi: int = 0):
        """Bir tarayıcı taramasını tamamlar"""
        with self.lock:
            if tarayici in self.tarayicilar:
                self.tarayicilar[tarayici]["durum"] = "tamamlandi"
                self.tarayicilar[tarayici]["ilerleme"] = 100
                self.tarayicilar[tarayici]["veri_sayisi"] = veri_sayisi
                self.tamamlanan_adim += 1
                self._genel_ilerleme_hesapla()
        self._bildir()
    
    def tarayici_hata(self, tarayici: str, hata_mesaji: str):
        """Bir tarayıcı hatasını kaydeder"""
        with self.lock:
            if tarayici in self.tarayicilar:
                self.tarayicilar[tarayici]["durum"] = "hata"
                self.tarayicilar[tarayici]["mesaj"] = hata_mesaji
                self.tamamlanan_adim += 1
                self._genel_ilerleme_hesapla()
        self._bildir()
    
    def _genel_ilerleme_hesapla(self):
        """Genel ilerlemeyi hesaplar"""
        if self.toplam_adim == 0:
            self.genel_ilerleme = 0
            return
        
        toplam_ilerleme = sum(
            t["ilerleme"] for t in self.tarayicilar.values()
        )
        self.genel_ilerleme = toplam_ilerleme / self.toplam_adim
    
    def _bildir(self):
        """Callback ile güncelleme bildirir"""
        if self.guncelleme_callback:
            try:
                self.guncelleme_callback(self.durum_raporu())
            except:
                pass
    
    def durum_raporu(self) -> Dict[str, Any]:
        """Mevcut durumu rapor olarak döndürür"""
        with self.lock:
            gecen_sure = 0
            if self.baslangic_zamani:
                gecen_sure = (datetime.now() - self.baslangic_zamani).total_seconds()
            
            return {
                "genel_ilerleme": self.genel_ilerleme,
                "tamamlanan": self.tamamlanan_adim,
                "toplam": self.toplam_adim,
                "gecen_sure": gecen_sure,
                "durum_mesaji": self.durum_mesaji,
                "tarayicilar": dict(self.tarayicilar)
            }
    
    def tamamlandi_mi(self) -> bool:
        """Taramanın tamamlanıp tamamlanmadığını kontrol eder"""
        with self.lock:
            return self.tamamlanan_adim >= self.toplam_adim


class LazyLoader:
    """Büyük listeler için lazy loading sınıfı"""
    
    def __init__(self, veri_listesi: List[Any], sayfa_boyutu: int = 50):
        self.tum_veri = veri_listesi
        self.sayfa_boyutu = sayfa_boyutu
        self.mevcut_sayfa = 0
        self.toplam_sayfa = (len(veri_listesi) + sayfa_boyutu - 1) // sayfa_boyutu
    
    def sayfa_al(self, sayfa_no: int) -> List[Any]:
        """Belirtilen sayfadaki verileri döndürür"""
        baslangic = sayfa_no * self.sayfa_boyutu
        bitis = min(baslangic + self.sayfa_boyutu, len(self.tum_veri))
        return self.tum_veri[baslangic:bitis]
    
    def sonraki_sayfa(self) -> List[Any]:
        """Sonraki sayfayı döndürür"""
        if self.mevcut_sayfa < self.toplam_sayfa - 1:
            self.mevcut_sayfa += 1
        return self.sayfa_al(self.mevcut_sayfa)
    
    def onceki_sayfa(self) -> List[Any]:
        """Önceki sayfayı döndürür"""
        if self.mevcut_sayfa > 0:
            self.mevcut_sayfa -= 1
        return self.sayfa_al(self.mevcut_sayfa)
    
    def ilk_sayfa(self) -> List[Any]:
        """İlk sayfayı döndürür"""
        self.mevcut_sayfa = 0
        return self.sayfa_al(0)
    
    def son_sayfa(self) -> List[Any]:
        """Son sayfayı döndürür"""
        self.mevcut_sayfa = self.toplam_sayfa - 1
        return self.sayfa_al(self.mevcut_sayfa)
    
    @property
    def toplam_kayit(self) -> int:
        return len(self.tum_veri)
    
    @property
    def sayfa_bilgisi(self) -> str:
        return f"Sayfa {self.mevcut_sayfa + 1}/{self.toplam_sayfa}"
