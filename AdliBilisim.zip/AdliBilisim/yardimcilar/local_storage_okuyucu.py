# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - LocalStorage Okuyucu Modülü

Chrome/Edge LevelDB ve Firefox webappsstore.sqlite okuma.
"""

import sqlite3
import os
import struct
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
import tempfile
import shutil
import json


class LocalStorageOkuyucu:
    """LocalStorage ve IndexedDB verilerini okuma sınıfı"""
    
    def __init__(self):
        self.hatalar: List[str] = []
    
    def veritabani_kopyala(self, db_yolu: Path) -> Optional[Path]:
        """Veritabanını geçici dizine kopyalar"""
        if not db_yolu.exists():
            return None
        
        try:
            gecici = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
            gecici_yol = Path(gecici.name)
            gecici.close()
            shutil.copy2(db_yolu, gecici_yol)
            return gecici_yol
        except Exception as e:
            self.hatalar.append(f"Kopyalama hatası: {str(e)}")
            return None
    
    def chrome_local_storage_oku(self, profil_dizini: Path) -> List[Dict[str, Any]]:
        """
        Chrome/Chromium LocalStorage verilerini okur.
        Chrome LevelDB kullanır, basit bir okuma yaparız.
        """
        veriler = []
        storage_dizini = profil_dizini / "Local Storage" / "leveldb"
        
        if not storage_dizini.exists():
            return veriler
        
        try:
            # LevelDB log dosyalarını oku
            for dosya in storage_dizini.iterdir():
                if dosya.suffix == '.log' or dosya.suffix == '.ldb':
                    try:
                        veriler.extend(self._leveldb_dosya_oku(dosya))
                    except Exception as e:
                        self.hatalar.append(f"LevelDB okuma hatası: {str(e)}")
        except Exception as e:
            self.hatalar.append(f"LocalStorage dizin hatası: {str(e)}")
        
        return veriler
    
    def _leveldb_dosya_oku(self, dosya_yolu: Path) -> List[Dict[str, Any]]:
        """
        LevelDB dosyasından basit veri çıkarma.
        Not: Bu tam bir LevelDB parser değil, metin araması yapar.
        """
        veriler = []
        
        try:
            with open(dosya_yolu, 'rb') as f:
                icerik = f.read()
            
            # Origin kalıplarını ara (http:// veya https://)
            patterns = [b'_http://', b'_https://']
            
            for pattern in patterns:
                pos = 0
                while True:
                    idx = icerik.find(pattern, pos)
                    if idx == -1:
                        break
                    
                    # Origin'i çıkar
                    origin_start = idx + 1  # '_' karakterini atla
                    origin_end = origin_start
                    
                    for i in range(origin_start, min(origin_start + 256, len(icerik))):
                        if icerik[i] == 0:
                            origin_end = i
                            break
                        origin_end = i + 1
                    
                    if origin_end > origin_start:
                        try:
                            origin = icerik[origin_start:origin_end].decode('utf-8', errors='ignore')
                            
                            # Key-value'yu bulmaya çalış
                            kv_start = origin_end + 1
                            kv_data = self._kv_cikart(icerik, kv_start)
                            
                            if kv_data:
                                for key, value in kv_data.items():
                                    veriler.append({
                                        'origin': origin,
                                        'anahtar': key,
                                        'deger': value,
                                        'boyut': len(str(value)),
                                        'kaynak': 'localStorage'
                                    })
                        except:
                            pass
                    
                    pos = origin_end
                    
        except Exception as e:
            self.hatalar.append(f"Dosya okuma hatası: {str(e)}")
        
        return veriler
    
    def _kv_cikart(self, data: bytes, start: int) -> Dict[str, str]:
        """Byte dizisinden key-value çiftleri çıkarır"""
        sonuc = {}
        
        try:
            # Basit string araması yap
            pos = start
            max_pos = min(start + 4096, len(data))
            
            while pos < max_pos:
                # String başlangıcı bul
                str_start = -1
                for i in range(pos, max_pos):
                    if 32 <= data[i] <= 126:
                        str_start = i
                        break
                
                if str_start == -1:
                    break
                
                # String sonunu bul
                str_end = str_start
                for i in range(str_start, max_pos):
                    if data[i] < 32 or data[i] > 126:
                        str_end = i
                        break
                    str_end = i + 1
                
                if str_end - str_start >= 2:
                    try:
                        metin = data[str_start:str_end].decode('utf-8', errors='ignore')
                        # Eğer JSON gibi görünüyorsa anahtar olabilir
                        if len(metin) < 100 and not metin.startswith('{'):
                            sonuc[metin] = "(değer mevcut)"
                    except:
                        pass
                
                pos = str_end + 1
                
                # Maksimum 10 anahtar
                if len(sonuc) >= 10:
                    break
                    
        except:
            pass
        
        return sonuc
    
    def firefox_local_storage_oku(self, profil_dizini: Path) -> List[Dict[str, Any]]:
        """
        Firefox webappsstore.sqlite veritabanını okur.
        Firefox LocalStorage'ı SQLite'ta saklar.
        """
        veriler = []
        db_yolu = profil_dizini / "webappsstore.sqlite"
        
        if not db_yolu.exists():
            return veriler
        
        gecici_yol = self.veritabani_kopyala(db_yolu)
        if gecici_yol is None:
            return veriler
        
        try:
            conn = sqlite3.connect(str(gecici_yol))
            cursor = conn.cursor()
            
            # webappsstore2 tablosunu oku
            cursor.execute("""
                SELECT 
                    originKey,
                    key,
                    value
                FROM webappsstore2
                ORDER BY originKey
            """)
            
            satirlar = cursor.fetchall()
            conn.close()
            
            for satir in satirlar:
                try:
                    # originKey formatı: moc.elpmaxe.:https:443
                    # Tersine çevrilmiş domain
                    origin_key = satir[0] or ""
                    origin = self._firefox_origin_cevir(origin_key)
                    
                    veriler.append({
                        'origin': origin,
                        'anahtar': satir[1] or "",
                        'deger': satir[2] or "",
                        'boyut': len(satir[2]) if satir[2] else 0,
                        'kaynak': 'localStorage'
                    })
                except Exception as e:
                    self.hatalar.append(f"Firefox localStorage satır hatası: {str(e)}")
                    
        except sqlite3.Error as e:
            self.hatalar.append(f"Firefox localStorage SQLite hatası: {str(e)}")
        except Exception as e:
            self.hatalar.append(f"Firefox localStorage hatası: {str(e)}")
        finally:
            if gecici_yol and gecici_yol.exists():
                try:
                    os.unlink(gecici_yol)
                except:
                    pass
        
        return veriler
    
    def _firefox_origin_cevir(self, origin_key: str) -> str:
        """Firefox'un tersine çevrilmiş origin formatını düzeltir"""
        try:
            # Format: moc.elpmaxe.:https:443
            parts = origin_key.split(':')
            if len(parts) >= 2:
                reversed_domain = parts[0]
                protocol = parts[1] if len(parts) > 1 else 'https'
                
                # Domain'i düzelt
                domain_parts = reversed_domain.split('.')
                domain_parts.reverse()
                domain = '.'.join(domain_parts).lstrip('.')
                
                return f"{protocol}://{domain}"
        except:
            pass
        return origin_key
    
    def indexeddb_oku(self, profil_dizini: Path, tarayici: str = "chrome") -> List[Dict[str, Any]]:
        """IndexedDB verilerini okur"""
        veriler = []
        
        if tarayici.lower() in ['chrome', 'edge', 'brave', 'opera']:
            indexeddb_dizini = profil_dizini / "IndexedDB"
        else:  # Firefox
            indexeddb_dizini = profil_dizini / "storage" / "default"
        
        if not indexeddb_dizini.exists():
            return veriler
        
        try:
            # Her origin için alt dizinleri tara
            for origin_dizini in indexeddb_dizini.iterdir():
                if origin_dizini.is_dir():
                    origin = origin_dizini.name
                    
                    # SQLite veritabanlarını bul
                    for dosya in origin_dizini.rglob("*.sqlite"):
                        try:
                            db_veriler = self._indexeddb_sqlite_oku(dosya, origin)
                            veriler.extend(db_veriler)
                        except Exception as e:
                            self.hatalar.append(f"IndexedDB okuma hatası: {str(e)}")
                            
        except Exception as e:
            self.hatalar.append(f"IndexedDB dizin hatası: {str(e)}")
        
        return veriler
    
    def _indexeddb_sqlite_oku(self, db_yolu: Path, origin: str) -> List[Dict[str, Any]]:
        """IndexedDB SQLite dosyasını okur"""
        veriler = []
        gecici_yol = self.veritabani_kopyala(db_yolu)
        
        if gecici_yol is None:
            return veriler
        
        try:
            conn = sqlite3.connect(str(gecici_yol))
            cursor = conn.cursor()
            
            # Tablo listesini al
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tablolar = cursor.fetchall()
            
            for tablo in tablolar:
                tablo_adi = tablo[0]
                if tablo_adi.startswith('sqlite_'):
                    continue
                
                try:
                    cursor.execute(f"SELECT * FROM {tablo_adi} LIMIT 100")
                    satirlar = cursor.fetchall()
                    
                    # Sütun isimlerini al
                    sutun_isimleri = [desc[0] for desc in cursor.description]
                    
                    for satir in satirlar:
                        veri_dict = dict(zip(sutun_isimleri, satir))
                        
                        # Serileştirilmiş veriyi string'e çevir
                        deger_str = json.dumps(veri_dict, default=str, ensure_ascii=False)
                        
                        veriler.append({
                            'origin': origin,
                            'anahtar': f"{tablo_adi}",
                            'deger': deger_str[:1000],  # Maksimum 1000 karakter
                            'boyut': len(deger_str),
                            'kaynak': 'indexedDB'
                        })
                except Exception as e:
                    continue
            
            conn.close()
            
        except Exception as e:
            self.hatalar.append(f"IndexedDB SQLite hatası: {str(e)}")
        finally:
            if gecici_yol and gecici_yol.exists():
                try:
                    os.unlink(gecici_yol)
                except:
                    pass
        
        return veriler
