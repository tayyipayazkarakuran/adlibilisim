"""
Adli Bilişim Forensik Aracı - Şifre Çözücü Modülü

Tarayıcı şifrelerini çözme (DPAPI, Keychain, NSS).
"""

import os
import sys
import json
import base64
from typing import Optional
from pathlib import Path

# Platform-bağımlı importlar
try:
    from Crypto.Cipher import AES
    CRYPTO_MEVCUT = True
except ImportError:
    CRYPTO_MEVCUT = False


class SifreCozucu:
    """Tarayıcı şifrelerini çözme sınıfı"""
    
    def __init__(self):
        self.platform = sys.platform
        self.hatalar = []
    
    def chrome_sifre_coz(self, sifreli_veri: bytes, anahtar: Optional[bytes] = None) -> Optional[str]:
        """
        Chrome şifresini çözer
        
        Args:
            sifreli_veri: Şifreli şifre verisi
            anahtar: Şifreleme anahtarı (Windows için)
            
        Returns:
            Çözülmüş şifre veya None
        """
        if not sifreli_veri:
            return None
        
        try:
            # Chrome v80+ (AES-256-GCM)
            if sifreli_veri.startswith(b'v10') or sifreli_veri.startswith(b'v11'):
                return self._chrome_v80_coz(sifreli_veri, anahtar)
            
            # Eski Chrome (DPAPI - Windows)
            if self.platform == 'win32':
                return self._dpapi_coz(sifreli_veri)
            
            # macOS Keychain
            if self.platform == 'darwin':
                return self._keychain_coz(sifreli_veri)
            
            # Linux (Secret Service)
            if self.platform.startswith('linux'):
                return self._linux_sifre_coz(sifreli_veri)
            
            return None
        except Exception as e:
            self.hatalar.append(f"Şifre çözme hatası: {str(e)}")
            return None
    
    def _chrome_v80_coz(self, sifreli_veri: bytes, anahtar: bytes = None) -> Optional[str]:
        """Chrome v80+ şifrelerini çözer (AES-256-GCM)"""
        if not CRYPTO_MEVCUT:
            self.hatalar.append("pycryptodome kütüphanesi gerekli")
            return None
        
        if anahtar is None:
            self.hatalar.append("Şifreleme anahtarı gerekli")
            return None
        
        try:
            # v10/v11 prefix'ini kaldır
            sifreli_veri = sifreli_veri[3:]
            
            # Nonce (12 byte) ve cipher text
            nonce = sifreli_veri[:12]
            ciphertext = sifreli_veri[12:-16]  # Son 16 byte auth tag
            tag = sifreli_veri[-16:]
            
            cipher = AES.new(anahtar, AES.MODE_GCM, nonce=nonce)
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)
            
            return plaintext.decode('utf-8')
        except Exception as e:
            self.hatalar.append(f"AES çözme hatası: {str(e)}")
            return None
    
    def _dpapi_coz(self, sifreli_veri: bytes) -> Optional[str]:
        """Windows DPAPI ile şifre çözer"""
        try:
            import ctypes
            import ctypes.wintypes
            
            class DATA_BLOB(ctypes.Structure):
                _fields_ = [
                    ('cbData', ctypes.wintypes.DWORD),
                    ('pbData', ctypes.POINTER(ctypes.c_char))
                ]
            
            blob_in = DATA_BLOB(len(sifreli_veri), ctypes.cast(sifreli_veri, ctypes.POINTER(ctypes.c_char)))
            blob_out = DATA_BLOB()
            
            if ctypes.windll.crypt32.CryptUnprotectData(
                ctypes.byref(blob_in),
                None,
                None,
                None,
                None,
                0,
                ctypes.byref(blob_out)
            ):
                result = ctypes.string_at(blob_out.pbData, blob_out.cbData)
                ctypes.windll.kernel32.LocalFree(blob_out.pbData)
                return result.decode('utf-8')
            
            return None
        except Exception as e:
            self.hatalar.append(f"DPAPI hatası: {str(e)}")
            return None
    
    def _keychain_coz(self, sifreli_veri: bytes) -> Optional[str]:
        """macOS Keychain'den şifre çözer"""
        try:
            import subprocess
            
            # Security komutu ile Keychain'den şifre al
            # Not: Kullanıcı izni gerektirir
            self.hatalar.append("macOS Keychain erişimi kullanıcı izni gerektirir")
            return None
        except Exception as e:
            self.hatalar.append(f"Keychain hatası: {str(e)}")
            return None
    
    def _linux_sifre_coz(self, sifreli_veri: bytes) -> Optional[str]:
        """Linux'ta şifre çözer (GNOME Keyring / kwallet)"""
        try:
            # Linux'ta Chromium genellikle 'peanuts' veya 
            # Secret Service API kullanır
            import secretstorage
            
            # Secret Service bağlantısı
            connection = secretstorage.dbus_init()
            collection = secretstorage.get_default_collection(connection)
            
            # Chrome Safe Storage Key'i bul
            for item in collection.get_all_items():
                if item.get_label() == 'Chrome Safe Storage':
                    anahtar = item.get_secret()
                    return self._chrome_v80_coz(sifreli_veri, anahtar)
            
            # Varsayılan anahtar dene
            varsayilan_anahtar = b'peanuts'  # Chromium varsayılan
            return self._chrome_v80_coz(sifreli_veri, varsayilan_anahtar)
        except ImportError:
            self.hatalar.append("secretstorage kütüphanesi gerekli")
            return None
        except Exception as e:
            self.hatalar.append(f"Linux şifre çözme hatası: {str(e)}")
            return None
    
    def chrome_anahtar_al(self, local_state_yolu: Path) -> Optional[bytes]:
        """
        Chrome Local State dosyasından şifreleme anahtarını alır
        
        Args:
            local_state_yolu: Local State dosya yolu
            
        Returns:
            Şifreleme anahtarı veya None
        """
        if not local_state_yolu.exists():
            return None
        
        try:
            with open(local_state_yolu, 'r', encoding='utf-8') as f:
                local_state = json.load(f)
            
            encrypted_key = local_state.get('os_crypt', {}).get('encrypted_key')
            
            if not encrypted_key:
                return None
            
            # Base64 decode
            encrypted_key = base64.b64decode(encrypted_key)
            
            # 'DPAPI' prefix'ini kaldır
            if encrypted_key.startswith(b'DPAPI'):
                encrypted_key = encrypted_key[5:]
            
            # Windows'ta DPAPI ile çöz
            if self.platform == 'win32':
                return self._dpapi_coz_bytes(encrypted_key)
            
            # macOS'ta Keychain ile çöz
            if self.platform == 'darwin':
                return self._keychain_anahtar_al()
            
            # Linux'ta Secret Service ile çöz
            if self.platform.startswith('linux'):
                return self._linux_anahtar_al()
            
            return None
        except Exception as e:
            self.hatalar.append(f"Anahtar alma hatası: {str(e)}")
            return None
    
    def _dpapi_coz_bytes(self, sifreli_veri: bytes) -> Optional[bytes]:
        """Windows DPAPI ile bytes çözer"""
        try:
            import ctypes
            import ctypes.wintypes
            
            class DATA_BLOB(ctypes.Structure):
                _fields_ = [
                    ('cbData', ctypes.wintypes.DWORD),
                    ('pbData', ctypes.POINTER(ctypes.c_char))
                ]
            
            blob_in = DATA_BLOB(len(sifreli_veri), ctypes.cast(sifreli_veri, ctypes.POINTER(ctypes.c_char)))
            blob_out = DATA_BLOB()
            
            if ctypes.windll.crypt32.CryptUnprotectData(
                ctypes.byref(blob_in),
                None,
                None,
                None,
                None,
                0,
                ctypes.byref(blob_out)
            ):
                result = ctypes.string_at(blob_out.pbData, blob_out.cbData)
                ctypes.windll.kernel32.LocalFree(blob_out.pbData)
                return result
            
            return None
        except Exception as e:
            self.hatalar.append(f"DPAPI bytes hatası: {str(e)}")
            return None
    
    def _keychain_anahtar_al(self) -> Optional[bytes]:
        """macOS Keychain'den Chrome anahtarını alır"""
        try:
            import subprocess
            
            result = subprocess.run([
                'security', 'find-generic-password',
                '-w', '-s', 'Chrome Safe Storage',
                '-a', 'Chrome'
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                password = result.stdout.strip()
                # PBKDF2 ile anahtar türet
                import hashlib
                key = hashlib.pbkdf2_hmac(
                    'sha1',
                    password.encode('utf-8'),
                    b'saltysalt',
                    1003,
                    dklen=16
                )
                return key
            
            return None
        except Exception as e:
            self.hatalar.append(f"Keychain anahtar hatası: {str(e)}")
            return None
    
    def _linux_anahtar_al(self) -> Optional[bytes]:
        """Linux'ta Chrome anahtarını alır"""
        try:
            import secretstorage
            import hashlib
            
            connection = secretstorage.dbus_init()
            collection = secretstorage.get_default_collection(connection)
            
            for item in collection.get_all_items():
                if item.get_label() == 'Chrome Safe Storage':
                    password = item.get_secret().decode('utf-8')
                    key = hashlib.pbkdf2_hmac(
                        'sha1',
                        password.encode('utf-8'),
                        b'saltysalt',
                        1,
                        dklen=16
                    )
                    return key
            
            # Varsayılan anahtar
            default_password = 'peanuts'
            key = hashlib.pbkdf2_hmac(
                'sha1',
                default_password.encode('utf-8'),
                b'saltysalt',
                1,
                dklen=16
            )
            return key
        except ImportError:
            # secretstorage yoksa varsayılan anahtar dön
            import hashlib
            default_password = 'peanuts'
            key = hashlib.pbkdf2_hmac(
                'sha1',
                default_password.encode('utf-8'),
                b'saltysalt',
                1,
                dklen=16
            )
            return key
        except Exception as e:
            self.hatalar.append(f"Linux anahtar hatası: {str(e)}")
            return None
    
    def firefox_sifre_coz(self, encrypted_username: str, encrypted_password: str, 
                          key_db_yolu: Path) -> tuple:
        """
        Firefox şifrelerini çözer
        
        Args:
            encrypted_username: Şifreli kullanıcı adı
            encrypted_password: Şifreli şifre
            key_db_yolu: key4.db dosya yolu
            
        Returns:
            (kullanici_adi, sifre) tuple
        """
        # Firefox NSS kütüphanesi kullanır
        # Bu karmaşık bir işlem ve libnss3 gerektirir
        self.hatalar.append("Firefox şifre çözme henüz desteklenmiyor")
        return (None, None)
