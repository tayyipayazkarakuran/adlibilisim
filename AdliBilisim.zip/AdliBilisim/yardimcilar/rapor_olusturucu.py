"""
Adli Bilişim Forensik Aracı - Rapor Oluşturucu Modülü

PDF ve HTML rapor oluşturma.
"""

import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

from config.ayarlar import Ayarlar


class RaporOlusturucu:
    """PDF ve HTML rapor oluşturma sınıfı"""
    
    def __init__(self):
        self.rapor_dizini = Ayarlar.rapor_dizini()
        self.hatalar = []
    
    def html_rapor_olustur(self, veriler: Dict[str, Any], dosya_adi: Optional[str] = None) -> Optional[Path]:
        """HTML formatında rapor oluşturur"""
        if dosya_adi is None:
            zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
            dosya_adi = f"forensik_rapor_{zaman}.html"
        
        hedef = self.rapor_dizini / dosya_adi
        
        html = self._html_sablonu_olustur(veriler)
        
        try:
            with open(hedef, 'w', encoding='utf-8') as f:
                f.write(html)
            return hedef
        except Exception as e:
            self.hatalar.append(f"HTML rapor hatası: {str(e)}")
            return None
    
    def _html_sablonu_olustur(self, veriler: Dict[str, Any]) -> str:
        """HTML rapor şablonu oluşturur"""
        tarih = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        
        html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adli Bilişim Forensik Raporu</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, sans-serif; background: #1a1a2e; color: #fff; padding: 40px; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .header {{ background: linear-gradient(135deg, #6C63FF, #4CAF50); padding: 30px; border-radius: 15px; margin-bottom: 30px; }}
        .header h1 {{ font-size: 2em; margin-bottom: 10px; }}
        .header p {{ opacity: 0.9; }}
        .section {{ background: #16213e; border-radius: 15px; padding: 25px; margin-bottom: 20px; }}
        .section h2 {{ color: #6C63FF; margin-bottom: 20px; border-bottom: 2px solid #3a3a5a; padding-bottom: 10px; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #3a3a5a; }}
        th {{ background: #1a1a2e; color: #6C63FF; }}
        tr:hover {{ background: #1a1a2e; }}
        .stat-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }}
        .stat-card {{ background: #1a1a2e; padding: 20px; border-radius: 10px; text-align: center; }}
        .stat-card .value {{ font-size: 2em; color: #6C63FF; font-weight: bold; }}
        .stat-card .label {{ color: #b0b0b0; margin-top: 5px; }}
        .warning {{ background: #ff9800; color: #000; padding: 15px; border-radius: 10px; margin-bottom: 20px; }}
        .footer {{ text-align: center; color: #666; margin-top: 40px; padding-top: 20px; border-top: 1px solid #3a3a5a; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Adli Bilişim Forensik Raporu</h1>
            <p>Oluşturulma Tarihi: {tarih}</p>
        </div>
        
        <div class="warning">
            ⚠️ Bu rapor sadece yetkili adli bilişim çalışmaları için hazırlanmıştır.
        </div>
        
        <div class="section">
            <h2>📊 Özet İstatistikler</h2>
            <div class="stat-grid">
                <div class="stat-card">
                    <div class="value">{veriler.get('toplam_gecmis', 0)}</div>
                    <div class="label">Geçmiş Kaydı</div>
                </div>
                <div class="stat-card">
                    <div class="value">{veriler.get('toplam_cerez', 0)}</div>
                    <div class="label">Çerez</div>
                </div>
                <div class="stat-card">
                    <div class="value">{veriler.get('toplam_indirme', 0)}</div>
                    <div class="label">İndirme</div>
                </div>
                <div class="stat-card">
                    <div class="value">{veriler.get('toplam_sifre', 0)}</div>
                    <div class="label">Kayıtlı Şifre</div>
                </div>
                <div class="stat-card">
                    <div class="value">{veriler.get('toplam_form', 0)}</div>
                    <div class="label">Form Verisi</div>
                </div>
                <div class="stat-card">
                    <div class="value">{veriler.get('toplam_cache', 0)}</div>
                    <div class="label">Cache Görsel</div>
                </div>
            </div>
        </div>
"""
        # Geçmiş tablosu
        gecmis = veriler.get('gecmis', [])
        if gecmis:
            html += """
        <div class="section">
            <h2>🌐 Tarayıcı Geçmişi</h2>
            <table>
                <thead>
                    <tr><th>Tarih</th><th>Tarayıcı</th><th>URL</th><th>Başlık</th></tr>
                </thead>
                <tbody>
"""
            for kayit in gecmis[:100]:  # İlk 100 kayıt
                tarih_str = kayit.get('tarih', '')
                html += f"                    <tr><td>{tarih_str}</td><td>{kayit.get('tarayici', '')}</td><td>{kayit.get('url', '')[:50]}...</td><td>{kayit.get('baslik', '')[:30]}...</td></tr>\n"
            
            html += """                </tbody>
            </table>
        </div>
"""
        
        html += f"""
        <div class="footer">
            <p>Adli Bilişim Forensik Aracı v{Ayarlar.UYGULAMA_VERSIYONU}</p>
            <p>Bu rapor otomatik olarak oluşturulmuştur.</p>
        </div>
    </div>
</body>
</html>"""
        return html
    
    def pdf_rapor_olustur(self, veriler: Dict[str, Any], dosya_adi: Optional[str] = None) -> Optional[Path]:
        """PDF formatında rapor oluşturur"""
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
            from reportlab.lib.units import cm
        except ImportError:
            self.hatalar.append("reportlab kütüphanesi gerekli")
            return None
        
        if dosya_adi is None:
            zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
            dosya_adi = f"forensik_rapor_{zaman}.pdf"
        
        hedef = self.rapor_dizini / dosya_adi
        
        try:
            doc = SimpleDocTemplate(str(hedef), pagesize=A4)
            story = []
            styles = getSampleStyleSheet()
            
            # Başlık
            title_style = ParagraphStyle('Title', parent=styles['Title'], fontSize=24, textColor=colors.HexColor('#6C63FF'))
            story.append(Paragraph("Adli Bilişim Forensik Raporu", title_style))
            story.append(Spacer(1, 0.5*cm))
            
            tarih = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
            story.append(Paragraph(f"Oluşturulma: {tarih}", styles['Normal']))
            story.append(Spacer(1, 1*cm))
            
            # İstatistikler tablosu
            istatistik_veri = [
                ['Veri Türü', 'Sayı'],
                ['Geçmiş Kaydı', str(veriler.get('toplam_gecmis', 0))],
                ['Çerez', str(veriler.get('toplam_cerez', 0))],
                ['İndirme', str(veriler.get('toplam_indirme', 0))],
                ['Kayıtlı Şifre', str(veriler.get('toplam_sifre', 0))],
                ['Form Verisi', str(veriler.get('toplam_form', 0))],
                ['Cache Görsel', str(veriler.get('toplam_cache', 0))]
            ]
            
            tablo = Table(istatistik_veri, colWidths=[10*cm, 5*cm])
            tablo.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6C63FF')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTSIZE', (0, 0), (-1, -1), 12),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.gray)
            ]))
            story.append(tablo)
            
            doc.build(story)
            return hedef
        except Exception as e:
            self.hatalar.append(f"PDF rapor hatası: {str(e)}")
            return None
