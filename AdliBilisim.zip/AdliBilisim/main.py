#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - v3.0

Profesyonel tarayıcı forensik analiz uygulaması.
"""

import flet as ft
import sys
import os
import threading
import traceback
from datetime import datetime
from typing import List, Dict, Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.ayarlar import Ayarlar
from cikarticilar import (
    ChromeCikarici, FirefoxCikarici, EdgeCikarici,
    OperaCikarici, BraveCikarici, SafariCikarici
)
from arayuz.ana_sayfa import AnaSayfa
from arayuz.gecmis_sayfasi import GecmisSayfasi
from arayuz.aramalar_sayfasi import AramalarSayfasi
from arayuz.cerez_sayfasi import CerezSayfasi
from arayuz.indirmeler_sayfasi import IndirmelerSayfasi
from arayuz.sifreler_sayfasi import SifrelerSayfasi
from arayuz.cache_sayfasi import CacheSayfasi
from arayuz.rapor_sayfasi import RaporSayfasi
from arayuz.oturum_sayfasi import OturumSayfasi
from arayuz.local_storage_sayfasi import LocalStorageSayfasi
from arayuz.kurtarma_sayfasi import KurtarmaSayfasi
from arayuz.otomatik_doldurma_sayfasi import OtomatikDoldurmaSayfasi
from arayuz.medya_sayfasi import MedyaSayfasi
from arayuz.forensik_sayfasi import ForensikSayfasi


class AdliBilisimUygulamasi:
    """Ana uygulama sınıfı"""
    
    def __init__(self, page: ft.Page):
        self.page = page
        self.tum_gecmis = []
        
        # Sayfalar
        self.ana_sayfa = AnaSayfa(self._tarama_baslat)
        self.gecmis_sayfasi = GecmisSayfasi()
        self.aramalar_sayfasi = AramalarSayfasi()
        self.cerez_sayfasi = CerezSayfasi()
        self.indirmeler_sayfasi = IndirmelerSayfasi()
        self.sifreler_sayfasi = SifrelerSayfasi()
        self.cache_sayfasi = CacheSayfasi()
        self.oturum_sayfasi = OturumSayfasi()
        self.local_storage_sayfasi = LocalStorageSayfasi()
        self.kurtarma_sayfasi = KurtarmaSayfasi()
        self.otomatik_doldurma_sayfasi = OtomatikDoldurmaSayfasi()
        self.medya_sayfasi = MedyaSayfasi()
        self.forensik_sayfasi = ForensikSayfasi()
        self.rapor_sayfasi = RaporSayfasi()
        
        self.sayfalar = [
            self.ana_sayfa,
            self.gecmis_sayfasi,
            self.aramalar_sayfasi,
            self.cerez_sayfasi,
            self.indirmeler_sayfasi,
            self.sifreler_sayfasi,
            self.cache_sayfasi,
            self.oturum_sayfasi,
            self.local_storage_sayfasi,
            self.kurtarma_sayfasi,
            self.otomatik_doldurma_sayfasi,
            self.medya_sayfasi,
            self.forensik_sayfasi,
            self.rapor_sayfasi
        ]
        
        self.icerik = ft.Container(expand=True, bgcolor="#0a0a0a")
        self.secili = 0
        
        self._sayfa_ayarla()
    
    def _sayfa_ayarla(self):
        self.page.title = Ayarlar.UYGULAMA_ADI
        self.page.theme_mode = ft.ThemeMode.DARK
        self.page.bgcolor = "#0a0a0a"
        self.page.window.width = Ayarlar.PENCERE_GENISLIK
        self.page.window.height = Ayarlar.PENCERE_YUKSEKLIK
        self.page.padding = 0
        
        self._uyari_goster()
    
    def _uyari_goster(self):
        def kapat(e):
            dialog.open = False
            self.page.update()
            self._arayuz_olustur()
        
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Yasal Uyarı", text_align=ft.TextAlign.CENTER, color="#ffffff"),
            content=ft.Column([
                ft.Text("Bu uygulama sadece aşağıdaki amaçlar için kullanılmalıdır:", size=13, color="#cccccc"),
                ft.Container(height=10),
                ft.Text("• Eğitim ve öğretim amaçlı çalışmalar", size=12, color="#888888"),
                ft.Text("• Yetkili adli bilişim incelemeleri", size=12, color="#888888"),
                ft.Text("• Kendi bilgisayarınızdaki verileri analiz etme", size=12, color="#888888"),
                ft.Container(height=10),
                ft.Text("Yetkisiz erişim veya veri çalma amaçlı kullanım YASAKTIR.", size=12, color="#ff6666"),
            ], tight=True),
            actions=[ft.TextButton("Kabul Ediyorum", on_click=kapat)],
            actions_alignment=ft.MainAxisAlignment.CENTER,
            bgcolor="#141414"
        )
        
        self.page.overlay.append(dialog)
        dialog.open = True
        self.page.update()
    
    def _arayuz_olustur(self):
        nav = ft.NavigationRail(
            selected_index=self.secili,
            on_change=self._sayfa_degistir,
            label_type=ft.NavigationRailLabelType.ALL,
            min_width=90, bgcolor="#0a0a0a", indicator_color="#333333",
            destinations=[
                ft.NavigationRailDestination(icon=ft.Icons.HOME_OUTLINED, selected_icon=ft.Icons.HOME, label="Ana Sayfa"),
                ft.NavigationRailDestination(icon=ft.Icons.HISTORY_OUTLINED, selected_icon=ft.Icons.HISTORY, label="Geçmiş"),
                ft.NavigationRailDestination(icon=ft.Icons.SEARCH_OUTLINED, selected_icon=ft.Icons.SEARCH, label="Aramalar"),
                ft.NavigationRailDestination(icon=ft.Icons.COOKIE_OUTLINED, selected_icon=ft.Icons.COOKIE, label="Çerezler"),
                ft.NavigationRailDestination(icon=ft.Icons.DOWNLOAD_OUTLINED, selected_icon=ft.Icons.DOWNLOAD, label="İndirmeler"),
                ft.NavigationRailDestination(icon=ft.Icons.LOCK_OUTLINE, selected_icon=ft.Icons.LOCK, label="Şifreler"),
                ft.NavigationRailDestination(icon=ft.Icons.IMAGE_OUTLINED, selected_icon=ft.Icons.IMAGE, label="Cache"),
                ft.NavigationRailDestination(icon=ft.Icons.TAB_OUTLINED, selected_icon=ft.Icons.TAB, label="Oturumlar"),
                ft.NavigationRailDestination(icon=ft.Icons.STORAGE_OUTLINED, selected_icon=ft.Icons.STORAGE, label="Storage"),
                ft.NavigationRailDestination(icon=ft.Icons.RESTORE_OUTLINED, selected_icon=ft.Icons.RESTORE, label="Kurtarma"),
                ft.NavigationRailDestination(icon=ft.Icons.TEXT_FIELDS_OUTLINED, selected_icon=ft.Icons.TEXT_FIELDS, label="Doldurma"),
                ft.NavigationRailDestination(icon=ft.Icons.PLAY_CIRCLE_OUTLINE, selected_icon=ft.Icons.PLAY_CIRCLE, label="Medya"),
                ft.NavigationRailDestination(icon=ft.Icons.SECURITY_OUTLINED, selected_icon=ft.Icons.SECURITY, label="Forensik"),
                ft.NavigationRailDestination(icon=ft.Icons.DESCRIPTION_OUTLINED, selected_icon=ft.Icons.DESCRIPTION, label="Rapor"),
            ]
        )
        
        self.icerik.content = self.ana_sayfa.build()
        
        self.page.add(
            ft.Row([nav, ft.VerticalDivider(width=1, color="#222222"), self.icerik], 
                   expand=True, spacing=0)
        )
    
    def _sayfa_degistir(self, e):
        self.secili = e.control.selected_index
        self.icerik.content = self.sayfalar[self.secili].build()
        self.page.update()
    
    def _tarama_baslat(self):
        """Tarama işlemini başlatır (thread içinde çalışır)"""
        # UI thread'de durum güncellemesi
        self.ana_sayfa.tarama_durumu.value = "Tarama başlatılıyor..."
        self.ana_sayfa.ilerleme.visible = True
        self.page.update()
        
        # Tarama işlemini ayrı thread'de başlat
        tarama_thread = threading.Thread(target=self._tarama_yap, daemon=True)
        tarama_thread.start()
    
    def _tarama_yap(self):
        """Gerçek tarama işlemini yapar (ayrı thread'de çalışır)"""
        baslangic = datetime.now()
        hata_mesajlari = []
        
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            
            cikarticilar = [
                ChromeCikarici(), FirefoxCikarici(), EdgeCikarici(),
                OperaCikarici(), BraveCikarici(), SafariCikarici()
            ]
            
            tum_gecmis = []
            tum_cerezler = []
            tum_indirmeler = []
            tum_sifreler = []
            tum_form = []
            tum_cache = []
            tum_oturumlar = []
            tum_local_storage = []
            tum_silinen = []
            tum_otomatik_doldurma = []
            tum_medya = []
            tum_silme_girisimi = []
            tum_sw_cache = []
            
            def cikarici_isle(c, p):
                """Bir çıkarıcı için tüm verileri toplar"""
                sonuc = {
                    'gecmis': [], 'cerezler': [], 'indirmeler': [],
                    'sifreler': [], 'form': [], 'cache': [],
                    'oturumlar': [], 'local_storage': [], 'silinen': [],
                    'otomatik_doldurma': [], 'medya': [], 'silme_girisimi': [],
                    'sw_cache': [],
                    'hatalar': []
                }
                try:
                    sonuc['gecmis'] = c.gecmis_cikart(p)
                    sonuc['cerezler'] = c.cerezleri_cikart(p)
                    sonuc['indirmeler'] = c.indirmeleri_cikart(p)
                    sonuc['sifreler'] = c.sifreleri_cikart(p)
                    sonuc['form'] = c.form_verilerini_cikart(p)
                    sonuc['cache'] = c.cache_gorselleri_cikart(p)
                    sonuc['oturumlar'] = c.oturum_cikart(p)
                    sonuc['local_storage'] = c.local_storage_cikart(p)
                    sonuc['silinen'] = c.silinen_verileri_kurtar(p)
                    # Yeni özellikler
                    sonuc['otomatik_doldurma'] = c.otomatik_doldurma_cikart(p)
                    sonuc['medya'] = c.medya_gecmisi_cikart(p)
                    sonuc['silme_girisimi'] = c.silme_girisimi_tespit(p)
                    sonuc['sw_cache'] = c.service_worker_cache_cikart(p)
                    if c.hatalar:
                        sonuc['hatalar'] = [f"{c.tarayici_adi}: {h}" for h in c.hatalar]
                except Exception as e:
                    sonuc['hatalar'].append(f"{c.tarayici_adi} ({p}): {str(e)}")
                return sonuc
            
            # Paralel çıkarma için görevler oluştur
            gorevler = []
            for c in cikarticilar:
                try:
                    if c.tarayici_kurulu_mu():
                        profiller = c.profilleri_listele()
                        if profiller:
                            for p in profiller[:2]:  # İlk 2 profil
                                gorevler.append((c, p))
                except Exception as e:
                    hata_mesajlari.append(f"{c.tarayici_adi}: {str(e)}")
            
            # Paralel çalıştır
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = {executor.submit(cikarici_isle, c, p): (c, p) for c, p in gorevler}
                for future in as_completed(futures):
                    try:
                        sonuc = future.result()
                        tum_gecmis.extend(sonuc['gecmis'])
                        tum_cerezler.extend(sonuc['cerezler'])
                        tum_indirmeler.extend(sonuc['indirmeler'])
                        tum_sifreler.extend(sonuc['sifreler'])
                        tum_form.extend(sonuc['form'])
                        tum_cache.extend(sonuc['cache'])
                        tum_oturumlar.extend(sonuc['oturumlar'])
                        tum_local_storage.extend(sonuc['local_storage'])
                        tum_silinen.extend(sonuc['silinen'])
                        tum_otomatik_doldurma.extend(sonuc['otomatik_doldurma'])
                        tum_medya.extend(sonuc['medya'])
                        tum_silme_girisimi.extend(sonuc['silme_girisimi'])
                        tum_sw_cache.extend(sonuc['sw_cache'])
                        hata_mesajlari.extend(sonuc['hatalar'])
                    except Exception as e:
                        hata_mesajlari.append(f"Paralel işlem hatası: {str(e)}")
            
            self.tum_gecmis = tum_gecmis
            
            # UI güncellemeleri için callback
            self._tarama_sonucu_guncelle(
                tum_gecmis, tum_cerezler, tum_indirmeler, 
                tum_sifreler, tum_form, tum_cache, 
                tum_oturumlar, tum_local_storage, tum_silinen,
                tum_otomatik_doldurma, tum_medya, tum_silme_girisimi, tum_sw_cache,
                baslangic, hata_mesajlari
            )
            
        except Exception as e:
            hata_msg = f"Kritik tarama hatası: {str(e)}"
            print(f"KRİTİK HATA: {hata_msg}")
            traceback.print_exc()
            self._tarama_hata_goster(hata_msg)
    
    def _tarama_sonucu_guncelle(self, tum_gecmis, tum_cerezler, tum_indirmeler, 
                                tum_sifreler, tum_form, tum_cache, 
                                tum_oturumlar, tum_local_storage, tum_silinen,
                                tum_otomatik_doldurma, tum_medya, tum_silme_girisimi, tum_sw_cache,
                                baslangic, hata_mesajlari):
        """Tarama sonuçlarını UI'da günceller (UI thread'de çalışır)"""
        try:
            # Sayfalara yükle
            self.gecmis_sayfasi.verileri_yukle(tum_gecmis)
            self.aramalar_sayfasi.verileri_yukle(tum_gecmis)
            self.cerez_sayfasi.verileri_yukle(tum_cerezler)
            self.indirmeler_sayfasi.verileri_yukle(tum_indirmeler)
            self.sifreler_sayfasi.verileri_yukle(tum_sifreler)
            self.cache_sayfasi.verileri_yukle(tum_cache)
            
            # Yeni sayfalar
            self.oturum_sayfasi.verileri_yukle(tum_oturumlar)
            self.local_storage_sayfasi.verileri_yukle(tum_local_storage)
            self.kurtarma_sayfasi.verileri_yukle(tum_silinen)
            self.otomatik_doldurma_sayfasi.verileri_yukle(tum_otomatik_doldurma)
            self.medya_sayfasi.verileri_yukle(tum_medya)
            self.forensik_sayfasi.verileri_yukle(silme=tum_silme_girisimi)
            
            rapor_veri = {
                "toplam_gecmis": len(tum_gecmis),
                "toplam_cerez": len(tum_cerezler),
                "toplam_indirme": len(tum_indirmeler),
                "toplam_sifre": len(tum_sifreler),
                "toplam_form": len(tum_form),
                "toplam_cache": len(tum_cache),
                "toplam_oturum": len(tum_oturumlar),
                "toplam_local_storage": len(tum_local_storage),
                "toplam_silinen": len(tum_silinen),
                "gecmis": [{"tarih": g.ziyaret_tarihi.strftime("%d.%m.%Y %H:%M"), 
                           "tarayici": g.tarayici.value, "url": g.url, "baslik": g.baslik} 
                          for g in tum_gecmis[:100]]
            }
            self.rapor_sayfasi.verileri_yukle(rapor_veri)
            
            arama_sayisi = len(self.aramalar_sayfasi.aramalar)
            
            self.ana_sayfa.istatistikleri_guncelle({
                "gecmis": len(tum_gecmis),
                "arama": arama_sayisi,
                "cerez": len(tum_cerezler),
                "indirme": len(tum_indirmeler),
                "sifre": len(tum_sifreler),
                "cache": len(tum_cache),
                "oturum": len(tum_oturumlar),
                "storage": len(tum_local_storage),
                "kurtarma": len(tum_silinen)
            })
            
            sure = (datetime.now() - baslangic).total_seconds()
            durum_mesaji = f"✓ Tarama tamamlandı ({sure:.1f}s)"
            
            if hata_mesajlari:
                durum_mesaji += f" - {len(hata_mesajlari)} hata"
                print(f"\n=== TARAMA HATALARI ({len(hata_mesajlari)}) ===")
                for hata in hata_mesajlari[:10]:  # İlk 10 hatayı göster
                    print(f"  - {hata}")
                if len(hata_mesajlari) > 10:
                    print(f"  ... ve {len(hata_mesajlari) - 10} hata daha")
            
            self.ana_sayfa.tarama_durumu.value = durum_mesaji
            self.ana_sayfa.ilerleme.visible = False
            
            self.page.update()
        except Exception as e:
            print(f"UI güncelleme hatası: {str(e)}")
            traceback.print_exc()
            self._tarama_hata_goster(f"UI güncelleme hatası: {str(e)}")
    
    def _tarama_hata_goster(self, hata_mesaji: str):
        """Hata durumunu UI'da gösterir"""
        self.ana_sayfa.tarama_durumu.value = f"✗ Hata: {hata_mesaji[:50]}..."
        self.ana_sayfa.ilerleme.visible = False
        self.page.update()


def main(page: ft.Page):
    AdliBilisimUygulamasi(page)


if __name__ == "__main__":
    ft.app(target=main)

