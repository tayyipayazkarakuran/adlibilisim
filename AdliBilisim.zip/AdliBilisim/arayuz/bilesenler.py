"""
Adli Bilişim Forensik Aracı - UI Bileşenleri

Yeniden kullanılabilir Flet UI bileşenleri.
"""

import flet as ft
from typing import List, Callable, Optional
from config.ayarlar import Ayarlar


class Bilesenler:
    """Yeniden kullanılabilir UI bileşenleri"""
    
    @staticmethod
    def tema_renkleri() -> dict:
        return Ayarlar.KOYU_TEMA
    
    @staticmethod
    def baslik_karti(baslik: str, alt_baslik: str = "") -> ft.Container:
        """Sayfa başlık kartı - minimal tasarım"""
        return ft.Container(
            content=ft.Column([
                ft.Text(baslik, size=24, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text(alt_baslik, size=13, color="#666666") if alt_baslik else ft.Container()
            ], spacing=4),
            padding=ft.padding.only(bottom=20),
            border=ft.border.only(bottom=ft.BorderSide(1, "#333333"))
        )
    
    @staticmethod
    def istatistik_karti(baslik: str, deger: str) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text(deger, size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text(baslik, size=12, color="#666666")
            ], spacing=4),
            padding=15, border_radius=8, bgcolor="#141414",
            border=ft.border.all(1, "#333333"), expand=True
        )
    
    @staticmethod
    def buton(metin: str, on_tikla: Callable, birincil: bool = True) -> ft.Container:
        return ft.Container(
            content=ft.Text(metin, color="#000000" if birincil else "#ffffff", weight=ft.FontWeight.W_500, size=13),
            padding=ft.padding.symmetric(horizontal=20, vertical=10),
            border_radius=6,
            bgcolor="#ffffff" if birincil else "#333333",
            on_click=on_tikla,
            ink=True
        )
    
    @staticmethod
    def navigasyon_rail(secili_index: int, on_degisim: Callable) -> ft.NavigationRail:
        return ft.NavigationRail(
            selected_index=secili_index, on_change=on_degisim,
            label_type=ft.NavigationRailLabelType.ALL, min_width=100,
            bgcolor="#0a0a0a", indicator_color="#333333",
            destinations=[
                ft.NavigationRailDestination(icon=ft.Icons.HOME_OUTLINED, selected_icon=ft.Icons.HOME, label="Ana Sayfa"),
                ft.NavigationRailDestination(icon=ft.Icons.HISTORY_OUTLINED, selected_icon=ft.Icons.HISTORY, label="Gecmis"),
                ft.NavigationRailDestination(icon=ft.Icons.SEARCH_OUTLINED, selected_icon=ft.Icons.SEARCH, label="Aramalar"),
                ft.NavigationRailDestination(icon=ft.Icons.MAP_OUTLINED, selected_icon=ft.Icons.MAP, label="Zaman Çizelgesi"),
                ft.NavigationRailDestination(icon=ft.Icons.EXTENSION_OUTLINED, selected_icon=ft.Icons.EXTENSION, label="Eklentiler"),
                ft.NavigationRailDestination(icon=ft.Icons.FIND_IN_PAGE_OUTLINED, selected_icon=ft.Icons.FIND_IN_PAGE, label="Genel Arama"),
                ft.NavigationRailDestination(icon=ft.Icons.COOKIE_OUTLINED, selected_icon=ft.Icons.COOKIE, label="Cerezler"),
                ft.NavigationRailDestination(icon=ft.Icons.DOWNLOAD_OUTLINED, selected_icon=ft.Icons.DOWNLOAD, label="Indirmeler"),
                ft.NavigationRailDestination(icon=ft.Icons.LOCK_OUTLINE, selected_icon=ft.Icons.LOCK, label="Sifreler"),
                ft.NavigationRailDestination(icon=ft.Icons.IMAGE_OUTLINED, selected_icon=ft.Icons.IMAGE, label="Cache"),
                ft.NavigationRailDestination(icon=ft.Icons.DESCRIPTION_OUTLINED, selected_icon=ft.Icons.DESCRIPTION, label="Rapor"),
            ]
        )
    
    @staticmethod
    def uyari_banner(mesaj: str, tur: str = "bilgi") -> ft.Container:
        renkler = {"bilgi": "#333333", "uyari": "#332200", "hata": "#331111"}
        return ft.Container(
            content=ft.Text(mesaj, size=12, color="#999999"),
            padding=12, border_radius=6, bgcolor=renkler.get(tur, "#333333")
        )
    
    @staticmethod
    def liste_satiri(baslik: str, alt_baslik: str = "", sag_metin: str = "", 
                     sag_alt: str = "", etiket: str = "") -> ft.Container:
        """Performanslı liste satırı"""
        return ft.Container(
            content=ft.Row([
                ft.Container(
                    content=ft.Text(etiket[:2].upper() if etiket else "--", size=10, 
                                   color="#888888", weight=ft.FontWeight.BOLD),
                    width=32, height=32, border_radius=4, bgcolor="#1a1a1a",
                    alignment=ft.Alignment(0, 0)
                ) if etiket else ft.Container(width=0),
                ft.Column([
                    ft.Text(baslik[:70], size=13, color="#ffffff", max_lines=1),
                    ft.Text(alt_baslik[:90], size=11, color="#666666", max_lines=1)
                ], expand=True, spacing=2),
                ft.Column([
                    ft.Text(sag_metin, size=11, color="#888888"),
                    ft.Text(sag_alt, size=10, color="#555555")
                ], horizontal_alignment=ft.CrossAxisAlignment.END, spacing=2)
            ], spacing=12),
            padding=ft.padding.symmetric(horizontal=12, vertical=10),
            border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a"))
        )
