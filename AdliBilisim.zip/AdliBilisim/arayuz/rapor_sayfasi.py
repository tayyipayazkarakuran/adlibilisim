# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Rapor Sayfası
"""

import flet as ft
from datetime import datetime
from typing import Dict, Any, List
import json
import platform

from yardimcilar.rapor_olusturucu import RaporOlusturucu
from config.ayarlar import Ayarlar


class RaporSayfasi:
    """Rapor oluşturma sayfası"""
    
    def __init__(self):
        self.veriler: Dict[str, List[Any]] = {} # Ham veriler
        self.rapor = RaporOlusturucu()
        self.durum = ft.Text("Rapor oluşturulmadı", color="#666666", size=12)
        
        # İstatistikler
        self.stat_texts = {
            "gecmis": ft.Text("0", size=12, color="#888888"),
            "cerez": ft.Text("0", size=12, color="#888888"),
            "indirme": ft.Text("0", size=12, color="#888888"),
            "sifre": ft.Text("0", size=12, color="#888888"),
            "cache": ft.Text("0", size=12, color="#888888"),
            "eklenti": ft.Text("0", size=12, color="#888888"),
        }
    
    def verileri_yukle(self, veriler: Dict[str, List[Any]]):
        self.veriler = veriler
        
        # İstatistikleri güncelle
        self.stat_texts["gecmis"].value = f"Geçmiş: {len(veriler.get('gecmis', []))}"
        self.stat_texts["cerez"].value = f"Çerez: {len(veriler.get('cerez', []))}"
        self.stat_texts["indirme"].value = f"İndirme: {len(veriler.get('indirme', []))}"
        self.stat_texts["sifre"].value = f"Şifre: {len(veriler.get('sifre', []))}"
        self.stat_texts["cache"].value = f"Cache: {len(veriler.get('cache', []))}"
        self.stat_texts["eklenti"].value = f"Eklenti: {len(veriler.get('eklenti', []))}"
    
    def _html(self, e):
        meta = {
            "vaka_adi": "Otomatik Analiz",
            "sistem_bilgisi": f"{platform.system()} {platform.release()}"
        }
        yol = self.rapor.html_rapor_olustur(self.veriler, meta)
        self.durum.value = f"✓ HTML rapor oluşturuldu: {yol}" if yol else "Hata oluştu"
        e.page.update()
    
    def _csv(self, e):
        # Her kategori için ayrı CSV
        yollar = []
        for key, liste in self.veriler.items():
            if liste:
                yol = self.rapor.csv_export(liste, f"export_{key}")
                if "Hatası" not in yol:
                    yollar.append(key)
        
        if yollar:
            self.durum.value = f"✓ {len(yollar)} kategori CSV olarak dışa aktarıldı (exports/raporlar/)"
        else:
            self.durum.value = "Dışa aktarılacak veri bulunamadı"
        e.page.update()
    
    def _json(self, e):
        """JSON olarak dışa aktar"""
        try:
            dosya = Ayarlar.rapor_dizini() / f"rapor_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            # Complex objeleri dict'e çevir
            export_data = {}
            for key, liste in self.veriler.items():
                export_data[key] = []
                for item in liste:
                    if hasattr(item, 'to_dict'):
                        export_data[key].append(item.to_dict())
                    else:
                         export_data[key].append(str(item))

            with open(dosya, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2, default=str)
            self.durum.value = f"✓ JSON rapor oluşturuldu: {dosya}"
        except Exception as ex:
            self.durum.value = f"Hata: {ex}"
        e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Rapor Oluştur", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Forensik analiz raporu", size=12, color="#666666"),
                ft.Container(height=25),
                
                # Özet istatistikler
                ft.Container(
                    content=ft.Column([
                        ft.Text("Tarama Özeti", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                        ft.Container(height=10),
                        ft.Row([
                            self.stat_texts["gecmis"],
                            self.stat_texts["cerez"],
                            self.stat_texts["indirme"],
                            self.stat_texts["sifre"],
                        ], spacing=20),
                        ft.Row([
                            self.stat_texts["cache"],
                            self.stat_texts["eklenti"],
                        ], spacing=20)
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=20),
                
                ft.Container(
                    content=ft.Column([
                        ft.Text("Rapor Formatı Seçin", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                        ft.Container(height=15),
                        ft.Row([
                            ft.Container(
                                content=ft.Row([ft.Icon(ft.Icons.HTML, color="black"), ft.Text("HTML Rapor", color="#000000", size=12)]),
                                padding=ft.padding.symmetric(horizontal=20, vertical=10),
                                border_radius=6, bgcolor="#ffffff", on_click=self._html, ink=True
                            ),
                            ft.Container(
                                content=ft.Row([ft.Icon(ft.Icons.TABLE_CHART, color="white"), ft.Text("CSV Export", color="#ffffff", size=12)]),
                                padding=ft.padding.symmetric(horizontal=20, vertical=10),
                                border_radius=6, bgcolor="#4caf50", on_click=self._csv, ink=True
                            ),
                            ft.Container(
                                content=ft.Row([ft.Icon(ft.Icons.DATA_OBJECT, color="white"), ft.Text("JSON Export", color="#ffffff", size=12)]),
                                padding=ft.padding.symmetric(horizontal=20, vertical=10),
                                border_radius=6, bgcolor="#333333", on_click=self._json, ink=True
                            ),
                        ], spacing=15),
                        ft.Container(height=20),
                        self.durum
                    ]),
                    padding=25, border_radius=8, bgcolor="#141414", border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=20),
                ft.Container(
                    content=ft.Text("Raporlar exports/raporlar dizinine kaydedilir.", size=11, color="#666666"),
                    padding=12, border_radius=6, bgcolor="#1a1a1a"
                )
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
