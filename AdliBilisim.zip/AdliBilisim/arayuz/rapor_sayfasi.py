# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Rapor Sayfası
"""

import flet as ft
from datetime import datetime
from typing import Dict, Any
import json

from yardimcilar.rapor_olusturucu import RaporOlusturucu
from config.ayarlar import Ayarlar


class RaporSayfasi:
    """Rapor oluşturma sayfası"""
    
    def __init__(self):
        self.veriler: Dict[str, Any] = {}
        self.rapor = RaporOlusturucu()
        self.durum = ft.Text("Rapor oluşturulmadı", color="#666666", size=12)
    
    def verileri_yukle(self, veriler: Dict[str, Any]):
        self.veriler = veriler
    
    def _html(self, e):
        yol = self.rapor.html_rapor_olustur(self.veriler)
        self.durum.value = f"✓ HTML rapor oluşturuldu: {yol}" if yol else "Hata oluştu"
        e.page.update()
    
    def _pdf(self, e):
        yol = self.rapor.pdf_rapor_olustur(self.veriler)
        self.durum.value = f"✓ PDF rapor oluşturuldu: {yol}" if yol else "reportlab kütüphanesi gerekli"
        e.page.update()
    
    def _json(self, e):
        """JSON olarak dışa aktar"""
        try:
            dosya = Ayarlar.rapor_dizini() / f"rapor_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(dosya, 'w', encoding='utf-8') as f:
                json.dump(self.veriler, f, ensure_ascii=False, indent=2, default=str)
            self.durum.value = f"✓ JSON rapor oluşturuldu: {dosya}"
        except Exception as ex:
            self.durum.value = f"Hata: {ex}"
        e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Rapor Oluştur", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Forensik analiz raporu", size=12, color="#666666"),
                ft.Container(height=25),
                
                # Özet istatistikler
                ft.Container(
                    content=ft.Column([
                        ft.Text("Tarama Özeti", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                        ft.Container(height=10),
                        ft.Row([
                            ft.Text(f"Geçmiş: {self.veriler.get('toplam_gecmis', 0)}", size=12, color="#888888"),
                            ft.Text(f"Çerez: {self.veriler.get('toplam_cerez', 0)}", size=12, color="#888888"),
                            ft.Text(f"İndirme: {self.veriler.get('toplam_indirme', 0)}", size=12, color="#888888"),
                            ft.Text(f"Şifre: {self.veriler.get('toplam_sifre', 0)}", size=12, color="#888888"),
                        ], spacing=20)
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=20),
                
                ft.Container(
                    content=ft.Column([
                        ft.Text("Rapor Formatı Seçin", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                        ft.Container(height=15),
                        ft.Row([
                            ft.Container(
                                content=ft.Text("HTML Rapor", color="#000000", size=12),
                                padding=ft.padding.symmetric(horizontal=20, vertical=10),
                                border_radius=6, bgcolor="#ffffff", on_click=self._html, ink=True
                            ),
                            ft.Container(
                                content=ft.Text("PDF Rapor", color="#ffffff", size=12),
                                padding=ft.padding.symmetric(horizontal=20, vertical=10),
                                border_radius=6, bgcolor="#333333", on_click=self._pdf, ink=True
                            ),
                            ft.Container(
                                content=ft.Text("JSON Veri", color="#ffffff", size=12),
                                padding=ft.padding.symmetric(horizontal=20, vertical=10),
                                border_radius=6, bgcolor="#333333", on_click=self._json, ink=True
                            ),
                        ], spacing=15),
                        ft.Container(height=20),
                        self.durum
                    ]),
                    padding=25, border_radius=8, bgcolor="#141414", border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=20),
                ft.Container(
                    content=ft.Text("Raporlar exports/raporlar dizinine kaydedilir.", size=11, color="#666666"),
                    padding=12, border_radius=6, bgcolor="#1a1a1a"
                )
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
