# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Forensik Analiz Sayfası

Silme tespiti, gizli mod izleri, DNS cache ve USB geçmişi.
"""

import flet as ft
from typing import List, Dict, Any
from modeller.veri_modelleri import SilmeGirisimi, GizliModIzi, DNSKaydi

class ForensikSayfasi:
    """Forensik analiz sayfası (silme tespiti, gizli mod, DNS, USB)"""
    
    def __init__(self):
        self.silme_girisimleri: List[SilmeGirisimi] = []
        self.gizli_mod_izleri: List[GizliModIzi] = []
        self.dns_kayitlari: List[DNSKaydi] = []
        self.usb_cihazlar: List[Dict[str, Any]] = []
        
        self.aktif_sekme = 0
        self.silme_liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.gizli_liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.dns_liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.usb_liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        
        self.detay_panel = ft.Container(visible=False)
    
    def verileri_yukle(self, silme: List[SilmeGirisimi] = None, 
                       gizli: List[GizliModIzi] = None,
                       dns: List[DNSKaydi] = None,
                       usb: List[Dict[str, Any]] = None):
        if silme is not None:
            self.silme_girisimleri = silme
        if gizli is not None:
            self.gizli_mod_izleri = gizli
        if dns is not None:
            self.dns_kayitlari = dns
        if usb is not None:
            self.usb_cihazlar = usb
        self._guncelle()
    
    def _guncelle(self):
        self._silme_guncelle()
        self._gizli_guncelle()
        self._dns_guncelle()
        self._usb_guncelle()
    
    def _usb_guncelle(self):
        self.usb_liste.controls.clear()
        for cihaz in self.usb_cihazlar:
            self.usb_liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.USB, size=20, color="#ffffff"),
                        ft.Column([
                            ft.Text(cihaz.get('ad', 'Bilinmeyen Cihaz'), size=13, color="#ffffff", weight=ft.FontWeight.BOLD),
                            ft.Text(f"Durum: {cihaz.get('durum', '-')}", size=11, color="#888888"),
                            ft.Text(f"Seri No: {cihaz.get('seri_no', '-')}", size=10, color="#666666")
                        ], spacing=2)
                    ], spacing=10),
                    padding=10, border=ft.border.only(bottom=ft.BorderSide(1, "#222222"))
                )
            )
        
        if not self.usb_cihazlar:
             self.usb_liste.controls.append(ft.Container(content=ft.Text("Bağlı USB cihaz bulunamadı", color="#666666"), padding=20))

    def _silme_guncelle(self):
        self.silme_liste.controls.clear()
        for kayit in self.silme_girisimleri[:100]:
            if kayit.guvenilirlik >= 70: renk, seviye = "#f44336", "Yüksek"
            elif kayit.guvenilirlik >= 40: renk, seviye = "#ff9800", "Orta"
            else: renk, seviye = "#4caf50", "Düşük"
            
            self.silme_liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(content=ft.Icon(ft.Icons.WARNING, size=14, color=renk), width=28, height=28, border_radius=4, bgcolor="#1a1a1a", alignment=ft.Alignment(0, 0)),
                        ft.Column([ft.Text(kayit.silme_tipi.replace('_', ' ').title(), size=12, color="#ffffff"), ft.Text(kayit.detaylar[:50], size=10, color="#555555")], expand=True, spacing=1),
                        ft.Column([ft.Text(f"{kayit.guvenilirlik}%", size=11, color=renk, weight=ft.FontWeight.BOLD), ft.Text(seviye, size=9, color="#666666")], horizontal_alignment=ft.CrossAxisAlignment.END)
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8), border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")), ink=True
                )
            )
        if not self.silme_girisimleri:
            self.silme_liste.controls.append(ft.Container(content=ft.Row([ft.Icon(ft.Icons.CHECK_CIRCLE, color="#4caf50", size=20), ft.Text("Silme girişimi tespit edilmedi", color="#888888")], spacing=10), padding=20))
    
    def _gizli_guncelle(self):
        self.gizli_liste.controls.clear()
        for kayit in self.gizli_mod_izleri[:100]:
            self.gizli_liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(content=ft.Icon(ft.Icons.VISIBILITY_OFF, size=14, color="#9c27b0"), width=28, height=28, border_radius=4, bgcolor="#1a1a1a", alignment=ft.Alignment(0, 0)),
                        ft.Column([ft.Text(kayit.aciklama[:50], size=12, color="#ffffff"), ft.Text(f"Tip: {kayit.iz_tipi}", size=10, color="#555555")], expand=True, spacing=1),
                        ft.Text(f"{kayit.guvenilirlik}%", size=11, color="#9c27b0")
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8), border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")), ink=True
                )
            )
        if not self.gizli_mod_izleri:
            self.gizli_liste.controls.append(ft.Container(content=ft.Row([ft.Icon(ft.Icons.INFO_OUTLINE, color="#666666", size=20), ft.Text("Gizli mod izi bulunamadı", color="#888888")], spacing=10), padding=20))

    def _dns_guncelle(self):
        self.dns_liste.controls.clear()
        for kayit in self.dns_kayitlari[:200]:
            self.dns_liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(content=ft.Text(kayit.kayit_tipi, size=9, color="#4a9eff"), width=28, height=28, border_radius=4, bgcolor="#1a1a1a", alignment=ft.Alignment(0, 0)),
                        ft.Column([ft.Text(kayit.domain[:40], size=12, color="#ffffff"), ft.Text(kayit.ip_adresi, size=10, color="#555555")], expand=True, spacing=1),
                        ft.Text(f"TTL: {kayit.ttl}", size=10, color="#666666")
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8), border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")), ink=True
                )
            )
        if not self.dns_kayitlari:
            self.dns_liste.controls.append(ft.Container(content=ft.Row([ft.Icon(ft.Icons.DNS, color="#666666", size=20), ft.Text("DNS önbellek verisi yok", color="#888888")], spacing=10), padding=20))

    def build(self) -> ft.Container:
        silme_icerik = ft.Container(content=self.silme_liste, expand=True, visible=True)
        gizli_icerik = ft.Container(content=self.gizli_liste, expand=True, visible=False)
        dns_icerik = ft.Container(content=self.dns_liste, expand=True, visible=False)
        usb_icerik = ft.Container(content=self.usb_liste, expand=True, visible=False)
        
        icerikler = [silme_icerik, gizli_icerik, dns_icerik, usb_icerik]
        buton_bg_normal = "#1a1a1a"
        buton_bg_aktif = "#222222"
        
        def sekme_sec(e, idx):
            for i, icerik in enumerate(icerikler):
                icerik.visible = (i == idx)
            e.page.update()

        return ft.Container(
            content=ft.Column([
                ft.Text("Forensik Analiz", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Silme tespiti, gizli mod, DNS ve USB analizi", size=12, color="#666666"),
                ft.Container(height=15),
                
                ft.Container(
                    content=ft.Row([
                        ft.Column([ft.Text("Silme Tespiti", size=10, color="#666666"), ft.Text(str(len(self.silme_girisimleri)), size=18, weight=ft.FontWeight.BOLD, color="#f44336")], expand=True),
                        ft.Column([ft.Text("Gizli Mod", size=10, color="#666666"), ft.Text(str(len(self.gizli_mod_izleri)), size=18, weight=ft.FontWeight.BOLD, color="#9c27b0")], expand=True),
                        ft.Column([ft.Text("DNS", size=10, color="#666666"), ft.Text(str(len(self.dns_kayitlari)), size=18, weight=ft.FontWeight.BOLD, color="#4a9eff")], expand=True),
                        ft.Column([ft.Text("USB", size=10, color="#666666"), ft.Text(str(len(self.usb_cihazlar)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.Row([
                    ft.Container(content=ft.Row([ft.Icon(ft.Icons.DELETE_SWEEP, size=14, color="#f44336"), ft.Text("Silme", size=12, color="#ffffff")], spacing=5), padding=8, bgcolor=buton_bg_normal, border_radius=6, on_click=lambda e: sekme_sec(e, 0), ink=True),
                    ft.Container(content=ft.Row([ft.Icon(ft.Icons.VISIBILITY_OFF, size=14, color="#9c27b0"), ft.Text("Gizli Mod", size=12, color="#ffffff")], spacing=5), padding=8, bgcolor=buton_bg_normal, border_radius=6, on_click=lambda e: sekme_sec(e, 1), ink=True),
                    ft.Container(content=ft.Row([ft.Icon(ft.Icons.DNS, size=14, color="#4a9eff"), ft.Text("DNS", size=12, color="#ffffff")], spacing=5), padding=8, bgcolor=buton_bg_normal, border_radius=6, on_click=lambda e: sekme_sec(e, 2), ink=True),
                    ft.Container(content=ft.Row([ft.Icon(ft.Icons.USB, size=14, color="#ffffff"), ft.Text("USB", size=12, color="#ffffff")], spacing=5), padding=8, bgcolor=buton_bg_normal, border_radius=6, on_click=lambda e: sekme_sec(e, 3), ink=True),
                ], spacing=8),
                
                ft.Container(height=10),
                ft.Container(content=ft.Stack(icerikler), expand=True)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
