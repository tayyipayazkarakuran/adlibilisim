"""
Adli Bilişim Forensik Aracı - Form Verileri Sayfası

Otomatik doldurulan form verileri.
"""

import flet as ft
from typing import List

from .bilesenler import Bilesenler
from modeller.veri_modelleri import FormVerisi


class FormVerileriSayfasi:
    """Form verileri sayfası"""
    
    def __init__(self):
        self.veriler: List[FormVerisi] = []
        self.liste = ft.ListView(expand=True, spacing=5)
        self.sonuc = ft.Text("0 form verisi", color="#b0b0b0")
    
    def verileri_yukle(self, form_verileri: List[FormVerisi]):
        self.veriler = form_verileri
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.veriler)} form verisi"
        
        for v in self.veriler[:300]:
            self.liste.controls.append(ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.EDIT_NOTE, color="#2196f3"),
                    ft.Column([
                        ft.Text(v.alan_adi, size=14, weight=ft.FontWeight.W_500),
                        ft.Text(f"Tip: {v.alan_tipi}", size=12, color="#b0b0b0")
                    ], expand=True, spacing=2),
                    ft.Column([
                        ft.Text(v.deger[:30] + "..." if len(v.deger) > 30 else v.deger, size=12),
                        ft.Text(f"{v.kullanim_sayisi}x kullanım", size=11, color="#666")
                    ], horizontal_alignment=ft.CrossAxisAlignment.END)
                ], spacing=15),
                padding=15, border_radius=10, bgcolor="#16213e", border=ft.border.all(1, "#3a3a5a")
            ))
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                Bilesenler.baslik_karti("📝 Form Verileri", "Otomatik doldurulan veriler", ft.Icons.EDIT_NOTE),
                ft.Container(height=15),
                self.sonuc, ft.Divider(color="#3a3a5a"),
                ft.Container(content=self.liste, expand=True)
            ], spacing=10),
            expand=True, padding=30
        )
