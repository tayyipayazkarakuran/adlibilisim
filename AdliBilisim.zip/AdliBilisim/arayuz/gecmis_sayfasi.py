# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Geçmiş Sayfası

Tarayıcı geçmişi görüntüleme - Optimized + Forensik Detaylar
"""

import flet as ft
from datetime import datetime
from typing import List, Dict
from urllib.parse import urlparse
from collections import Counter

from modeller.veri_modelleri import TarayiciGecmisi


class GecmisSayfasi:
    """Tarayıcı geçmişi sayfası - Forensik analiz özellikleri"""
    
    def __init__(self):
        self.tum_gecmis: List[TarayiciGecmisi] = []
        self.filtrelenmis: List[TarayiciGecmisi] = []
        self.arama = ""
        self.secili_tarayici = "Tümü"
        self.sayfa_boyutu = 100
        self.gosterilen = 100
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 kayıt", color="#666666", size=12)
        
        # Forensik istatistikler
        self.domain_sayaci: Dict[str, int] = {}
        self.tarayici_sayaci: Dict[str, int] = {}
        self.gunluk_aktivite: Dict[str, int] = {}
        
        # Detay paneli
        self.detay_panel = ft.Container(visible=False)
        self.secili_kayit = None
    
    def verileri_yukle(self, gecmis: List[TarayiciGecmisi]):
        self.tum_gecmis = sorted(gecmis, key=lambda x: x.ziyaret_tarihi)
        self.gosterilen = self.sayfa_boyutu
        self._istatistikleri_hesapla()
        self._filtrele()
    
    def _istatistikleri_hesapla(self):
        """Forensik istatistikleri hesapla"""
        self.domain_sayaci.clear()
        self.tarayici_sayaci.clear()
        self.gunluk_aktivite.clear()
        
        for kayit in self.tum_gecmis:
            # Domain sayacı
            try:
                domain = urlparse(kayit.url).netloc.replace("www.", "")
                if domain:
                    self.domain_sayaci[domain] = self.domain_sayaci.get(domain, 0) + 1
            except:
                pass
            
            # Tarayıcı sayacı
            tarayici = kayit.tarayici.value
            self.tarayici_sayaci[tarayici] = self.tarayici_sayaci.get(tarayici, 0) + 1
            
            # Günlük aktivite
            try:
                if kayit.ziyaret_tarihi != datetime.min:
                    gun = kayit.ziyaret_tarihi.strftime("%Y-%m-%d")
                    self.gunluk_aktivite[gun] = self.gunluk_aktivite.get(gun, 0) + 1
            except:
                pass
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_gecmis.copy()
        
        if self.secili_tarayici != "Tümü":
            self.filtrelenmis = [g for g in self.filtrelenmis 
                                if g.tarayici.gorunen_ad == self.secili_tarayici]
        
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [g for g in self.filtrelenmis 
                                if a in g.url.lower() or a in g.baslik.lower()]
        
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        toplam = len(self.filtrelenmis)
        self.sonuc.value = f"{toplam} kayıt bulundu"
        
        for kayit in self.filtrelenmis[:self.gosterilen]:
            try:
                tarih = kayit.ziyaret_tarihi.strftime("%d.%m.%Y %H:%M") if kayit.ziyaret_tarihi != datetime.min else "-"
            except:
                tarih = "-"
            
            baslik = kayit.baslik[:65] if kayit.baslik else "(Başlıksız)"
            url = kayit.url[:85] if kayit.url else ""
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(kayit.tarayici.value[:2].upper(), size=10, 
                                           color="#888888", weight=ft.FontWeight.BOLD),
                            width=28, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Text(baslik, size=13, color="#ffffff", max_lines=1),
                            ft.Text(url, size=11, color="#555555", max_lines=1)
                        ], expand=True, spacing=1),
                        ft.Text(tarih, size=10, color="#555555")
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")),
                    on_click=lambda e, k=kayit: self._kayit_sec(e, k),
                    ink=True
                )
            )
        
        if self.gosterilen < toplam:
            self.liste.controls.append(
                ft.Container(
                    content=ft.Text(f"Daha fazla göster ({toplam - self.gosterilen} kaldı)", 
                                   size=12, color="#888888"),
                    padding=15, alignment=ft.Alignment(0, 0),
                    on_click=self._daha_fazla, ink=True
                )
            )
    
    def _kayit_sec(self, e, kayit: TarayiciGecmisi):
        """Kayıt detaylarını göster"""
        self.secili_kayit = kayit
        
        try:
            tarih = kayit.ziyaret_tarihi.strftime("%d.%m.%Y %H:%M:%S") if kayit.ziyaret_tarihi != datetime.min else "-"
        except:
            tarih = "-"
        
        try:
            domain = urlparse(kayit.url).netloc
        except:
            domain = "-"
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Kayıt Detayları", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                self._detay_satir("URL", kayit.url),
                self._detay_satir("Başlık", kayit.baslik),
                self._detay_satir("Domain", domain),
                self._detay_satir("Ziyaret Tarihi", tarih),
                self._detay_satir("Ziyaret Sayısı", str(kayit.ziyaret_sayisi)),
                self._detay_satir("Tarayıcı", kayit.tarayici.gorunen_ad),
                self._detay_satir("Profil", kayit.profil),
                self._detay_satir("Hash", kayit.hash_degeri or "Hesaplanmadı"),
            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=350
        )
        self.detay_panel.visible = True
        e.page.update()
    
    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=90),
            ft.Text(deger[:60] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])
    
    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()
    
    def _daha_fazla(self, e):
        self.gosterilen += self.sayfa_boyutu
        self._guncelle()
        e.page.update()
    
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self.gosterilen = self.sayfa_boyutu
        self._filtrele()
        e.page.update()
    
    def _tarayici_degisti(self, e):
        self.secili_tarayici = e.control.value
        self.gosterilen = self.sayfa_boyutu
        self._filtrele()
        e.page.update()
    
    def _en_cok_ziyaret(self) -> List[ft.Control]:
        """En çok ziyaret edilen domainler"""
        top_10 = sorted(self.domain_sayaci.items(), key=lambda x: x[1], reverse=True)[:10]
        return [
            ft.Text(f"{i+1}. {domain} ({sayi})", size=11, color="#888888")
            for i, (domain, sayi) in enumerate(top_10)
        ]
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Tarayıcı Geçmişi", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Forensik analiz - Kayıt için tıklayın", size=12, color="#666666"),
                ft.Container(height=15),
                
                # Forensik özet
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("Toplam Kayıt", size=10, color="#666666"),
                            ft.Text(str(len(self.tum_gecmis)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Benzersiz Domain", size=10, color="#666666"),
                            ft.Text(str(len(self.domain_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Aktif Gün", size=10, color="#666666"),
                            ft.Text(str(len(self.gunluk_aktivite)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.Row([
                    ft.TextField(hint_text="Ara...", prefix_icon=ft.Icons.SEARCH,
                                border_radius=6, bgcolor="#141414", border_color="#333333",
                                on_submit=self._arama_degisti, on_blur=self._arama_degisti, 
                                expand=True, height=40, text_size=13),
                    ft.Dropdown(
                        value="Tümü", width=140, bgcolor="#141414", border_color="#333333",
                        options=[ft.dropdown.Option("Tümü"), ft.dropdown.Option("Google Chrome"),
                                ft.dropdown.Option("Mozilla Firefox"), ft.dropdown.Option("Microsoft Edge"),
                                ft.dropdown.Option("Opera"), ft.dropdown.Option("Brave"), ft.dropdown.Option("Safari")],
                        on_change=self._tarayici_degisti, text_size=12
                    )
                ], spacing=10),
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=10)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
