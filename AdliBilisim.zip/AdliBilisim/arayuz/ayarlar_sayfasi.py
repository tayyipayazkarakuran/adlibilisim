"""
Adli Bilişim Forensik Aracı - Ayarlar Sayfası

Tema ve uygulama ayarları.
"""

import flet as ft
from typing import Callable

from .bilesenler import Bilesenler
from config.ayarlar import Ayarlar


class AyarlarSayfasi:
    """Ayarlar sayfası"""
    
    def __init__(self, tema_degistir_callback: Callable = None):
        self.tema_degistir = tema_degistir_callback
        self.koyu_tema = True
    
    def _tema_toggle(self, e):
        self.koyu_tema = e.control.value
        if self.tema_degistir:
            self.tema_degistir(self.koyu_tema)
        e.page.theme_mode = ft.ThemeMode.DARK if self.koyu_tema else ft.ThemeMode.LIGHT
        e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                Bilesenler.baslik_karti("⚙️ Ayarlar", "Uygulama ayarları", ft.Icons.SETTINGS),
                ft.Container(height=20),
                
                # Tema Ayarı
                ft.Container(
                    content=ft.Column([
                        ft.Text("🎨 Tema Ayarları", size=18, weight=ft.FontWeight.BOLD),
                        ft.Divider(color="#3a3a5a"),
                        ft.Row([
                            ft.Text("Koyu Tema"),
                            ft.Switch(value=self.koyu_tema, on_change=self._tema_toggle, active_color="#6C63FF")
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
                    ], spacing=15),
                    padding=25, border_radius=15, bgcolor="#16213e"
                ),
                
                ft.Container(height=20),
                
                # Uygulama Bilgisi
                ft.Container(
                    content=ft.Column([
                        ft.Text("ℹ️ Uygulama Bilgisi", size=18, weight=ft.FontWeight.BOLD),
                        ft.Divider(color="#3a3a5a"),
                        ft.Text(f"Uygulama: {Ayarlar.UYGULAMA_ADI}"),
                        ft.Text(f"Versiyon: {Ayarlar.UYGULAMA_VERSIYONU}"),
                        ft.Text(f"Açıklama: {Ayarlar.UYGULAMA_ACIKLAMASI}"),
                    ], spacing=10),
                    padding=25, border_radius=15, bgcolor="#16213e"
                ),
                
                ft.Container(height=20),
                
                Bilesenler.uyari_banner(
                    "⚠️ Bu araç sadece eğitim ve yasal adli bilişim çalışmaları içindir.", "uyari"
                )
            ], spacing=10),
            expand=True, padding=30
        )
