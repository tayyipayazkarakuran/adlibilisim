# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Zaman Çizelgesi Sayfası
"""

import flet as ft
from datetime import datetime
from typing import List, Dict, Any
from modeller.veri_modelleri import TimelineOlayi, TarayiciGecmisi, IndirilenDosya, Cerez, CacheGorsel, MedyaGecmisi

class ZamanCizelgesiSayfasi:
    """Tüm verilerin zaman ekseninde gösterimi"""
    
    def __init__(self):
        self.olaylar: List[TimelineOlayi] = []
        self.filtrelenmis: List[TimelineOlayi] = []
        self.arama = ""
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 olay", color="#666666", size=12)
        
    def verileri_yukle(self, veriler: Dict[str, List[Any]]):
        """Farklı kaynaklardan gelen verileri zaman çizelgesine dönüştürür"""
        self.olaylar = []
        
        # Geçmiş
        for v in veriler.get('gecmis', []):
            if isinstance(v, TarayiciGecmisi):
                self.olaylar.append(TimelineOlayi(
                    zaman=v.ziyaret_tarihi,
                    olay_tipi="gecmis",
                    baslik=v.baslik or v.url,
                    detay=f"Ziyaret: {v.url}",
                    kaynak=v.url,
                    ikon=ft.Icons.HISTORY,
                    renk="#4a9eff",
                    veri_objesi=v
                ))
                
        # İndirmeler
        for v in veriler.get('indirme', []):
            if isinstance(v, IndirilenDosya):
                self.olaylar.append(TimelineOlayi(
                    zaman=v.baslangic_tarihi,
                    olay_tipi="indirme",
                    baslik=f"İndirme: {v.dosya_adi}",
                    detay=f"{v.boyut_formatli} - {v.kaynak_url}",
                    kaynak=v.dosya_yolu,
                    ikon=ft.Icons.DOWNLOAD,
                    renk="#4caf50",
                    veri_objesi=v
                ))
        
        # Çerezler (Oluşturma tarihi varsa)
        for v in veriler.get('cerez', []):
            if isinstance(v, Cerez) and v.olusturma_tarihi:
                self.olaylar.append(TimelineOlayi(
                    zaman=v.olusturma_tarihi,
                    olay_tipi="cerez",
                    baslik=f"Çerez: {v.ad}",
                    detay=f"Domain: {v.domain}",
                    kaynak=v.domain,
                    ikon=ft.Icons.COOKIE,
                    renk="#ff9800",
                    veri_objesi=v
                ))

        # Cache (Oluşturma tarihi varsa)
        for v in veriler.get('cache', []):
            if isinstance(v, CacheGorsel) and v.olusturma_tarihi:
                self.olaylar.append(TimelineOlayi(
                    zaman=v.olusturma_tarihi,
                    olay_tipi="cache",
                    baslik=f"Cache: {v.dosya_yolu.split('/')[-1]}",
                    detay=f"{v.boyut_formatli}",
                    kaynak=v.dosya_yolu,
                    ikon=ft.Icons.IMAGE,
                    renk="#9c27b0",
                    veri_objesi=v
                ))

        # Medya
        for v in veriler.get('medya', []):
            if isinstance(v, MedyaGecmisi) and v.son_izleme:
                self.olaylar.append(TimelineOlayi(
                    zaman=v.son_izleme,
                    olay_tipi="medya",
                    baslik=f"Medya: {v.baslik}",
                    detay=f"{v.medya_tipi.upper()} - {v.kaynak}",
                    kaynak=v.url,
                    ikon=ft.Icons.PLAY_CIRCLE,
                    renk="#f44336",
                    veri_objesi=v
                ))

        # Tarihe göre sırala (Yeniden eskiye)
        self.olaylar.sort(key=lambda x: x.zaman, reverse=True)
        self._filtrele()
    
    def _filtrele(self):
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [x for x in self.olaylar 
                                if a in x.baslik.lower() or a in x.detay.lower()]
        else:
            self.filtrelenmis = self.olaylar
            
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} olay"
        
        # Günlere göre grupla
        if not self.filtrelenmis:
            return

        current_date_str = ""
        
        # Performans için ilk 500 olay
        for olay in self.filtrelenmis[:500]:
            try:
                date_str = olay.zaman.strftime("%d %B %Y")
                time_str = olay.zaman.strftime("%H:%M:%S")
            except:
                continue
                
            if date_str != current_date_str:
                self.liste.controls.append(
                    ft.Container(
                        content=ft.Text(date_str, weight=ft.FontWeight.BOLD, color="#4a9eff"),
                        padding=ft.padding.only(top=15, bottom=5),
                        bgcolor="#0a0a0a" # Sticky header simulation
                    )
                )
                current_date_str = date_str
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text(time_str, size=11, color="#666666", width=60),
                        ft.Container(
                            width=2, height=30, bgcolor=olay.renk,
                            border_radius=2
                        ),
                        ft.Icon(olay.ikon, size=16, color=olay.renk),
                        ft.Column([
                            ft.Text(olay.baslik[:60], size=13, color="#ffffff", max_lines=1),
                            ft.Text(olay.detay[:80], size=11, color="#888888", max_lines=1)
                        ], expand=True, spacing=1)
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=6),
                    on_click=lambda e: print("Olay tıklandı"), # Detay eklenebilir
                    ink=True
                )
            )
            
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()

    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Zaman Çizelgesi Analizi", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Aktivitelerin kronolojik görünümü", size=12, color="#666666"),
                ft.Container(height=10),
                
                ft.TextField(hint_text="Zaman çizelgesinde ara...", prefix_icon=ft.Icons.SEARCH,
                            border_radius=6, bgcolor="#141414", border_color="#333333",
                            on_change=self._arama_degisti, 
                            height=40, text_size=13),
                
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                
                ft.Container(content=self.liste, expand=True)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
