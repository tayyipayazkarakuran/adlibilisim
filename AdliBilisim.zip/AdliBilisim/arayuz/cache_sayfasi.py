# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Cache Sayfası
"""

import flet as ft
from typing import List, Optional
from pathlib import Path
import base64
import io

from modeller.veri_modelleri import CacheGorsel
from yardimcilar.cache_isleyici import CacheIsleyici


class CacheSayfasi:
    """Cache görselleri sayfası"""
    
    def __init__(self):
        self.gorseller: List[CacheGorsel] = []
        self.liste = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 görsel", color="#666666", size=12)
        self.cache_isleyici = CacheIsleyici()
        self.onizleme_goster = True  # Önizleme göster/gizle
    
    def verileri_yukle(self, gorseller: List[CacheGorsel]):
        self.gorseller = gorseller
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.gorseller)} görsel"
        
        for g in self.gorseller[:100]:  # Performans için ilk 100 görsel
            # Görsel önizlemesi oluştur
            onizleme_widget = self._gorsel_onizleme_olustur(g)
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            onizleme_widget,
                            ft.Column([
                                ft.Text(f"{g.format.upper()} - {g.boyutlar}", size=13, color="#ffffff", weight=ft.FontWeight.BOLD),
                                ft.Text(g.dosya_yolu[-70:] if len(g.dosya_yolu) > 70 else g.dosya_yolu, 
                                       size=11, color="#888888", max_lines=1),
                                ft.Text(f"Boyut: {g.boyut_formatli}", size=10, color="#666666"),
                                ft.Text(f"Tarayıcı: {g.tarayici.gorunen_ad}", size=10, color="#666666")
                            ], expand=True, spacing=2)
                        ], spacing=15, expand=True),
                    ], spacing=5),
                    padding=ft.padding.all(12),
                    border=ft.border.all(1, "#1a1a1a"),
                    border_radius=6,
                    bgcolor="#111111"
                )
            )
    
    def _gorsel_onizleme_olustur(self, gorsel: CacheGorsel) -> ft.Container:
        """Görsel önizlemesi oluşturur"""
        # Önizleme gizli ise sadece ikon göster
        if not self.onizleme_goster:
            return ft.Container(
                content=ft.Icon(ft.Icons.IMAGE, size=32, color="#666666"),
                width=80,
                height=80,
                bgcolor="#0a0a0a",
                border_radius=4,
                alignment=ft.Alignment(0, 0)
            )
        
        try:
            dosya_yolu = Path(gorsel.dosya_yolu)
            if not dosya_yolu.exists():
                return ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.IMAGE, size=48, color="#444444"),
                        ft.Text("Yok", size=10, color="#666666")
                    ], alignment=ft.MainAxisAlignment.CENTER, spacing=5),
                    width=120,
                    height=120,
                    bgcolor="#0a0a0a",
                    border_radius=4,
                    alignment=ft.alignment.center
                )
            
            # Görsel dosyasını oku
            try:
                # Büyük görseller için sınır (5MB)
                max_size = 5 * 1024 * 1024
                file_size = dosya_yolu.stat().st_size
                
                if file_size > max_size:
                    return ft.Container(
                        content=ft.Column([
                            ft.Icon(ft.Icons.IMAGE, size=32, color="#ffaa00"),
                            ft.Text("Çok büyük", size=10, color="#ffaa00"),
                            ft.Text(f"{gorsel.boyut_formatli}", size=8, color="#666666")
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=5),
                        width=120,
                        height=120,
                        bgcolor="#0a0a0a",
                        border_radius=4,
                        alignment=ft.Alignment(0, 0)
                    )
                
                with open(dosya_yolu, 'rb') as f:
                    gorsel_data = f.read()
                
                # Base64'e çevir
                gorsel_base64 = base64.b64encode(gorsel_data).decode('utf-8')
                
                # MIME type belirle
                mime_types = {
                    'jpeg': 'image/jpeg',
                    'jpg': 'image/jpeg',
                    'png': 'image/png',
                    'gif': 'image/gif',
                    'webp': 'image/webp',
                    'bmp': 'image/bmp'
                }
                mime_type = mime_types.get(gorsel.format.lower(), 'image/jpeg')
                
                # Data URI oluştur
                data_uri = f"data:{mime_type};base64,{gorsel_base64}"
                
                # Küçük önizleme göster (max 150x150)
                return ft.Container(
                    content=ft.Image(
                        src=data_uri,
                        width=150,
                        height=150
                    ),
                    width=150,
                    height=150,
                    bgcolor="#0a0a0a",
                    border_radius=4,
                    border=ft.border.all(1, "#222222"),
                    alignment=ft.Alignment(0, 0)
                )
            except Exception as e:
                # Dosya okuma hatası
                return ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.WARNING, size=32, color="#ffaa00"),
                        ft.Text("Okunamadı", size=10, color="#ffaa00", max_lines=2)
                    ], alignment=ft.MainAxisAlignment.CENTER, spacing=5),
                    width=120,
                    height=120,
                    bgcolor="#0a0a0a",
                    border_radius=4,
                    alignment=ft.Alignment(0, 0)
                )
        except Exception as e:
            # Genel hata
            return ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.BROKEN_IMAGE, size=32, color="#666666"),
                    ft.Text("Hata", size=10, color="#666666")
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=5),
                width=120,
                height=120,
                bgcolor="#0a0a0a",
                border_radius=4,
                alignment=ft.Alignment(0, 0)
            )
    
    def _toggle_onizleme(self, e):
        """Önizleme göster/gizle toggle"""
        self.onizleme_goster = not self.onizleme_goster
        self._guncelle()
        e.page.update()
    
    def _export(self, e):
        if self.gorseller:
            yollar = self.cache_isleyici.toplu_export(self.gorseller)
            e.page.snack_bar = ft.SnackBar(ft.Text(f"{len(yollar)} görsel dışa aktarıldı!"))
            e.page.snack_bar.open = True
            e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Cache Görselleri", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Önbelleğe alınan görseller", size=12, color="#666666"),
                ft.Container(height=15),
                ft.Row([
                    self.sonuc,
                    ft.Row([
                        ft.TextButton(
                            "Önizlemeyi Gizle" if self.onizleme_goster else "Önizlemeyi Göster",
                            on_click=self._toggle_onizleme,
                            icon=ft.Icons.VISIBILITY if not self.onizleme_goster else ft.Icons.VISIBILITY_OFF
                        ),
                        ft.Container(
                            content=ft.Text("Tümünü Dışa Aktar", color="#000000", size=11),
                            padding=ft.padding.symmetric(horizontal=12, vertical=6),
                            border_radius=4, bgcolor="#ffffff", on_click=self._export, ink=True
                        )
                    ], spacing=10)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#222222", height=1),
                ft.Container(content=self.liste, expand=True)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
