# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Eklentiler Sayfası
"""

import flet as ft
from datetime import datetime
from typing import List, Dict
from modeller.veri_modelleri import EklentiVerisi

class EklentilerSayfasi:
    """Tarayıcı eklentileri sayfası"""
    
    def __init__(self):
        self.tum_veriler: List[EklentiVerisi] = []
        self.filtrelenmis: List[EklentiVerisi] = []
        self.arama = ""
        self.secili_tarayici = "Tümü"
        self.liste = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 eklenti", color="#666666", size=12)
        
        # Detay paneli
        self.detay_panel = ft.Container(visible=False)
        self.secili_kayit = None
    
    def verileri_yukle(self, veriler: List[EklentiVerisi]):
        self.tum_veriler = sorted(veriler, key=lambda x: x.risk_skoru, reverse=True)
        self._filtrele()
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_veriler.copy()
        
        if self.secili_tarayici != "Tümü":
             self.filtrelenmis = [v for v in self.filtrelenmis if v.tarayici.gorunen_ad == self.secili_tarayici]
        
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [v for v in self.filtrelenmis 
                                if a in v.ad.lower() or a in v.aciklama.lower() or a in v.kimlik.lower()]
        
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} eklenti"
        
        for eklenti in self.filtrelenmis:
            # Risk rengi
            if eklenti.risk_skoru >= 70:
                risk_renk = "#f44336" # Yüksek
                risk_ikon = ft.Icons.WARNING
            elif eklenti.risk_skoru >= 40:
                risk_renk = "#ff9800" # Orta
                risk_ikon = ft.Icons.WARNING_AMBER
            else:
                risk_renk = "#4caf50" # Düşük
                risk_ikon = ft.Icons.CHECK_CIRCLE
                
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Icon(ft.Icons.EXTENSION, size=20, color="#ffffff"),
                            width=40, height=40, border_radius=8, bgcolor="#222222",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Text(eklenti.ad[:40], size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                            ft.Row([
                                ft.Container(
                                    content=ft.Text(f"v{eklenti.versiyon}", size=10, color="#aaaaaa"),
                                    padding=ft.padding.symmetric(horizontal=6, vertical=2),
                                    bgcolor="#1a1a1a", border_radius=4
                                ),
                                ft.Text(f"ID: {eklenti.kimlik[:20]}...", size=11, color="#666666")
                            ])
                        ], expand=True, spacing=2),
                        
                        ft.Column([
                            ft.Row([
                                ft.Icon(risk_ikon, size=14, color=risk_renk),
                                ft.Text(f"Risk: {eklenti.risk_skoru}/100", size=11, color=risk_renk, weight=ft.FontWeight.BOLD)
                            ]),
                            ft.Text(eklenti.tarayici.gorunen_ad, size=10, color="#555555")
                        ], horizontal_alignment=ft.CrossAxisAlignment.END)
                        
                    ], spacing=10),
                    padding=12,
                    bgcolor="#141414",
                    border_radius=8,
                    border=ft.border.all(1, "#222222"),
                    on_click=lambda e, k=eklenti: self._kayit_sec(e, k),
                    ink=True
                )
            )

    def _kayit_sec(self, e, kayit: EklentiVerisi):
        self.secili_kayit = kayit
        
        risk_maddeleri = []
        if kayit.risk_detaylari:
            for detay in kayit.risk_detaylari:
                risk_maddeleri.append(
                    ft.Row([
                        ft.Icon(ft.Icons.CIRCLE, size=6, color="#ff4444"),
                        ft.Text(detay, size=11, color="#ffaaaa")
                    ], spacing=5)
                )
        else:
             risk_maddeleri.append(ft.Text("Riskli durum tespit edilmedi.", size=11, color="#888888"))

        izinler_str = ", ".join(kayit.izinler) if kayit.izinler else "Özel izin yok"
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Eklenti Detayları", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                
                self._detay_satir("Ad", kayit.ad),
                self._detay_satir("Kimlik", kayit.kimlik),
                self._detay_satir("Versiyon", kayit.versiyon),
                
                ft.Text("Açıklama:", size=11, color="#888888"),
                ft.Text(kayit.aciklama or "-", size=11, color="#dddddd"),
                
                ft.Container(height=10),
                ft.Text("İzinler:", size=11, color="#888888"),
                ft.Container(
                    content=ft.Text(izinler_str, size=11, color="#dddddd"),
                    padding=8, bgcolor="#1a1a1a", border_radius=4
                ),
                
                ft.Container(height=10),
                ft.Text("Risk Analizi:", size=11, color="#888888"),
                ft.Container(
                    content=ft.Column(risk_maddeleri, spacing=2),
                    padding=8, bgcolor="#1a0a0a", border_radius=4, border=ft.border.all(1, "#331111" if kayit.risk_skoru > 0 else "#113311")
                ),
                
                ft.Container(height=10),
                self._detay_satir("Tarayıcı", kayit.tarayici.gorunen_ad),
                self._detay_satir("Profil", kayit.profil),
                self._detay_satir("Kurulum", kayit.kurulum_tarihi.strftime("%d.%m.%Y") if kayit.kurulum_tarihi else "-"),

            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=350
        )
        self.detay_panel.visible = True
        e.page.update()

    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=70),
            ft.Text(deger[:60] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])

    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()

    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()
        
    def _tarayici_degisti(self, e):
        self.secili_tarayici = e.control.value
        self._filtrele()
        e.page.update()

    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Tarayıcı Eklentileri", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Yüklü eklentiler ve risk analizi", size=12, color="#666666"),
                ft.Container(height=15),
                
                ft.Row([
                    ft.TextField(hint_text="Eklenti ara...", prefix_icon=ft.Icons.SEARCH,
                                border_radius=6, bgcolor="#141414", border_color="#333333",
                                on_change=self._arama_degisti, 
                                expand=True, height=40, text_size=13),
                    ft.Dropdown(
                        value="Tümü", width=140, bgcolor="#141414", border_color="#333333",
                        options=[ft.dropdown.Option("Tümü"), ft.dropdown.Option("Google Chrome"),
                                ft.dropdown.Option("Mozilla Firefox"), ft.dropdown.Option("Microsoft Edge"),
                                ft.dropdown.Option("Opera"), ft.dropdown.Option("Brave"), ft.dropdown.Option("Safari")],
                        on_change=self._tarayici_degisti, text_size=12
                    )
                ], spacing=10),
                
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=10)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
