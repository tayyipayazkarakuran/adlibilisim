# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Oturum Sayfası

Açık sekmeler ve oturum verileri görüntüleme.
"""

import flet as ft
from datetime import datetime
from typing import List, Dict
from urllib.parse import urlparse

from modeller.veri_modelleri import OturumVerisi


class OturumSayfasi:
    """Oturum/sekme verileri sayfası"""
    
    def __init__(self):
        self.tum_oturumlar: List[OturumVerisi] = []
        self.filtrelenmis: List[OturumVerisi] = []
        self.arama = ""
        self.secili_tarayici = "Tümü"
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 sekme", color="#666666", size=12)
        
        # İstatistikler
        self.tarayici_sayaci: Dict[str, int] = {}
        self.domain_sayaci: Dict[str, int] = {}
        
        # Detay paneli
        self.detay_panel = ft.Container(visible=False)
        self.secili_kayit = None
    
    def verileri_yukle(self, oturumlar: List[OturumVerisi]):
        """Oturum verilerini yükler"""
        self.tum_oturumlar = sorted(oturumlar, key=lambda x: x.son_erisim, reverse=True)
        self._istatistikleri_hesapla()
        self._filtrele()
    
    def _istatistikleri_hesapla(self):
        """İstatistikleri hesapla"""
        self.tarayici_sayaci.clear()
        self.domain_sayaci.clear()
        
        for kayit in self.tum_oturumlar:
            # Tarayıcı sayacı
            tarayici = kayit.tarayici.value
            self.tarayici_sayaci[tarayici] = self.tarayici_sayaci.get(tarayici, 0) + 1
            
            # Domain sayacı
            try:
                domain = urlparse(kayit.url).netloc.replace("www.", "")
                if domain:
                    self.domain_sayaci[domain] = self.domain_sayaci.get(domain, 0) + 1
            except:
                pass
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_oturumlar.copy()
        
        if self.secili_tarayici != "Tümü":
            self.filtrelenmis = [o for o in self.filtrelenmis 
                                if o.tarayici.gorunen_ad == self.secili_tarayici]
        
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [o for o in self.filtrelenmis 
                                if a in o.url.lower() or a in o.baslik.lower()]
        
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} sekme bulundu"
        
        for kayit in self.filtrelenmis[:200]:
            try:
                tarih = kayit.son_erisim.strftime("%d.%m.%Y %H:%M") if kayit.son_erisim != datetime.min else "-"
            except:
                tarih = "-"
            
            baslik = kayit.baslik[:65] if kayit.baslik else "(Başlıksız)"
            url = kayit.url[:85] if kayit.url else ""
            
            # Pinned badge
            pin_badge = None
            if kayit.pinned:
                pin_badge = ft.Container(
                    content=ft.Icon(ft.Icons.PUSH_PIN, size=12, color="#888888"),
                    width=16
                )
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(kayit.tarayici.value[:2].upper(), size=10, 
                                           color="#888888", weight=ft.FontWeight.BOLD),
                            width=28, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Row([
                                ft.Text(baslik, size=13, color="#ffffff", max_lines=1, expand=True),
                                pin_badge if pin_badge else ft.Container()
                            ], spacing=4),
                            ft.Text(url, size=11, color="#555555", max_lines=1)
                        ], expand=True, spacing=1),
                        ft.Text(tarih, size=10, color="#555555")
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")),
                    on_click=lambda e, k=kayit: self._kayit_sec(e, k),
                    ink=True
                )
            )
    
    def _kayit_sec(self, e, kayit: OturumVerisi):
        """Kayıt detaylarını göster"""
        self.secili_kayit = kayit
        
        try:
            tarih = kayit.son_erisim.strftime("%d.%m.%Y %H:%M:%S") if kayit.son_erisim != datetime.min else "-"
        except:
            tarih = "-"
        
        try:
            domain = urlparse(kayit.url).netloc
        except:
            domain = "-"
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Sekme Detayları", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                self._detay_satir("URL", kayit.url),
                self._detay_satir("Başlık", kayit.baslik),
                self._detay_satir("Domain", domain),
                self._detay_satir("Son Erişim", tarih),
                self._detay_satir("Tarayıcı", kayit.tarayici.gorunen_ad),
                self._detay_satir("Profil", kayit.profil),
                self._detay_satir("Pencere ID", str(kayit.pencere_id)),
                self._detay_satir("Sekme İndeksi", str(kayit.sekme_indeksi)),
                self._detay_satir("Sabitlenmiş", "Evet" if kayit.pinned else "Hayır"),
            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=350
        )
        self.detay_panel.visible = True
        e.page.update()
    
    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=90),
            ft.Text(deger[:60] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])
    
    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()
    
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()
    
    def _tarayici_degisti(self, e):
        self.secili_tarayici = e.control.value
        self._filtrele()
        e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Oturum Verileri", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Açık sekmeler ve son oturumlar", size=12, color="#666666"),
                ft.Container(height=15),
                
                # Özet istatistikler
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("Toplam Sekme", size=10, color="#666666"),
                            ft.Text(str(len(self.tum_oturumlar)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Benzersiz Domain", size=10, color="#666666"),
                            ft.Text(str(len(self.domain_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Tarayıcı Sayısı", size=10, color="#666666"),
                            ft.Text(str(len(self.tarayici_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.Row([
                    ft.TextField(hint_text="Ara...", prefix_icon=ft.Icons.SEARCH,
                                border_radius=6, bgcolor="#141414", border_color="#333333",
                                on_submit=self._arama_degisti, on_blur=self._arama_degisti, 
                                expand=True, height=40, text_size=13),
                    ft.Dropdown(
                        value="Tümü", width=140, bgcolor="#141414", border_color="#333333",
                        options=[ft.dropdown.Option("Tümü"), ft.dropdown.Option("Google Chrome"),
                                ft.dropdown.Option("Mozilla Firefox"), ft.dropdown.Option("Microsoft Edge"),
                                ft.dropdown.Option("Opera"), ft.dropdown.Option("Brave"), ft.dropdown.Option("Safari")],
                        on_change=self._tarayici_degisti, text_size=12
                    )
                ], spacing=10),
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=10)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
