# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Genel Arama Sayfası
"""

import flet as ft
from typing import List, Dict, Any

class GenelAramaSayfasi:
    """Tüm verilerde global arama"""
    
    def __init__(self):
        self.tum_veriler: Dict[str, List[Any]] = {}
        self.sonuc_listesi = ft.Column(spacing=15, scroll=ft.ScrollMode.AUTO)
        self.arama_kutusu = ft.TextField(
            hint_text="Tüm verilerde ara (URL, başlık, kullanıcı adı, dosya...)", 
            prefix_icon=ft.Icons.SEARCH,
            border_radius=8, bgcolor="#141414", border_color="#333333",
            on_submit=self._ara, text_size=14, height=50, autofocus=True
        )
        self.durum_mesaji = ft.Text("Arama yapmak için enter'a basın", color="#666666")
        
    def verileri_yukle(self, veriler: Dict[str, List[Any]]):
        self.tum_veriler = veriler
        
    def _ara(self, e):
        terim = self.arama_kutusu.value.lower()
        if not terim or len(terim) < 2:
            self.durum_mesaji.value = "En az 2 karakter girin"
            self.sonuc_listesi.controls.clear()
            e.page.update()
            return

        self.durum_mesaji.value = "Aranıyor..."
        self.sonuc_listesi.controls.clear()
        e.page.update()
        
        # Sonuçları kategori bazında topla
        bulunanlar = {}
        toplam_sonuc = 0
        
        # Kategoriler ve aranacak alanlar mapping
        kategoriler = {
            'gecmis': ('Geçmiş', ['url', 'baslik']),
            'indirme': ('İndirmeler', ['dosya_adi', 'kaynak_url']),
            'cerez': ('Çerezler', ['ad', 'domain', 'deger']),
            'sifre': ('Şifreler', ['site_url', 'kullanici_adi']),
            'eklenti': ('Eklentiler', ['ad', 'kimlik', 'aciklama']),
            'oturum': ('Oturumlar', ['baslik', 'url']),
            'form': ('Form Verileri', ['alan_adi', 'deger']),
            'cache': ('Önbellek', ['dosya_yolu', 'kaynak_url'])
        }
        
        for key, (label, fields) in kategoriler.items():
            if key not in self.tum_veriler:
                continue
                
            items = []
            for item in self.tum_veriler[key]:
                matched = False
                # Basit attribute kontrolü
                for field in fields:
                    try:
                        val = getattr(item, field, "")
                        if val and terim in str(val).lower():
                            matched = True
                            break
                    except:
                        continue
                
                if matched:
                    items.append(self._liste_ogesi_olustur(item, key))
                    if len(items) >= 50: # Kategori başına limit
                        break
            
            if items:
                bulunanlar[label] = items
                toplam_sonuc += len(items)
        
        self.durum_mesaji.value = f"{toplam_sonuc} sonuç bulundu"
        
        # UI Oluştur
        if not bulunanlar:
            self.sonuc_listesi.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SEARCH_OFF, size=64, color="#333333"),
                        ft.Text("Sonuç bulunamadı", color="#666666")
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    alignment=ft.alignment.center, padding=40
                )
            )
        else:
            for label, controls in bulunanlar.items():
                self.sonuc_listesi.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text(f"{label} ({len(controls)})", size=16, weight=ft.FontWeight.BOLD, color="#4a9eff"),
                            ft.Divider(height=1, color="#333333"),
                            ft.Column(controls, spacing=2)
                        ], spacing=5),
                        bgcolor="#111111", padding=15, border_radius=8
                    )
                )
        
        e.page.update()

    def _liste_ogesi_olustur(self, item, key):
        """Veri tipine göre liste öğesi oluşturur"""
        baslik = ""
        alt = ""
        ikon = ft.Icons.CIRCLE
        
        if key == 'gecmis':
            baslik = item.baslik or item.url
            alt = item.url
            ikon = ft.Icons.HISTORY
        elif key == 'indirme':
            baslik = item.dosya_adi
            alt = item.kaynak_url
            ikon = ft.Icons.DOWNLOAD
        elif key == 'cerez':
            baslik = item.ad
            alt = item.domain
            ikon = ft.Icons.COOKIE
        elif key == 'sifre':
            baslik = item.domain
            alt = item.kullanici_adi
            ikon = ft.Icons.LOCK
        elif key == 'eklenti':
            baslik = item.ad
            alt = f"ID: {item.kimlik}"
            ikon = ft.Icons.EXTENSION
        # Diğerleri...
        
        return ft.Container(
            content=ft.Row([
                ft.Icon(ikon, size=16, color="#666666"),
                ft.Column([
                    ft.Text(str(baslik)[:80], size=13, color="#ffffff", max_lines=1),
                    ft.Text(str(alt)[:100], size=11, color="#888888", max_lines=1)
                ], spacing=1, expand=True)
            ], spacing=10),
            padding=8,
            border_radius=4,
            on_hover=lambda e: self._hover(e),
            ink=True
        )

    def _hover(self, e):
        e.control.bgcolor = "#222222" if e.data == "true" else None
        e.control.update()

    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Global Arama", size=24, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Tüm forensik veriler içinde detaylı arama", size=13, color="#888888"),
                ft.Container(height=20),
                self.arama_kutusu,
                self.durum_mesaji,
                ft.Container(height=10),
                ft.Container(content=self.sonuc_listesi, expand=True)
            ]),
            expand=True, padding=30, bgcolor="#0a0a0a"
        )
