# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Kurtarma Sayfası

Silinen veri kurtarma sonuçları görüntüleme.
"""

import flet as ft
from datetime import datetime
from typing import List, Dict
import json

from modeller.veri_modelleri import SilinenKayit


class KurtarmaSayfasi:
    """Silinen veri kurtarma sonuçları sayfası"""
    
    def __init__(self):
        self.tum_kurtarilan: List[SilinenKayit] = []
        self.filtrelenmis: List[SilinenKayit] = []
        self.arama = ""
        self.secili_tablo = "Tümü"
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 kurtarılan kayıt", color="#666666", size=12)
        
        # İstatistikler
        self.tablo_sayaci: Dict[str, int] = {}
        self.db_sayaci: Dict[str, int] = {}
        self.ortalama_guvenilirlik = 0
        
        # Detay paneli
        self.detay_panel = ft.Container(visible=False)
        self.secili_kayit = None
    
    def verileri_yukle(self, kayitlar: List[SilinenKayit]):
        """Kurtarılan verileri yükler"""
        self.tum_kurtarilan = sorted(kayitlar, key=lambda x: x.guvenilirlik, reverse=True)
        self._istatistikleri_hesapla()
        self._filtrele()
    
    def _istatistikleri_hesapla(self):
        """İstatistikleri hesapla"""
        self.tablo_sayaci.clear()
        self.db_sayaci.clear()
        
        toplam_guvenilirlik = 0
        
        for kayit in self.tum_kurtarilan:
            # Tablo sayacı
            self.tablo_sayaci[kayit.tablo] = self.tablo_sayaci.get(kayit.tablo, 0) + 1
            
            # Veritabanı sayacı
            self.db_sayaci[kayit.kaynak_db] = self.db_sayaci.get(kayit.kaynak_db, 0) + 1
            
            # Güvenilirlik toplamı
            toplam_guvenilirlik += kayit.guvenilirlik
        
        if self.tum_kurtarilan:
            self.ortalama_guvenilirlik = toplam_guvenilirlik // len(self.tum_kurtarilan)
        else:
            self.ortalama_guvenilirlik = 0
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_kurtarilan.copy()
        
        if self.secili_tablo != "Tümü":
            self.filtrelenmis = [k for k in self.filtrelenmis if k.tablo == self.secili_tablo]
        
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [k for k in self.filtrelenmis 
                                if a in k.veri_ozeti.lower() or a in k.kaynak_db.lower()]
        
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} kurtarılan kayıt"
        
        for kayit in self.filtrelenmis[:500]:
            # Güvenilirlik rengi
            if kayit.guvenilirlik >= 70:
                guv_renk = "#4caf50"
            elif kayit.guvenilirlik >= 40:
                guv_renk = "#ff9800"
            else:
                guv_renk = "#f44336"
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        # Güvenilirlik göstergesi
                        ft.Container(
                            content=ft.Text(f"{kayit.guvenilirlik}%", size=9, color=guv_renk, 
                                           weight=ft.FontWeight.BOLD),
                            width=35, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Row([
                                ft.Container(
                                    content=ft.Text(kayit.tablo, size=10, color="#888888"),
                                    padding=ft.padding.symmetric(horizontal=6, vertical=2),
                                    bgcolor="#222222", border_radius=3
                                ),
                                ft.Text(kayit.kaynak_db, size=10, color="#555555")
                            ], spacing=6),
                            ft.Text(kayit.veri_ozeti[:70], size=12, color="#ffffff", max_lines=1)
                        ], expand=True, spacing=3),
                        ft.Text(kayit.tarayici.value[:3].upper(), size=10, color="#555555")
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")),
                    on_click=lambda e, k=kayit: self._kayit_sec(e, k),
                    ink=True
                )
            )
    
    def _kayit_sec(self, e, kayit: SilinenKayit):
        """Kayıt detaylarını göster"""
        self.secili_kayit = kayit
        
        # Veri JSON formatı
        try:
            veri_str = json.dumps(kayit.veri, indent=2, ensure_ascii=False, default=str)
            if len(veri_str) > 1000:
                veri_str = veri_str[:1000] + "\n..."
        except:
            veri_str = str(kayit.veri)
        
        # Güvenilirlik rengi
        if kayit.guvenilirlik >= 70:
            guv_renk = "#4caf50"
            guv_aciklama = "Yüksek güvenilirlik"
        elif kayit.guvenilirlik >= 40:
            guv_renk = "#ff9800"
            guv_aciklama = "Orta güvenilirlik"
        else:
            guv_renk = "#f44336"
            guv_aciklama = "Düşük güvenilirlik"
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Kurtarılan Veri Detayları", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                
                # Güvenilirlik göstergesi
                ft.Container(
                    content=ft.Row([
                        ft.ProgressBar(value=kayit.guvenilirlik/100, color=guv_renk, bgcolor="#333333", expand=True),
                        ft.Text(f"{kayit.guvenilirlik}%", size=12, color=guv_renk, weight=ft.FontWeight.BOLD)
                    ], spacing=10),
                    padding=10, bgcolor="#1a1a1a", border_radius=4
                ),
                ft.Text(guv_aciklama, size=10, color="#888888"),
                ft.Container(height=5),
                
                self._detay_satir("Tablo", kayit.tablo),
                self._detay_satir("Kaynak DB", kayit.kaynak_db),
                self._detay_satir("Tarayıcı", kayit.tarayici.gorunen_ad),
                self._detay_satir("Profil", kayit.profil),
                self._detay_satir("Kurtarma Tarihi", kayit.kurtarma_tarihi.strftime("%d.%m.%Y %H:%M")),
                ft.Container(height=8),
                ft.Text("Kurtarılan Veri:", size=11, color="#888888"),
                ft.Container(
                    content=ft.Text(veri_str, size=10, color="#ffffff", selectable=True),
                    padding=10, bgcolor="#0a0a0a", border_radius=4,
                    border=ft.border.all(1, "#333333")
                )
            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=450
        )
        self.detay_panel.visible = True
        e.page.update()
    
    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=90),
            ft.Text(deger[:50] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])
    
    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()
    
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()
    
    def _tablo_degisti(self, e):
        self.secili_tablo = e.control.value
        self._filtrele()
        e.page.update()
    
    def build(self) -> ft.Container:
        # Tablo seçenekleri
        tablo_secenekleri = [ft.dropdown.Option("Tümü")]
        for tablo in self.tablo_sayaci.keys():
            tablo_secenekleri.append(ft.dropdown.Option(tablo))
        
        return ft.Container(
            content=ft.Column([
                ft.Text("Silinen Veri Kurtarma", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("SQLite veritabanlarından kurtarılan veriler", size=12, color="#666666"),
                ft.Container(height=15),
                
                # Uyarı
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.INFO_OUTLINE, size=16, color="#ff9800"),
                        ft.Text("Kurtarılan veriler WAL ve freelist taramasından elde edilmiştir. "
                               "Güvenilirlik skoru, verinin bütünlüğünü gösterir.", 
                               size=11, color="#888888", expand=True)
                    ], spacing=8),
                    padding=10, bgcolor="#1a1a0a", border_radius=6, border=ft.border.all(1, "#333300")
                ),
                ft.Container(height=15),
                
                # Özet istatistikler
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("Kurtarılan Kayıt", size=10, color="#666666"),
                            ft.Text(str(len(self.tum_kurtarilan)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Farklı Tablo", size=10, color="#666666"),
                            ft.Text(str(len(self.tablo_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Veritabanı", size=10, color="#666666"),
                            ft.Text(str(len(self.db_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Ort. Güvenilirlik", size=10, color="#666666"),
                            ft.Text(f"{self.ortalama_guvenilirlik}%", size=18, weight=ft.FontWeight.BOLD, 
                                   color="#4caf50" if self.ortalama_guvenilirlik >= 50 else "#ff9800")
                        ], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.Row([
                    ft.TextField(hint_text="Ara...", prefix_icon=ft.Icons.SEARCH,
                                border_radius=6, bgcolor="#141414", border_color="#333333",
                                on_submit=self._arama_degisti, on_blur=self._arama_degisti, 
                                expand=True, height=40, text_size=13),
                    ft.Dropdown(
                        value="Tümü", width=160, bgcolor="#141414", border_color="#333333",
                        options=tablo_secenekleri,
                        on_change=self._tablo_degisti, text_size=12
                    )
                ], spacing=10),
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=10)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
