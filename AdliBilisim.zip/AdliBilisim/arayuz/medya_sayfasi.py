# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Medya Geçmişi Sayfası

Video ve ses izleme geçmişi görüntüleme.
"""

import flet as ft
from datetime import datetime
from typing import List, Dict

from modeller.veri_modelleri import MedyaGecmisi


class MedyaSayfasi:
    """Medya geçmişi sayfası"""
    
    def __init__(self):
        self.tum_veriler: List[MedyaGecmisi] = []
        self.filtrelenmis: List[MedyaGecmisi] = []
        self.arama = ""
        self.secili_tip = "Tümü"
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 medya", color="#666666", size=12)
        
        # İstatistikler
        self.kaynak_sayaci: Dict[str, int] = {}
        self.video_sayisi = 0
        self.audio_sayisi = 0
        
        # Detay paneli
        self.detay_panel = ft.Container(visible=False)
    
    def verileri_yukle(self, veriler: List[MedyaGecmisi]):
        self.tum_veriler = sorted(veriler, key=lambda x: x.son_izleme or datetime.min, reverse=True)
        self._istatistikleri_hesapla()
        self._filtrele()
    
    def _istatistikleri_hesapla(self):
        self.kaynak_sayaci.clear()
        self.video_sayisi = 0
        self.audio_sayisi = 0
        
        for veri in self.tum_veriler:
            if veri.medya_tipi == "video":
                self.video_sayisi += 1
            else:
                self.audio_sayisi += 1
            
            if veri.kaynak:
                self.kaynak_sayaci[veri.kaynak] = self.kaynak_sayaci.get(veri.kaynak, 0) + 1
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_veriler.copy()
        
        if self.secili_tip == "Video":
            self.filtrelenmis = [v for v in self.filtrelenmis if v.medya_tipi == "video"]
        elif self.secili_tip == "Ses":
            self.filtrelenmis = [v for v in self.filtrelenmis if v.medya_tipi == "audio"]
        
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [v for v in self.filtrelenmis 
                                if a in v.baslik.lower() or a in v.url.lower()]
        
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} medya"
        
        for veri in self.filtrelenmis[:300]:
            ikon = "🎬" if veri.medya_tipi == "video" else "🎵"
            renk = "#f44336" if veri.medya_tipi == "video" else "#4caf50"
            
            try:
                tarih = veri.son_izleme.strftime("%d.%m.%Y %H:%M") if veri.son_izleme else "-"
            except:
                tarih = "-"
            
            baslik = veri.baslik[:60] if veri.baslik else "(Başlıksız)"
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(ikon, size=14),
                            width=28, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Text(baslik, size=12, color="#ffffff", max_lines=1),
                            ft.Row([
                                ft.Text(veri.kaynak if veri.kaynak else veri.domain[:30], 
                                       size=10, color="#555555"),
                            ])
                        ], expand=True, spacing=2),
                        ft.Column([
                            ft.Container(
                                content=ft.Text(veri.medya_tipi.upper(), size=9, color=renk),
                                padding=ft.padding.symmetric(horizontal=6, vertical=2),
                                bgcolor="#1a1a1a", border_radius=3
                            ),
                            ft.Text(tarih, size=10, color="#444444")
                        ], horizontal_alignment=ft.CrossAxisAlignment.END, spacing=2)
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")),
                    on_click=lambda e, k=veri: self._kayit_sec(e, k),
                    ink=True
                )
            )
    
    def _kayit_sec(self, e, kayit: MedyaGecmisi):
        try:
            tarih = kayit.son_izleme.strftime("%d.%m.%Y %H:%M:%S") if kayit.son_izleme else "-"
        except:
            tarih = "-"
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Medya Detayları", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                self._detay_satir("Başlık", kayit.baslik),
                self._detay_satir("URL", kayit.url),
                self._detay_satir("Tip", kayit.medya_tipi.title()),
                self._detay_satir("Kaynak", kayit.kaynak or kayit.domain),
                self._detay_satir("Son İzleme", tarih),
                self._detay_satir("Tarayıcı", kayit.tarayici.gorunen_ad),
            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=350
        )
        self.detay_panel.visible = True
        e.page.update()
    
    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=80),
            ft.Text(deger[:55] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])
    
    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()
    
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()
    
    def _tip_degisti(self, e):
        self.secili_tip = e.control.value
        self._filtrele()
        e.page.update()
    
    def build(self) -> ft.Container:
        # En çok izlenen kaynaklar
        top_kaynaklar = sorted(self.kaynak_sayaci.items(), key=lambda x: x[1], reverse=True)[:3]
        
        return ft.Container(
            content=ft.Column([
                ft.Text("Medya Geçmişi", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Video ve ses izleme kayıtları", size=12, color="#666666"),
                ft.Container(height=15),
                
                # İstatistik özeti
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("Toplam Medya", size=10, color="#666666"),
                            ft.Text(str(len(self.tum_veriler)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Video", size=10, color="#666666"),
                            ft.Text(str(self.video_sayisi), size=18, weight=ft.FontWeight.BOLD, color="#f44336")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Ses", size=10, color="#666666"),
                            ft.Text(str(self.audio_sayisi), size=18, weight=ft.FontWeight.BOLD, color="#4caf50")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Kaynak Sayısı", size=10, color="#666666"),
                            ft.Text(str(len(self.kaynak_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.Row([
                    ft.TextField(hint_text="Başlık veya URL ara...", prefix_icon=ft.Icons.SEARCH,
                                border_radius=6, bgcolor="#141414", border_color="#333333",
                                on_submit=self._arama_degisti, on_blur=self._arama_degisti, 
                                expand=True, height=40, text_size=13),
                    ft.Dropdown(
                        value="Tümü", width=110, bgcolor="#141414", border_color="#333333",
                        options=[ft.dropdown.Option("Tümü"), ft.dropdown.Option("Video"),
                                ft.dropdown.Option("Ses")],
                        on_select=self._tip_degisti, text_size=12
                    )
                ], spacing=10),
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=10)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
