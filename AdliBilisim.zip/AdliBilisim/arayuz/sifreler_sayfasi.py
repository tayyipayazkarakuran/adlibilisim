# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Şifreler Sayfası
"""

import flet as ft
from typing import List

from modeller.veri_modelleri import KayitliSifre


class SifrelerSayfasi:
    """Kayıtlı şifreler sayfası"""
    
    def __init__(self):
        self.sifreler: List[KayitliSifre] = []
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 şifre", color="#666666", size=12)
        self.gizle = False  # Varsayılan olarak şifreleri göster
    
    def verileri_yukle(self, sifreler: List[KayitliSifre]):
        self.sifreler = sifreler
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.sifreler)} kayıtlı şifre"
        
        for s in self.sifreler[:200]:
            # Şifreyi göster veya gizle
            if self.gizle:
                sifre = "••••••••"
                sifre_rengi = "#888888"
            else:
                if s.sifre_cozulmus:
                    sifre = s.sifre_cozulmus
                    sifre_rengi = "#44ff44"  # Yeşil renk - çözülmüş şifre
                else:
                    sifre = "(Çözülemedi)"
                    sifre_rengi = "#ff6666"  # Kırmızı - çözülemedi
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.LOCK, size=16, color="#666666"),
                        ft.Column([
                            ft.Text(s.domain[:50] if s.domain else "(Domain yok)", size=13, color="#ffffff", max_lines=1),
                            ft.Text(f"Kullanıcı: {s.kullanici_adi[:40] if s.kullanici_adi else '(Kullanıcı adı yok)'}", 
                                   size=11, color="#555555", max_lines=1)
                        ], expand=True, spacing=1),
                        ft.Container(
                            content=ft.Text(sifre, size=11, color=sifre_rengi, font_family="monospace"),
                            tooltip=sifre if len(sifre) > 30 else None  # Uzun şifreler için tooltip
                        )
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a"))
                )
            )
    
    def _toggle(self, e):
        self.gizle = not self.gizle
        self._guncelle()
        e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Kayıtlı Şifreler", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Tarayıcılarda saklanan şifreler", size=12, color="#666666"),
                ft.Container(height=10),
                ft.Container(
                    content=ft.Text("Bu bilgiler hassas veri içerir. Sadece yetkili kullanım için.", 
                                   size=11, color="#888888"),
                    padding=10, border_radius=6, bgcolor="#1a1a1a"
                ),
                ft.Container(height=15),
                ft.Row([
                    self.sonuc,
                    ft.TextButton(
                        "Gizle" if not self.gizle else "Göster", 
                        on_click=self._toggle,
                        icon=ft.Icons.VISIBILITY if self.gizle else ft.Icons.VISIBILITY_OFF
                    )
                ]),
                ft.Divider(color="#222222", height=1),
                ft.Container(content=self.liste, expand=True)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
