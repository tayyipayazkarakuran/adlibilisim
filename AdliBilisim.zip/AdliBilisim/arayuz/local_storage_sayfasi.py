# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - LocalStorage Sayfası

LocalStorage ve IndexedDB verileri görüntüleme.
"""

import flet as ft
from datetime import datetime
from typing import List, Dict
from urllib.parse import urlparse

from modeller.veri_modelleri import LocalStorageVerisi


class LocalStorageSayfasi:
    """LocalStorage/IndexedDB verileri sayfası"""
    
    def __init__(self):
        self.tum_veriler: List[LocalStorageVerisi] = []
        self.filtrelenmis: List[LocalStorageVerisi] = []
        self.arama = ""
        self.secili_tip = "Tümü"
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 kayıt", color="#666666", size=12)
        
        # İstatistikler
        self.origin_sayaci: Dict[str, int] = {}
        self.tip_sayaci: Dict[str, int] = {}
        self.toplam_boyut = 0
        
        # Detay paneli
        self.detay_panel = ft.Container(visible=False)
        self.secili_kayit = None
    
    def verileri_yukle(self, veriler: List[LocalStorageVerisi]):
        """Verileri yükler"""
        self.tum_veriler = sorted(veriler, key=lambda x: x.origin)
        self._istatistikleri_hesapla()
        self._filtrele()
    
    def _istatistikleri_hesapla(self):
        """İstatistikleri hesapla"""
        self.origin_sayaci.clear()
        self.tip_sayaci.clear()
        self.toplam_boyut = 0
        
        for veri in self.tum_veriler:
            # Origin sayacı
            origin = veri.domain
            self.origin_sayaci[origin] = self.origin_sayaci.get(origin, 0) + 1
            
            # Tip sayacı
            tip = veri.veri_tipi
            self.tip_sayaci[tip] = self.tip_sayaci.get(tip, 0) + 1
            
            # Toplam boyut
            self.toplam_boyut += veri.boyut
    
    def _boyut_formatla(self, boyut: int) -> str:
        """Boyutu okunabilir formata çevirir"""
        for birim in ['B', 'KB', 'MB', 'GB']:
            if boyut < 1024:
                return f"{boyut:.1f} {birim}"
            boyut /= 1024
        return f"{boyut:.1f} TB"
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_veriler.copy()
        
        if self.secili_tip != "Tümü":
            tip_map = {
                "LocalStorage": "localStorage",
                "IndexedDB": "indexedDB"
            }
            hedef_tip = tip_map.get(self.secili_tip, self.secili_tip)
            self.filtrelenmis = [v for v in self.filtrelenmis if v.veri_tipi == hedef_tip]
        
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [v for v in self.filtrelenmis 
                                if a in v.origin.lower() or a in v.anahtar.lower() or a in v.deger.lower()]
        
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} kayıt bulundu"
        
        for veri in self.filtrelenmis[:300]:
            tip_renk = "#4a9eff" if veri.veri_tipi == "localStorage" else "#ff9800"
            tip_kisa = "LS" if veri.veri_tipi == "localStorage" else "IDB"
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(tip_kisa, size=9, color=tip_renk, weight=ft.FontWeight.BOLD),
                            width=28, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Row([
                                ft.Text(veri.domain[:40], size=12, color="#ffffff", weight=ft.FontWeight.W_500),
                                ft.Text(f"({self._boyut_formatla(veri.boyut)})", size=10, color="#666666")
                            ], spacing=8),
                            ft.Text(f"{veri.anahtar[:50]}: {veri.deger_kisaltilmis[:40]}", 
                                   size=11, color="#555555", max_lines=1)
                        ], expand=True, spacing=2),
                        ft.Text(veri.tarayici.value[:3].upper(), size=10, color="#555555")
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")),
                    on_click=lambda e, k=veri: self._kayit_sec(e, k),
                    ink=True
                )
            )
    
    def _kayit_sec(self, e, kayit: LocalStorageVerisi):
        """Kayıt detaylarını göster"""
        self.secili_kayit = kayit
        
        # JSON formatında değer gösterimi
        deger_gosterim = kayit.deger
        if len(deger_gosterim) > 500:
            deger_gosterim = deger_gosterim[:500] + "..."
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Veri Detayları", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                self._detay_satir("Origin", kayit.origin),
                self._detay_satir("Domain", kayit.domain),
                self._detay_satir("Anahtar", kayit.anahtar),
                self._detay_satir("Tip", kayit.veri_tipi),
                self._detay_satir("Boyut", self._boyut_formatla(kayit.boyut)),
                self._detay_satir("Tarayıcı", kayit.tarayici.gorunen_ad),
                self._detay_satir("Profil", kayit.profil),
                ft.Container(height=8),
                ft.Text("Değer:", size=11, color="#888888"),
                ft.Container(
                    content=ft.Text(deger_gosterim, size=10, color="#ffffff", selectable=True),
                    padding=10, bgcolor="#0a0a0a", border_radius=4,
                    border=ft.border.all(1, "#333333")
                )
            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=400
        )
        self.detay_panel.visible = True
        e.page.update()
    
    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=70),
            ft.Text(deger[:50] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])
    
    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()
    
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()
    
    def _tip_degisti(self, e):
        self.secili_tip = e.control.value
        self._filtrele()
        e.page.update()
    
    def _en_cok_origin(self) -> List[str]:
        """En çok veri içeren origin'ler"""
        sorted_origins = sorted(self.origin_sayaci.items(), key=lambda x: x[1], reverse=True)
        return [f"{o} ({s})" for o, s in sorted_origins[:5]]
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("LocalStorage / IndexedDB", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Web sitelerinin yerel depolama verileri", size=12, color="#666666"),
                ft.Container(height=15),
                
                # Özet istatistikler
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("Toplam Kayıt", size=10, color="#666666"),
                            ft.Text(str(len(self.tum_veriler)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Benzersiz Origin", size=10, color="#666666"),
                            ft.Text(str(len(self.origin_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Toplam Boyut", size=10, color="#666666"),
                            ft.Text(self._boyut_formatla(self.toplam_boyut), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("LocalStorage", size=10, color="#666666"),
                            ft.Text(str(self.tip_sayaci.get('localStorage', 0)), size=18, weight=ft.FontWeight.BOLD, color="#4a9eff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("IndexedDB", size=10, color="#666666"),
                            ft.Text(str(self.tip_sayaci.get('indexedDB', 0)), size=18, weight=ft.FontWeight.BOLD, color="#ff9800")
                        ], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.Row([
                    ft.TextField(hint_text="Origin, anahtar veya değer ara...", prefix_icon=ft.Icons.SEARCH,
                                border_radius=6, bgcolor="#141414", border_color="#333333",
                                on_submit=self._arama_degisti, on_blur=self._arama_degisti, 
                                expand=True, height=40, text_size=13),
                    ft.Dropdown(
                        value="Tümü", width=140, bgcolor="#141414", border_color="#333333",
                        options=[ft.dropdown.Option("Tümü"), ft.dropdown.Option("LocalStorage"),
                                ft.dropdown.Option("IndexedDB")],
                        on_select=self._tip_degisti, text_size=12
                    )
                ], spacing=10),
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=10)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
