# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Çerez Sayfası

Cookie analizi ve görüntüleme - Detaylı bilgiler.
"""

import flet as ft
from datetime import datetime
from typing import List, Dict

from modeller.veri_modelleri import Cerez


class CerezSayfasi:
    """Cookie analizi sayfası - Tüm detaylar"""
    
    def __init__(self):
        self.tum_cerezler: List[Cerez] = []
        self.filtrelenmis: List[Cerez] = []
        self.arama = ""
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 çerez", color="#666666", size=12)
        self.secili_cerez = None
        self.detay_panel = ft.Container(visible=False)
        
        # İstatistikler
        self.guvenli_sayisi = 0
        self.http_only_sayisi = 0
        self.oturum_cerezi_sayisi = 0
        self.domain_sayaci: Dict[str, int] = {}
    
    def verileri_yukle(self, cerezler: List[Cerez]):
        self.tum_cerezler = sorted(cerezler, key=lambda x: x.olusturma_tarihi)
        self._istatistikleri_hesapla()
        self._filtrele()
    
    def _istatistikleri_hesapla(self):
        """İstatistikleri hesapla"""
        self.guvenli_sayisi = 0
        self.http_only_sayisi = 0
        self.oturum_cerezi_sayisi = 0
        self.domain_sayaci.clear()
        
        for c in self.tum_cerezler:
            if c.guvenli:
                self.guvenli_sayisi += 1
            if c.http_only:
                self.http_only_sayisi += 1
            if c.oturum_cerezi:
                self.oturum_cerezi_sayisi += 1
            
            # Domain sayacı
            domain = c.domain.lstrip('.')
            self.domain_sayaci[domain] = self.domain_sayaci.get(domain, 0) + 1
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_cerezler.copy()
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [c for c in self.filtrelenmis if a in c.domain.lower() or a in c.ad.lower()]
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} çerez"
        
        for c in self.filtrelenmis[:300]:
            try:
                tarih = c.olusturma_tarihi.strftime("%d.%m.%Y") if c.olusturma_tarihi != datetime.min else "-"
            except:
                tarih = "-"
            
            tip = "Oturum" if c.oturum_cerezi else "Kalıcı"
            guvenlik = "Güvenli" if c.guvenli else "Normal"
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Icon(ft.Icons.LOCK if c.guvenli else ft.Icons.LOCK_OPEN, 
                                           size=14, color="#666666"),
                            width=28, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Text(c.ad[:50], size=13, color="#ffffff", max_lines=1),
                            ft.Text(c.domain, size=11, color="#555555", max_lines=1)
                        ], expand=True, spacing=1),
                        ft.Column([
                            ft.Text(f"{tip} | {guvenlik}", size=10, color="#555555"),
                            ft.Text(tarih, size=10, color="#444444")
                        ], horizontal_alignment=ft.CrossAxisAlignment.END, spacing=1)
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")),
                    on_click=lambda e, cerez=c: self._cerez_sec(e, cerez),
                    ink=True
                )
            )
    
    def _cerez_sec(self, e, cerez: Cerez):
        """Çerez detaylarını göster"""
        self.secili_cerez = cerez
        
        try:
            olusturma = cerez.olusturma_tarihi.strftime("%d.%m.%Y %H:%M:%S") if cerez.olusturma_tarihi != datetime.min else "-"
        except:
            olusturma = "-"
        
        try:
            son_erisim = cerez.son_erisim_tarihi.strftime("%d.%m.%Y %H:%M:%S") if cerez.son_erisim_tarihi and cerez.son_erisim_tarihi != datetime.min else "-"
        except:
            son_erisim = "-"
        
        try:
            son_kullanma = cerez.son_kullanma_tarihi.strftime("%d.%m.%Y %H:%M:%S") if cerez.son_kullanma_tarihi else "Oturum çerezi"
        except:
            son_kullanma = "-"
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Çerez Detayları", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                self._detay_satir("Ad", cerez.ad),
                self._detay_satir("Değer", cerez.deger[:100] + "..." if len(cerez.deger) > 100 else cerez.deger),
                self._detay_satir("Domain", cerez.domain),
                self._detay_satir("Yol", cerez.yol),
                self._detay_satir("Oluşturma", olusturma),
                self._detay_satir("Son Erişim", son_erisim),
                self._detay_satir("Son Kullanma", son_kullanma),
                self._detay_satir("Güvenli (HTTPS)", "Evet" if cerez.guvenli else "Hayır"),
                self._detay_satir("HttpOnly", "Evet" if cerez.http_only else "Hayır"),
                self._detay_satir("Tarayıcı", cerez.tarayici.gorunen_ad),
                self._detay_satir("Profil", cerez.profil),
            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=350
        )
        self.detay_panel.visible = True
        e.page.update()
    
    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=100),
            ft.Text(deger[:60] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])
    
    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()
    
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()
    
    def _en_cok_domain(self) -> str:
        """En çok çerez içeren domain"""
        if not self.domain_sayaci:
            return "-"
        en_cok = max(self.domain_sayaci.items(), key=lambda x: x[1])
        return f"{en_cok[0]} ({en_cok[1]})"
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Çerez Analizi", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Tüm çerez detayları - Tıklayarak detay görün", size=12, color="#666666"),
                ft.Container(height=15),
                
                # İstatistik özeti
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("Toplam Çerez", size=10, color="#666666"),
                            ft.Text(str(len(self.tum_cerezler)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Güvenli (HTTPS)", size=10, color="#666666"),
                            ft.Text(str(self.guvenli_sayisi), size=18, weight=ft.FontWeight.BOLD, color="#4caf50")
                        ], expand=True),
                        ft.Column([
                            ft.Text("HttpOnly", size=10, color="#666666"),
                            ft.Text(str(self.http_only_sayisi), size=18, weight=ft.FontWeight.BOLD, color="#ff9800")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Oturum Çerezi", size=10, color="#666666"),
                            ft.Text(str(self.oturum_cerezi_sayisi), size=18, weight=ft.FontWeight.BOLD, color="#4a9eff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Benzersiz Domain", size=10, color="#666666"),
                            ft.Text(str(len(self.domain_sayaci)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.TextField(hint_text="Domain veya çerez adı ara...", prefix_icon=ft.Icons.SEARCH,
                            border_radius=6, bgcolor="#141414", border_color="#333333",
                            on_submit=self._arama_degisti, on_blur=self._arama_degisti, height=40, text_size=13),
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=15)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )

