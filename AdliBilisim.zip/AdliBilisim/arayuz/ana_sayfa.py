# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Ana Sayfa

Dashboard ve tarama başlatma arayüzü.
"""

import flet as ft
from datetime import datetime
from typing import Callable


class AnaSayfa:
    """Ana sayfa / Dashboard"""
    
    def __init__(self, tarama_baslat_callback: Callable = None):
        self.tarama_baslat_callback = tarama_baslat_callback
        self.tarama_durumu = ft.Text("Tarama başlatılmadı", color="#666666", size=12)
        self.ilerleme = ft.ProgressBar(visible=False, color="#ffffff", bgcolor="#333333")
        
        self.istatistikler = {
            "gecmis": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
            "cerez": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
            "indirme": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
            "sifre": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
            "arama": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
            "cache": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
            "oturum": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#4a9eff"),
            "storage": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#ff9800"),
            "kurtarma": ft.Text("0", size=28, weight=ft.FontWeight.BOLD, color="#4caf50"),
        }
    
    def istatistikleri_guncelle(self, veriler: dict):
        self.istatistikler["gecmis"].value = str(veriler.get("gecmis", 0))
        self.istatistikler["cerez"].value = str(veriler.get("cerez", 0))
        self.istatistikler["indirme"].value = str(veriler.get("indirme", 0))
        self.istatistikler["sifre"].value = str(veriler.get("sifre", 0))
        self.istatistikler["arama"].value = str(veriler.get("arama", 0))
        self.istatistikler["cache"].value = str(veriler.get("cache", 0))
        self.istatistikler["oturum"].value = str(veriler.get("oturum", 0))
        self.istatistikler["storage"].value = str(veriler.get("storage", 0))
        self.istatistikler["kurtarma"].value = str(veriler.get("kurtarma", 0))
    
    def _stat_kart(self, baslik: str, deger_ref: ft.Text, ikon: str = None) -> ft.Container:
        ikon_widget = ft.Icon(ikon, size=16, color="#555555") if ikon else None
        return ft.Container(
            content=ft.Column([
                deger_ref, 
                ft.Row([
                    ikon_widget if ikon_widget else ft.Container(),
                    ft.Text(baslik, size=11, color="#666666")
                ], spacing=4)
            ], spacing=2),
            padding=15, border_radius=6, bgcolor="#141414", border=ft.border.all(1, "#222222"), expand=True
        )
    
    def _tarama_baslat(self, e):
        if self.tarama_baslat_callback:
            self.tarama_durumu.value = "Tarama yapılıyor..."
            self.ilerleme.visible = True
            e.page.update()
            self.tarama_baslat_callback()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                # Başlık
                ft.Text("Adli Bilişim Forensik Aracı", size=24, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Profesyonel tarayıcı forensik analiz aracı", size=12, color="#666666"),
                ft.Container(height=20),
                
                # Uyarı
                ft.Container(
                    content=ft.Text("Bu araç sadece yasal adli bilişim çalışmaları için kullanılmalıdır.", 
                                   size=12, color="#888888"),
                    padding=12, border_radius=6, bgcolor="#1a1a1a", border=ft.border.all(1, "#333333")
                ),
                ft.Container(height=20),
                
                # Tarama
                ft.Container(
                    content=ft.Column([
                        ft.Text("Tarama Kontrolü", size=16, weight=ft.FontWeight.BOLD, color="#ffffff"),
                        ft.Container(height=10),
                        ft.Row([
                            ft.Container(
                                content=ft.Text("Taramayı Başlat", color="#000000", weight=ft.FontWeight.W_500, size=13),
                                padding=ft.padding.symmetric(horizontal=24, vertical=12),
                                border_radius=6, bgcolor="#ffffff", on_click=self._tarama_baslat, ink=True
                            ),
                            ft.Container(width=15),
                            self.tarama_durumu
                        ]),
                        self.ilerleme
                    ]),
                    padding=20, border_radius=8, bgcolor="#141414", border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=25),
                
                # Temel İstatistikler
                ft.Text("Temel Veriler", size=16, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Container(height=10),
                ft.Row([
                    self._stat_kart("Geçmiş", self.istatistikler["gecmis"], ft.Icons.HISTORY),
                    self._stat_kart("Arama", self.istatistikler["arama"], ft.Icons.SEARCH),
                    self._stat_kart("Çerez", self.istatistikler["cerez"], ft.Icons.COOKIE),
                ], spacing=12),
                ft.Container(height=10),
                ft.Row([
                    self._stat_kart("İndirme", self.istatistikler["indirme"], ft.Icons.DOWNLOAD),
                    self._stat_kart("Şifre", self.istatistikler["sifre"], ft.Icons.LOCK),
                    self._stat_kart("Cache", self.istatistikler["cache"], ft.Icons.IMAGE),
                ], spacing=12),
                ft.Container(height=20),
                
                # Yeni Özellikler
                ft.Text("Gelişmiş Forensik", size=16, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Container(height=10),
                ft.Row([
                    self._stat_kart("Oturumlar", self.istatistikler["oturum"], ft.Icons.TAB),
                    self._stat_kart("LocalStorage", self.istatistikler["storage"], ft.Icons.STORAGE),
                    self._stat_kart("Kurtarılan", self.istatistikler["kurtarma"], ft.Icons.RESTORE),
                ], spacing=12),
            ], scroll=ft.ScrollMode.AUTO),
            expand=True, padding=30, bgcolor="#0a0a0a"
        )

