# -*- coding: utf-8 -*-
"""
Adli Bilişim Forensik Aracı - Otomatik Doldurma Sayfası

Form otomatik doldurma verilerini görüntüleme.
"""

import flet as ft
from datetime import datetime
from typing import List, Dict

from modeller.veri_modelleri import OtomatikDoldurma


class OtomatikDoldurmaSayfasi:
    """Otomatik doldurma verileri sayfası"""
    
    def __init__(self):
        self.tum_veriler: List[OtomatikDoldurma] = []
        self.filtrelenmis: List[OtomatikDoldurma] = []
        self.arama = ""
        self.secili_tip = "Tümü"
        self.liste = ft.Column(spacing=0, scroll=ft.ScrollMode.AUTO)
        self.sonuc = ft.Text("0 kayıt", color="#666666", size=12)
        
        # İstatistikler
        self.tip_sayaci: Dict[str, int] = {}
        
        # Detay paneli
        self.detay_panel = ft.Container(visible=False)
        self.secili_kayit = None
    
    def verileri_yukle(self, veriler: List[OtomatikDoldurma]):
        """Verileri yükler"""
        self.tum_veriler = veriler
        self._istatistikleri_hesapla()
        self._filtrele()
    
    def _istatistikleri_hesapla(self):
        """İstatistikleri hesapla"""
        self.tip_sayaci.clear()
        for veri in self.tum_veriler:
            self.tip_sayaci[veri.tip] = self.tip_sayaci.get(veri.tip, 0) + 1
    
    def _filtrele(self):
        self.filtrelenmis = self.tum_veriler.copy()
        
        if self.secili_tip != "Tümü":
            tip_map = {"Email": "email", "Telefon": "telefon", "Adres": "adres", 
                      "İsim": "isim", "Kredi Kartı": "kredi_karti"}
            hedef = tip_map.get(self.secili_tip, self.secili_tip.lower())
            self.filtrelenmis = [v for v in self.filtrelenmis if v.tip == hedef]
        
        if self.arama:
            a = self.arama.lower()
            self.filtrelenmis = [v for v in self.filtrelenmis 
                                if a in v.alan.lower() or a in v.deger.lower()]
        
        self._guncelle()
    
    def _guncelle(self):
        self.liste.controls.clear()
        self.sonuc.value = f"{len(self.filtrelenmis)} kayıt"
        
        for veri in self.filtrelenmis[:300]:
            # Tip ikonu ve rengi
            tip_bilgi = {
                'email': ('📧', '#4a9eff'),
                'telefon': ('📱', '#4caf50'),
                'adres': ('🏠', '#ff9800'),
                'isim': ('👤', '#9c27b0'),
                'kredi_karti': ('💳', '#f44336'),
            }
            ikon, renk = tip_bilgi.get(veri.tip, ('📝', '#888888'))
            
            self.liste.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(ikon, size=14),
                            width=28, height=28, border_radius=4, bgcolor="#1a1a1a",
                            alignment=ft.Alignment(0, 0)
                        ),
                        ft.Column([
                            ft.Text(veri.alan[:40], size=12, color="#ffffff"),
                            ft.Text(veri.maskelenmis_deger[:50], size=11, color="#555555")
                        ], expand=True, spacing=1),
                        ft.Column([
                            ft.Text(veri.tip.replace('_', ' ').title(), size=10, color=renk),
                            ft.Text(f"{veri.kullanim_sayisi}x", size=10, color="#444444")
                        ], horizontal_alignment=ft.CrossAxisAlignment.END, spacing=1)
                    ], spacing=10),
                    padding=ft.padding.symmetric(horizontal=10, vertical=8),
                    border=ft.border.only(bottom=ft.BorderSide(1, "#1a1a1a")),
                    on_click=lambda e, k=veri: self._kayit_sec(e, k),
                    ink=True
                )
            )
    
    def _kayit_sec(self, e, kayit: OtomatikDoldurma):
        self.secili_kayit = kayit
        
        try:
            son_kullanim = kayit.son_kullanim.strftime("%d.%m.%Y %H:%M") if kayit.son_kullanim else "-"
        except:
            son_kullanim = "-"
        
        self.detay_panel.content = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("Detaylar", size=14, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.IconButton(ft.Icons.CLOSE, icon_size=16, on_click=self._detay_kapat, icon_color="#888888")
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#333333", height=1),
                self._detay_satir("Tip", kayit.tip.replace('_', ' ').title()),
                self._detay_satir("Alan", kayit.alan),
                self._detay_satir("Değer", kayit.maskelenmis_deger),
                self._detay_satir("Kullanım", f"{kayit.kullanim_sayisi} kez"),
                self._detay_satir("Son Kullanım", son_kullanim),
                self._detay_satir("Tarayıcı", kayit.tarayici.gorunen_ad),
                self._detay_satir("Profil", kayit.profil),
            ], spacing=8, scroll=ft.ScrollMode.AUTO),
            padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#333333"),
            width=320
        )
        self.detay_panel.visible = True
        e.page.update()
    
    def _detay_satir(self, etiket: str, deger: str) -> ft.Row:
        return ft.Row([
            ft.Text(etiket + ":", size=11, color="#888888", width=90),
            ft.Text(deger[:50] if deger else "-", size=11, color="#ffffff", expand=True, selectable=True)
        ])
    
    def _detay_kapat(self, e):
        self.detay_panel.visible = False
        e.page.update()
    
    def _arama_degisti(self, e):
        self.arama = e.control.value
        self._filtrele()
        e.page.update()
    
    def _tip_degisti(self, e):
        self.secili_tip = e.control.value
        self._filtrele()
        e.page.update()
    
    def build(self) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text("Otomatik Doldurma Verileri", size=20, weight=ft.FontWeight.BOLD, color="#ffffff"),
                ft.Text("Form alanları, adresler, telefonlar", size=12, color="#666666"),
                ft.Container(height=15),
                
                # İstatistik özeti
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("Toplam Kayıt", size=10, color="#666666"),
                            ft.Text(str(len(self.tum_veriler)), size=18, weight=ft.FontWeight.BOLD, color="#ffffff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Email", size=10, color="#666666"),
                            ft.Text(str(self.tip_sayaci.get('email', 0)), size=18, weight=ft.FontWeight.BOLD, color="#4a9eff")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Telefon", size=10, color="#666666"),
                            ft.Text(str(self.tip_sayaci.get('telefon', 0)), size=18, weight=ft.FontWeight.BOLD, color="#4caf50")
                        ], expand=True),
                        ft.Column([
                            ft.Text("Adres", size=10, color="#666666"),
                            ft.Text(str(self.tip_sayaci.get('adres', 0)), size=18, weight=ft.FontWeight.BOLD, color="#ff9800")
                        ], expand=True),
                    ]),
                    padding=15, bgcolor="#141414", border_radius=8, border=ft.border.all(1, "#222222")
                ),
                ft.Container(height=15),
                
                ft.Row([
                    ft.TextField(hint_text="Ara...", prefix_icon=ft.Icons.SEARCH,
                                border_radius=6, bgcolor="#141414", border_color="#333333",
                                on_submit=self._arama_degisti, on_blur=self._arama_degisti, 
                                expand=True, height=40, text_size=13),
                    ft.Dropdown(
                        value="Tümü", width=130, bgcolor="#141414", border_color="#333333",
                        options=[ft.dropdown.Option("Tümü"), ft.dropdown.Option("Email"),
                                ft.dropdown.Option("Telefon"), ft.dropdown.Option("Adres"),
                                ft.dropdown.Option("İsim"), ft.dropdown.Option("Kredi Kartı")],
                        on_select=self._tip_degisti, text_size=12
                    )
                ], spacing=10),
                ft.Container(height=10),
                self.sonuc,
                ft.Divider(color="#222222", height=1),
                ft.Row([
                    ft.Container(content=self.liste, expand=2),
                    self.detay_panel
                ], expand=True, spacing=10)
            ]),
            expand=True, padding=25, bgcolor="#0a0a0a"
        )
