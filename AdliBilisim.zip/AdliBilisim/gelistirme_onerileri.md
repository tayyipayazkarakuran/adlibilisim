# Adli Bilişim Aracı - Geliştirme Önerileri ve Eksikler

Bu proje, güçlü bir temel üzerine kurulmuş olsa da, profesyonel bir adli bilişim aracı seviyesine ulaşması için aşağıdaki özelliklerin eklenmesi ve mevcut eksiklerin giderilmesi önerilmektedir.

## 1. Kritik Forensik Eksikler

### a. Raporlama Sistemi (En Büyük Eksik)
*   **Mevcut Durum:** Veriler sayfalarda görüntüleniyor ancak kapsamlı bir dosya/imaj halinde dışarı aktarılamıyor.
*   **Öneri:**
    *   **HTML Raporu:** Soruşturma detayları, hash değerleri ve bulguların özetlendiği modern bir HTML rapor çıktısı.
    *   **CSV/Excel Export:** Tüm listelerin (geçmiş, çerezler, şifreler) ham veri olarak dışa aktarılması.
    *   **Zaman Çizelgesi (Timeline) Raporu:** Tüm verilerin (geçmiş, indirme, cache) kronolojik sıraya dizildiği tek bir rapor.

### b. Disk İmajı ve Yazma Koruması
*   **Mevcut Durum:** Araç doğrudan canlı sistem diskinde çalışıyor.
*   **Öneri:**
    *   **Hash Doğrulaması:** Analiz edilen dosyaların MD5/SHA256 hashlerinin alınarak bütünlüğün bozulmadığının kanıtlanması.
    *   **Salt Okunur Mod:** Dosyaları açarken kesinlikle salt okunur (read-only) modda açıldığından ve geçici kopyalar üzerinde çalışıldığından emin olunması (şu an kısmen uygulanıyor).

## 2. Gelişmiş Özellik Önerileri

### a. Zaman Çizelgesi (Timeline) Analizi
*   Kullanıcının bir gününü saniye saniye takip edebilmek için Geçmiş, İndirmeler, Çerezler ve Önbellek verilerinin tek bir ekranda, zaman ekseni üzerinde birleştirilmesi.

### b. Global Arama (Keyword Search)
*   Sadece ilgili sayfada değil, tüm çıkarılan veriler (tüm tarayıcılar, tüm kategoriler) içinde anahtar kelime (örn: "kredi kartı", "hack", "gizli") araması yapılabilmesi.

### c. Tarayıcı Eklentileri (Extensions) Analizi
*   Yüklü tarayıcı eklentilerinin (Chrome Extensions vb.) listelenmesi, izinlerinin ve risk durumlarının analizi. Zararlı eklenti tespiti.

### d. Sistem Entegrasyonu
*   **USB Geçmişi:** Tarayıcı geçmişi ile eşleşen USB takıp çıkarma loglarının (Registry/System logs) analizi.
*   **İndirilen Dosya Konumu:** İndirilen dosyanın diskte hala mevcut olup olmadığının kontrolü.

## 3. Teknik İyileştirmeler ve Optimizasyon

### a. Veritabanı ve Bellek Yönetimi
*   **Sorun:** Şu an tüm veriler bellekte (RAM) Python listelerinde tutuluyor (`self.tum_veriler`). 100.000+ satırlık bir geçmiş dosyasında uygulama çökebilir.
*   **Çözüm:** Çıkarılan verilerin analiz sırasında geçici bir SQLite veritabanına (`analiz.db`) yazılması ve arayüzün bu veritabanından sayfalama (pagination) ile veri çekmesi.

### b. Kod Mimarisi
*   **Modüler Yapı:** Yeni bir tarayıcı (örneğin Vivaldi) ekleneceği zaman kodun birçok yerinin değişmesi gerekiyor. "Plugin" tabanlı bir yapıya geçilmeli.
*   **Testler:** Kritik parsers (ayrıştırıcılar) için birim testleri (unit tests) yazılmalı.

## 4. Kullanıcı Arayüzü (UI/UX)

*   **Tema Seçeneği:** Sadece koyu mod var, aydınlık mod eklenebilir.
*   **Daha Detaylı Dashboard:** Ana sayfada sadece sayılar yerine, "En çok ziyaret edilen 5 site", "Son 24 saatteki aktivite yoğunluğu" gibi grafikler eklenebilir (`matplotlib` veya Flet grafikleri ile).
*   **Favicon Desteği:** Geçmiş listesinde sitelerin logolarının (favicon) gösterilmesi.

## 5. Özet: Yapılacaklar Listesi (Öncelikli)

1.  **[KRİTİK] Raporlama Modülü:** `rapor_olusturucu.py` ekle.
2.  **[ÖNEMLİ] Veritabanı Tabanlı Depolama:** Bellek şişmesini önlemek için verileri SQLite'a aktar.
3.  **[ÖZELLİK] Timeline Görünümü:** Yeni bir sayfa olarak ekle.
4.  **[ÖZELLİK] Global Arama:** Üst bara her yerden erişilebilen bir arama çubuğu ekle.
